﻿using System.Collections.Generic;

namespace WinFormsApp1
{
	public class Class1
	{
		public string ID { get; set; }
		public string Firstname { get; set; }
		public string Middlename { get; set; }
		public string Lastname { get; set; }
		public string Age { get; set; }

		public string Gender { get; set; }
		public string Address { get; set; }

		public string EmailAddress { get; set; }

		public string DateofBirth { get; set; }
	}
	public static class StudentDataStore
	{
		public static List<Class1> bsitstudents = new List<Class1>();

		public static List<Class1> bsbastudents = new List<Class1>();

		public static List<Class1> bsnstudents = new List<Class1>();
		public static List<Class1> bscestudents = new List<Class1>();

		public static List<Class1> bseestudents = new List<Class1>();

		public static List<Class1> bscjstudents = new List<Class1>();

		public static List<Class1> bshmstudents = new List<Class1>();

		public static List<Class1> bsedstudents = new List<Class1>();

		public static List<Class1> shsstudents = new List<Class1>();




	}
}
