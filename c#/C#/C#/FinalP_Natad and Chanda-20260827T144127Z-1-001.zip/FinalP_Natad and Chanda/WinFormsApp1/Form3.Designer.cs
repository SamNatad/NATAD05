﻿namespace WinFormsApp1
{
	partial class Form3
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
			label1 = new Label();
			txtName = new TextBox();
			label2 = new Label();
			txtCourse = new TextBox();
			label3 = new Label();
			txtId = new TextBox();
			label4 = new Label();
			txtYear = new TextBox();
			label5 = new Label();
			label6 = new Label();
			label7 = new Label();
			label8 = new Label();
			txtOffer = new TextBox();
			txtSub = new TextBox();
			txtTitle = new TextBox();
			txtTime = new TextBox();
			printDocument1 = new System.Drawing.Printing.PrintDocument();
			printDialog1 = new PrintDialog();
			dataGridView1 = new DataGridView();
			colOffer = new DataGridViewTextBoxColumn();
			colSubject = new DataGridViewTextBoxColumn();
			colTitle = new DataGridViewTextBoxColumn();
			colTime = new DataGridViewTextBoxColumn();
			colSchedule = new DataGridViewTextBoxColumn();
			label9 = new Label();
			txtSchedule = new TextBox();
			btnAdd = new Button();
			btnPrint = new Button();
			pictureBox1 = new PictureBox();
			btnBack = new Button();
			label10 = new Label();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label1.Location = new Point(40, 222);
			label1.Name = "label1";
			label1.Size = new Size(82, 27);
			label1.TabIndex = 0;
			label1.Text = "Name:";
			// 
			// txtName
			// 
			txtName.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtName.Location = new Point(142, 222);
			txtName.Name = "txtName";
			txtName.Size = new Size(459, 35);
			txtName.TabIndex = 1;
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label2.Location = new Point(40, 265);
			label2.Name = "label2";
			label2.Size = new Size(96, 27);
			label2.TabIndex = 2;
			label2.Text = "Course:";
			// 
			// txtCourse
			// 
			txtCourse.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtCourse.Location = new Point(142, 262);
			txtCourse.Name = "txtCourse";
			txtCourse.Size = new Size(632, 35);
			txtCourse.TabIndex = 3;
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label3.Location = new Point(36, 315);
			label3.Name = "label3";
			label3.Size = new Size(100, 27);
			label3.TabIndex = 4;
			label3.Text = "ID Num:";
			// 
			// txtId
			// 
			txtId.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtId.Location = new Point(172, 315);
			txtId.Name = "txtId";
			txtId.Size = new Size(134, 35);
			txtId.TabIndex = 5;
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label4.Location = new Point(36, 384);
			label4.Name = "label4";
			label4.Size = new Size(130, 27);
			label4.TabIndex = 6;
			label4.Text = "Year Level:";
			// 
			// txtYear
			// 
			txtYear.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtYear.Location = new Point(172, 381);
			txtYear.Name = "txtYear";
			txtYear.Size = new Size(145, 35);
			txtYear.TabIndex = 7;
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label5.Location = new Point(54, 443);
			label5.Name = "label5";
			label5.Size = new Size(137, 27);
			label5.TabIndex = 8;
			label5.Text = "Offer Code:";
			// 
			// label6
			// 
			label6.AutoSize = true;
			label6.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label6.Location = new Point(303, 434);
			label6.Name = "label6";
			label6.Size = new Size(101, 27);
			label6.TabIndex = 9;
			label6.Text = "Subject:";
			// 
			// label7
			// 
			label7.AutoSize = true;
			label7.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label7.Location = new Point(585, 434);
			label7.Name = "label7";
			label7.Size = new Size(63, 27);
			label7.TabIndex = 10;
			label7.Text = "Title:";
			// 
			// label8
			// 
			label8.AutoSize = true;
			label8.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label8.Location = new Point(862, 434);
			label8.Name = "label8";
			label8.Size = new Size(70, 27);
			label8.TabIndex = 11;
			label8.Text = "Time:";
			// 
			// txtOffer
			// 
			txtOffer.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtOffer.Location = new Point(36, 483);
			txtOffer.Name = "txtOffer";
			txtOffer.Size = new Size(171, 35);
			txtOffer.TabIndex = 12;
			// 
			// txtSub
			// 
			txtSub.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtSub.Location = new Point(249, 483);
			txtSub.Name = "txtSub";
			txtSub.Size = new Size(200, 35);
			txtSub.TabIndex = 13;
			// 
			// txtTitle
			// 
			txtTitle.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtTitle.Location = new Point(489, 483);
			txtTitle.Name = "txtTitle";
			txtTitle.Size = new Size(279, 35);
			txtTitle.TabIndex = 14;
			// 
			// txtTime
			// 
			txtTime.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtTime.Location = new Point(828, 483);
			txtTime.Name = "txtTime";
			txtTime.Size = new Size(147, 35);
			txtTime.TabIndex = 15;
			// 
			// printDocument1
			// 
			printDocument1.PrintPage += printDocument1_PrintPage;
			// 
			// printDialog1
			// 
			printDialog1.UseEXDialog = true;
			// 
			// dataGridView1
			// 
			dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(new DataGridViewColumn[] { colOffer, colSubject, colTitle, colTime, colSchedule });
			dataGridView1.Location = new Point(34, 557);
			dataGridView1.Name = "dataGridView1";
			dataGridView1.RowHeadersWidth = 62;
			dataGridView1.Size = new Size(819, 298);
			dataGridView1.TabIndex = 16;
			// 
			// colOffer
			// 
			colOffer.HeaderText = "Offer Code";
			colOffer.MinimumWidth = 8;
			colOffer.Name = "colOffer";
			colOffer.Width = 150;
			// 
			// colSubject
			// 
			colSubject.HeaderText = "Subject";
			colSubject.MinimumWidth = 8;
			colSubject.Name = "colSubject";
			colSubject.Width = 150;
			// 
			// colTitle
			// 
			colTitle.HeaderText = "Title";
			colTitle.MinimumWidth = 8;
			colTitle.Name = "colTitle";
			colTitle.Width = 150;
			// 
			// colTime
			// 
			colTime.HeaderText = "Time";
			colTime.MinimumWidth = 8;
			colTime.Name = "colTime";
			colTime.Width = 150;
			// 
			// colSchedule
			// 
			colSchedule.HeaderText = "Schedule";
			colSchedule.MinimumWidth = 8;
			colSchedule.Name = "colSchedule";
			colSchedule.Width = 150;
			// 
			// label9
			// 
			label9.AutoSize = true;
			label9.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label9.Location = new Point(1054, 443);
			label9.Name = "label9";
			label9.Size = new Size(121, 27);
			label9.TabIndex = 17;
			label9.Text = "Schedule:";
			// 
			// txtSchedule
			// 
			txtSchedule.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtSchedule.Location = new Point(1022, 483);
			txtSchedule.Name = "txtSchedule";
			txtSchedule.Size = new Size(191, 35);
			txtSchedule.TabIndex = 18;
			// 
			// btnAdd
			// 
			btnAdd.Location = new Point(919, 585);
			btnAdd.Name = "btnAdd";
			btnAdd.Size = new Size(147, 97);
			btnAdd.TabIndex = 19;
			btnAdd.Text = "ADD";
			btnAdd.UseVisualStyleBackColor = true;
			btnAdd.MouseClick += btnAdd_MouseClick;
			// 
			// btnPrint
			// 
			btnPrint.Location = new Point(919, 758);
			btnPrint.Name = "btnPrint";
			btnPrint.Size = new Size(147, 97);
			btnPrint.TabIndex = 20;
			btnPrint.Text = "PRINT";
			btnPrint.UseVisualStyleBackColor = true;
			btnPrint.MouseClick += btnPrint_MouseClick;
			// 
			// pictureBox1
			// 
			pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
			pictureBox1.Location = new Point(891, 12);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new Size(201, 200);
			pictureBox1.TabIndex = 21;
			pictureBox1.TabStop = false;
			// 
			// btnBack
			// 
			btnBack.Location = new Point(1111, 12);
			btnBack.Name = "btnBack";
			btnBack.Size = new Size(139, 90);
			btnBack.TabIndex = 22;
			btnBack.Text = "Back";
			btnBack.UseVisualStyleBackColor = true;
			btnBack.MouseClick += btnBack_MouseClick;
			// 
			// label10
			// 
			label10.AutoSize = true;
			label10.Font = new Font("Arial Black", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
			label10.Location = new Point(128, 91);
			label10.Name = "label10";
			label10.Size = new Size(690, 45);
			label10.TabIndex = 23;
			label10.Text = "ST. JOHN PAUL ll COLLEGE OF DAVAO";
			// 
			// Form3
			// 
			AutoScaleDimensions = new SizeF(10F, 25F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(1282, 867);
			Controls.Add(label10);
			Controls.Add(btnBack);
			Controls.Add(pictureBox1);
			Controls.Add(btnPrint);
			Controls.Add(btnAdd);
			Controls.Add(txtSchedule);
			Controls.Add(label9);
			Controls.Add(dataGridView1);
			Controls.Add(txtTime);
			Controls.Add(txtTitle);
			Controls.Add(txtSub);
			Controls.Add(txtOffer);
			Controls.Add(label8);
			Controls.Add(label7);
			Controls.Add(label6);
			Controls.Add(label5);
			Controls.Add(txtYear);
			Controls.Add(label4);
			Controls.Add(txtId);
			Controls.Add(label3);
			Controls.Add(txtCourse);
			Controls.Add(label2);
			Controls.Add(txtName);
			Controls.Add(label1);
			Name = "Form3";
			Text = "Form3";
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
		private TextBox txtName;
		private Label label2;
		private TextBox txtCourse;
		private Label label3;
		private TextBox txtId;
		private Label label4;
		private TextBox txtYear;
		private Label label5;
		private Label label6;
		private Label label7;
		private Label label8;
		private TextBox txtOffer;
		private TextBox txtSub;
		private TextBox txtTitle;
		private TextBox txtTime;
		private System.Drawing.Printing.PrintDocument printDocument1;
		private PrintDialog printDialog1;
		private DataGridView dataGridView1;
		private DataGridViewTextBoxColumn colOffer;
		private DataGridViewTextBoxColumn colSubject;
		private DataGridViewTextBoxColumn colTitle;
		private DataGridViewTextBoxColumn colTime;
		private DataGridViewTextBoxColumn colSchedule;
		private Label label9;
		private TextBox txtSchedule;
		private Button btnAdd;
		private Button btnPrint;
		private PictureBox pictureBox1;
		private Button btnBack;
		private Label label10;
	}
}