﻿namespace WinFormsApp1
{
	partial class Form2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
			BSITbtn = new Button();
			BSBAbtn = new Button();
			BSNbtn = new Button();
			BSCEbtn = new Button();
			BSEEbtn = new Button();
			BSCJbtn = new Button();
			BSHMbtn = new Button();
			BSEDbtn = new Button();
			SHSbtn = new Button();
			panel1 = new Panel();
			pictureBox1 = new PictureBox();
			btnEDIT = new Button();
			BSITPANEL = new Panel();
			txtFnameBSIT1 = new TextBox();
			label20 = new Label();
			txtEaddressBSIT = new TextBox();
			txtAddressBSIT = new TextBox();
			txtAgeBSIT = new TextBox();
			txtLnameBSIT = new TextBox();
			txtMnameBSIT = new TextBox();
			txtFnameBSIT = new TextBox();
			btnDeletebsit = new Button();
			ID1 = new TextBox();
			Add1 = new Button();
			New1 = new Button();
			btnUpdatebsit = new Button();
			dateTimePickerBSIT = new DateTimePicker();
			label27 = new Label();
			label26 = new Label();
			label25 = new Label();
			bsitGENDER = new ComboBox();
			label24 = new Label();
			label23 = new Label();
			label22 = new Label();
			label21 = new Label();
			label19 = new Label();
			label10 = new Label();
			listViewBSIT = new ListView();
			label1 = new Label();
			BSBAPANEL = new Panel();
			textAddressBSBA = new TextBox();
			bsbaAgetxt = new TextBox();
			cbGenderBSBA = new ComboBox();
			dateTimePicker1BSBA = new DateTimePicker();
			txtLnameBSBA = new TextBox();
			label37 = new Label();
			btnAddBSBA = new Button();
			btnNewBSBA = new Button();
			label36 = new Label();
			btnDeleteBSBA = new Button();
			txtEaddressBSBA = new TextBox();
			btnUpdateBSBA = new Button();
			label35 = new Label();
			label11 = new Label();
			listViewBSBA = new ListView();
			label2 = new Label();
			label34 = new Label();
			label29 = new Label();
			txtIDBSBA = new TextBox();
			label30 = new Label();
			label33 = new Label();
			label32 = new Label();
			txtFnameBSBA = new TextBox();
			label31 = new Label();
			txtMnameBSBA = new TextBox();
			BSNPANEL = new Panel();
			btnDeleteBSN = new Button();
			dateTimePickerBSN = new DateTimePicker();
			btnUpdateBSN = new Button();
			txtAddressBSN = new TextBox();
			btnAddBSN = new Button();
			label45 = new Label();
			btnNewBSN = new Button();
			txtMnameBSN = new TextBox();
			txtEaddressBSN = new TextBox();
			txtFnameBSN = new TextBox();
			label44 = new Label();
			label12 = new Label();
			listViewBSN = new ListView();
			label43 = new Label();
			label3 = new Label();
			cbGenderBSN = new ComboBox();
			label28 = new Label();
			label42 = new Label();
			txtIdBSN = new TextBox();
			txtAgeBSN = new TextBox();
			label38 = new Label();
			label41 = new Label();
			label39 = new Label();
			txtLnameBSN = new TextBox();
			label40 = new Label();
			BSCEPANEL = new Panel();
			btnBSCENew = new Button();
			txtLnameBSCE = new TextBox();
			btnDeleteBSCE = new Button();
			txtMnameBSCE = new TextBox();
			btnUpdateBSCE = new Button();
			txtFnameBSCE = new TextBox();
			label13 = new Label();
			btnAddBSCE = new Button();
			listViewBSCE = new ListView();
			dateTimePickerBSCE = new DateTimePicker();
			label4 = new Label();
			label54 = new Label();
			label46 = new Label();
			txtEaddressBSCE = new TextBox();
			txtIdBSCEE = new TextBox();
			label53 = new Label();
			label47 = new Label();
			txtAddressBSCE = new TextBox();
			label48 = new Label();
			label52 = new Label();
			label49 = new Label();
			cbGenderBSCE = new ComboBox();
			label51 = new Label();
			label50 = new Label();
			txtAgeBSCE = new TextBox();
			PANELBSEE = new Panel();
			btnAddbsee = new Button();
			btnNewbsee = new Button();
			btnDeleteBSEE = new Button();
			dateTimePickerBSEE = new DateTimePicker();
			btnUpdateBSEE = new Button();
			label63 = new Label();
			txtAddressBSEE = new TextBox();
			txtEaddressBSEE = new TextBox();
			label62 = new Label();
			txtLnameBSEE = new TextBox();
			label61 = new Label();
			txtMnameBSEE = new TextBox();
			label14 = new Label();
			cbGenderBSEE = new ComboBox();
			listView1BSEE = new ListView();
			label60 = new Label();
			label5 = new Label();
			txtAgeBSEE = new TextBox();
			label57 = new Label();
			label59 = new Label();
			label55 = new Label();
			txtIdBSEE = new TextBox();
			label56 = new Label();
			label58 = new Label();
			txtFnameBSEE = new TextBox();
			BSCJPANEL = new Panel();
			btnDeleteBSCJ = new Button();
			txtMnameBSCJ = new TextBox();
			btnUpdateBSCJ = new Button();
			txtFnameBSCJ = new TextBox();
			btnAddBSCJ = new Button();
			label15 = new Label();
			btnNewBSCJ = new Button();
			listViewBSCJ = new ListView();
			dateTimePickerBSCJ = new DateTimePicker();
			label6 = new Label();
			label72 = new Label();
			label64 = new Label();
			txtEaddressBSCJ = new TextBox();
			txtIdBSCJ = new TextBox();
			label71 = new Label();
			label65 = new Label();
			txtAddressBSCJ = new TextBox();
			label66 = new Label();
			label70 = new Label();
			label67 = new Label();
			cbGenderBSCJ = new ComboBox();
			txtLnameBSCJ = new TextBox();
			label69 = new Label();
			label68 = new Label();
			txtAgeBSCJ = new TextBox();
			BSHMPANEL = new Panel();
			btnDeleteBSHM = new Button();
			txtMnameBSHM = new TextBox();
			btnUpdateBSHM = new Button();
			txtFnameBSHM = new TextBox();
			btnAddBSHM = new Button();
			label16 = new Label();
			btnNewBSHM = new Button();
			listViewBSHM = new ListView();
			dateTimePickerBSHM = new DateTimePicker();
			label7 = new Label();
			label81 = new Label();
			label73 = new Label();
			txtEaddressBSHM = new TextBox();
			txtIdBSHM = new TextBox();
			label80 = new Label();
			label74 = new Label();
			txtAddressBSHM = new TextBox();
			label75 = new Label();
			label79 = new Label();
			label76 = new Label();
			cbGenderBSHM = new ComboBox();
			txtLnameBSHM = new TextBox();
			label78 = new Label();
			label77 = new Label();
			txtAgeBSHM = new TextBox();
			BSEDPANEL = new Panel();
			btnDeleteBSED = new Button();
			txtMnameBSED = new TextBox();
			btnUpdateBSED = new Button();
			txtFnameBSED = new TextBox();
			btnAddBSED = new Button();
			label17 = new Label();
			btnNewBSED = new Button();
			listViewBSED = new ListView();
			dateTimePickerBSED = new DateTimePicker();
			label8 = new Label();
			label90 = new Label();
			label82 = new Label();
			label89 = new Label();
			txtEaddressBSED = new TextBox();
			txtIdBSED = new TextBox();
			label83 = new Label();
			txtAddressBSED = new TextBox();
			label84 = new Label();
			label88 = new Label();
			label85 = new Label();
			cbGenderBSED = new ComboBox();
			txtLnameBSED = new TextBox();
			label87 = new Label();
			label86 = new Label();
			txtAgeBSED = new TextBox();
			SHSPANEL = new Panel();
			btnDeleteSHS = new Button();
			txtMnameSHS = new TextBox();
			btnUpdateSHS = new Button();
			txtFnameSHS = new TextBox();
			btnAddSHS = new Button();
			label18 = new Label();
			btnNewSHS = new Button();
			listViewSHS = new ListView();
			dateTimePickerSHS = new DateTimePicker();
			label9 = new Label();
			label99 = new Label();
			label91 = new Label();
			txtEaddressSHS = new TextBox();
			txtIdSHS = new TextBox();
			label98 = new Label();
			label92 = new Label();
			txtAddressSHS = new TextBox();
			label93 = new Label();
			label97 = new Label();
			label94 = new Label();
			cbGenderSHS = new ComboBox();
			txtLnameSHS = new TextBox();
			label96 = new Label();
			label95 = new Label();
			txtAgeSHS = new TextBox();
			btnLogout = new Button();
			btnCourses = new Button();
			panel2 = new Panel();
			panel3 = new Panel();
			panel4 = new Panel();
			btnERC = new Button();
			btnSCHEDULE = new Button();
			PANELSDBSIT = new Panel();
			label100 = new Label();
			listViewSDBSIT = new ListView();
			panel5 = new Panel();
			btnSDBSIT = new Button();
			btnSDSHS = new Button();
			btnSDBSBA = new Button();
			btnSDBSED = new Button();
			btnSDBSN = new Button();
			btnSDBSHM = new Button();
			btnSDBSCE = new Button();
			btnSDBSCJ = new Button();
			btnSDBSEE = new Button();
			PANELSDBSN = new Panel();
			label101 = new Label();
			listViewSDBSN = new ListView();
			panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			BSITPANEL.SuspendLayout();
			BSBAPANEL.SuspendLayout();
			BSNPANEL.SuspendLayout();
			BSCEPANEL.SuspendLayout();
			PANELBSEE.SuspendLayout();
			BSCJPANEL.SuspendLayout();
			BSHMPANEL.SuspendLayout();
			BSEDPANEL.SuspendLayout();
			SHSPANEL.SuspendLayout();
			panel4.SuspendLayout();
			PANELSDBSIT.SuspendLayout();
			panel5.SuspendLayout();
			PANELSDBSN.SuspendLayout();
			SuspendLayout();
			// 
			// BSITbtn
			// 
			BSITbtn.BackColor = Color.DarkViolet;
			BSITbtn.Location = new Point(37, 22);
			BSITbtn.Name = "BSITbtn";
			BSITbtn.Size = new Size(125, 46);
			BSITbtn.TabIndex = 0;
			BSITbtn.Text = "BSIT";
			BSITbtn.UseVisualStyleBackColor = false;
			BSITbtn.Click += BSITbtn_Click;
			BSITbtn.MouseClick += BSITbtn_MouseClick;
			// 
			// BSBAbtn
			// 
			BSBAbtn.BackColor = Color.Yellow;
			BSBAbtn.Location = new Point(180, 22);
			BSBAbtn.Name = "BSBAbtn";
			BSBAbtn.Size = new Size(125, 46);
			BSBAbtn.TabIndex = 1;
			BSBAbtn.Text = "BSBA";
			BSBAbtn.UseVisualStyleBackColor = false;
			BSBAbtn.MouseClick += BSBAbtn_MouseClick;
			// 
			// BSNbtn
			// 
			BSNbtn.BackColor = Color.Green;
			BSNbtn.Location = new Point(326, 22);
			BSNbtn.Name = "BSNbtn";
			BSNbtn.Size = new Size(125, 46);
			BSNbtn.TabIndex = 2;
			BSNbtn.Text = "BSN";
			BSNbtn.UseVisualStyleBackColor = false;
			BSNbtn.MouseClick += BSNbtn_MouseClick;
			// 
			// BSCEbtn
			// 
			BSCEbtn.BackColor = Color.Orange;
			BSCEbtn.Location = new Point(483, 22);
			BSCEbtn.Name = "BSCEbtn";
			BSCEbtn.Size = new Size(125, 46);
			BSCEbtn.TabIndex = 3;
			BSCEbtn.Text = "BSCE";
			BSCEbtn.UseVisualStyleBackColor = false;
			BSCEbtn.MouseClick += BSCEbtn_MouseClick;
			// 
			// BSEEbtn
			// 
			BSEEbtn.BackColor = Color.Blue;
			BSEEbtn.Location = new Point(638, 22);
			BSEEbtn.Name = "BSEEbtn";
			BSEEbtn.Size = new Size(125, 46);
			BSEEbtn.TabIndex = 4;
			BSEEbtn.Text = "BSEE";
			BSEEbtn.UseVisualStyleBackColor = false;
			BSEEbtn.MouseClick += BSEEbtn_MouseClick;
			// 
			// BSCJbtn
			// 
			BSCJbtn.BackColor = Color.Red;
			BSCJbtn.Location = new Point(792, 22);
			BSCJbtn.Name = "BSCJbtn";
			BSCJbtn.Size = new Size(125, 46);
			BSCJbtn.TabIndex = 5;
			BSCJbtn.Text = "BSCJ";
			BSCJbtn.UseVisualStyleBackColor = false;
			BSCJbtn.MouseClick += BSCJbtn_MouseClick;
			// 
			// BSHMbtn
			// 
			BSHMbtn.BackColor = Color.Pink;
			BSHMbtn.Location = new Point(943, 22);
			BSHMbtn.Name = "BSHMbtn";
			BSHMbtn.Size = new Size(125, 46);
			BSHMbtn.TabIndex = 6;
			BSHMbtn.Text = "BSHM";
			BSHMbtn.UseVisualStyleBackColor = false;
			BSHMbtn.MouseClick += BSHMbtn_MouseClick;
			// 
			// BSEDbtn
			// 
			BSEDbtn.BackColor = Color.DodgerBlue;
			BSEDbtn.Location = new Point(1103, 22);
			BSEDbtn.Name = "BSEDbtn";
			BSEDbtn.Size = new Size(125, 46);
			BSEDbtn.TabIndex = 7;
			BSEDbtn.Text = "BSED";
			BSEDbtn.UseVisualStyleBackColor = false;
			BSEDbtn.MouseClick += BSEDbtn_MouseClick;
			// 
			// SHSbtn
			// 
			SHSbtn.BackColor = Color.Peru;
			SHSbtn.Location = new Point(1263, 22);
			SHSbtn.Name = "SHSbtn";
			SHSbtn.Size = new Size(125, 46);
			SHSbtn.TabIndex = 8;
			SHSbtn.Text = "SHS";
			SHSbtn.UseVisualStyleBackColor = false;
			SHSbtn.Click += SHSbtn_Click;
			SHSbtn.MouseClick += SHSbtn_MouseClick;
			// 
			// panel1
			// 
			panel1.BackColor = SystemColors.ActiveCaption;
			panel1.Controls.Add(BSITbtn);
			panel1.Controls.Add(SHSbtn);
			panel1.Controls.Add(BSBAbtn);
			panel1.Controls.Add(BSEDbtn);
			panel1.Controls.Add(BSNbtn);
			panel1.Controls.Add(BSHMbtn);
			panel1.Controls.Add(BSCEbtn);
			panel1.Controls.Add(BSCJbtn);
			panel1.Controls.Add(BSEEbtn);
			panel1.Location = new Point(176, -1);
			panel1.Name = "panel1";
			panel1.Size = new Size(1402, 95);
			panel1.TabIndex = 9;
			panel1.Visible = false;
			// 
			// pictureBox1
			// 
			pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
			pictureBox1.Location = new Point(-8, -1);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new Size(184, 95);
			pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
			pictureBox1.TabIndex = 21;
			pictureBox1.TabStop = false;
			pictureBox1.MouseClick += pictureBox1_MouseClick;
			// 
			// btnEDIT
			// 
			btnEDIT.BackColor = Color.LimeGreen;
			btnEDIT.Enabled = false;
			btnEDIT.ForeColor = Color.MintCream;
			btnEDIT.Location = new Point(11, 84);
			btnEDIT.Name = "btnEDIT";
			btnEDIT.Size = new Size(139, 57);
			btnEDIT.TabIndex = 10;
			btnEDIT.Text = "EDIT";
			btnEDIT.UseVisualStyleBackColor = false;
			btnEDIT.MouseClick += btnEDIT_MouseClick;
			// 
			// BSITPANEL
			// 
			BSITPANEL.BackColor = SystemColors.ActiveCaption;
			BSITPANEL.Controls.Add(txtFnameBSIT1);
			BSITPANEL.Controls.Add(label20);
			BSITPANEL.Controls.Add(txtEaddressBSIT);
			BSITPANEL.Controls.Add(txtAddressBSIT);
			BSITPANEL.Controls.Add(txtAgeBSIT);
			BSITPANEL.Controls.Add(txtLnameBSIT);
			BSITPANEL.Controls.Add(txtMnameBSIT);
			BSITPANEL.Controls.Add(txtFnameBSIT);
			BSITPANEL.Controls.Add(btnDeletebsit);
			BSITPANEL.Controls.Add(ID1);
			BSITPANEL.Controls.Add(Add1);
			BSITPANEL.Controls.Add(New1);
			BSITPANEL.Controls.Add(btnUpdatebsit);
			BSITPANEL.Controls.Add(dateTimePickerBSIT);
			BSITPANEL.Controls.Add(label27);
			BSITPANEL.Controls.Add(label26);
			BSITPANEL.Controls.Add(label25);
			BSITPANEL.Controls.Add(bsitGENDER);
			BSITPANEL.Controls.Add(label24);
			BSITPANEL.Controls.Add(label23);
			BSITPANEL.Controls.Add(label22);
			BSITPANEL.Controls.Add(label21);
			BSITPANEL.Controls.Add(label19);
			BSITPANEL.Controls.Add(label10);
			BSITPANEL.Controls.Add(listViewBSIT);
			BSITPANEL.Controls.Add(label1);
			BSITPANEL.Location = new Point(175, 100);
			BSITPANEL.Name = "BSITPANEL";
			BSITPANEL.Size = new Size(1405, 593);
			BSITPANEL.TabIndex = 11;
			BSITPANEL.Visible = false;
			// 
			// txtFnameBSIT1
			// 
			txtFnameBSIT1.Enabled = false;
			txtFnameBSIT1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtFnameBSIT1.Location = new Point(118, 126);
			txtFnameBSIT1.Name = "txtFnameBSIT1";
			txtFnameBSIT1.Size = new Size(169, 28);
			txtFnameBSIT1.TabIndex = 43;
			// 
			// label20
			// 
			label20.AutoSize = true;
			label20.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label20.Location = new Point(-1, 126);
			label20.Name = "label20";
			label20.Size = new Size(113, 25);
			label20.TabIndex = 36;
			label20.Text = "Firstname:";
			// 
			// txtEaddressBSIT
			// 
			txtEaddressBSIT.Enabled = false;
			txtEaddressBSIT.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtEaddressBSIT.Location = new Point(3, 357);
			txtEaddressBSIT.Name = "txtEaddressBSIT";
			txtEaddressBSIT.Size = new Size(295, 28);
			txtEaddressBSIT.TabIndex = 39;
			// 
			// txtAddressBSIT
			// 
			txtAddressBSIT.Enabled = false;
			txtAddressBSIT.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAddressBSIT.Location = new Point(98, 298);
			txtAddressBSIT.Name = "txtAddressBSIT";
			txtAddressBSIT.Size = new Size(200, 28);
			txtAddressBSIT.TabIndex = 38;
			// 
			// txtAgeBSIT
			// 
			txtAgeBSIT.Enabled = false;
			txtAgeBSIT.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAgeBSIT.Location = new Point(57, 225);
			txtAgeBSIT.Name = "txtAgeBSIT";
			txtAgeBSIT.Size = new Size(39, 28);
			txtAgeBSIT.TabIndex = 38;
			// 
			// txtLnameBSIT
			// 
			txtLnameBSIT.Enabled = false;
			txtLnameBSIT.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtLnameBSIT.Location = new Point(118, 191);
			txtLnameBSIT.Name = "txtLnameBSIT";
			txtLnameBSIT.Size = new Size(169, 28);
			txtLnameBSIT.TabIndex = 37;
			// 
			// txtMnameBSIT
			// 
			txtMnameBSIT.Enabled = false;
			txtMnameBSIT.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtMnameBSIT.Location = new Point(137, 157);
			txtMnameBSIT.Name = "txtMnameBSIT";
			txtMnameBSIT.Size = new Size(150, 28);
			txtMnameBSIT.TabIndex = 36;
			// 
			// txtFnameBSIT
			// 
			txtFnameBSIT.Enabled = false;
			txtFnameBSIT.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtFnameBSIT.Location = new Point(57, 225);
			txtFnameBSIT.Name = "txtFnameBSIT";
			txtFnameBSIT.Size = new Size(39, 28);
			txtFnameBSIT.TabIndex = 44;
			// 
			// btnDeletebsit
			// 
			btnDeletebsit.BackColor = SystemColors.ButtonShadow;
			btnDeletebsit.Enabled = false;
			btnDeletebsit.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnDeletebsit.ForeColor = Color.MintCream;
			btnDeletebsit.Location = new Point(158, 521);
			btnDeletebsit.Name = "btnDeletebsit";
			btnDeletebsit.Size = new Size(140, 59);
			btnDeletebsit.TabIndex = 32;
			btnDeletebsit.Text = "DELETE";
			btnDeletebsit.UseVisualStyleBackColor = false;
			btnDeletebsit.MouseClick += btnDeletebsit_MouseClick;
			// 
			// ID1
			// 
			ID1.Enabled = false;
			ID1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			ID1.Location = new Point(55, 86);
			ID1.Name = "ID1";
			ID1.Size = new Size(136, 28);
			ID1.TabIndex = 34;
			// 
			// Add1
			// 
			Add1.BackColor = SystemColors.ButtonShadow;
			Add1.Enabled = false;
			Add1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			Add1.ForeColor = Color.MintCream;
			Add1.Location = new Point(158, 456);
			Add1.Name = "Add1";
			Add1.Size = new Size(140, 59);
			Add1.TabIndex = 33;
			Add1.Text = "ADD";
			Add1.UseVisualStyleBackColor = false;
			Add1.MouseClick += Add1_MouseClick;
			// 
			// New1
			// 
			New1.BackColor = SystemColors.ButtonShadow;
			New1.Enabled = false;
			New1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			New1.ForeColor = Color.MintCream;
			New1.Location = new Point(3, 456);
			New1.Name = "New1";
			New1.Size = new Size(140, 59);
			New1.TabIndex = 32;
			New1.Text = "NEW";
			New1.UseVisualStyleBackColor = false;
			New1.MouseClick += New1_MouseClick;
			// 
			// btnUpdatebsit
			// 
			btnUpdatebsit.BackColor = SystemColors.ButtonShadow;
			btnUpdatebsit.Enabled = false;
			btnUpdatebsit.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnUpdatebsit.ForeColor = Color.MintCream;
			btnUpdatebsit.Location = new Point(3, 521);
			btnUpdatebsit.Name = "btnUpdatebsit";
			btnUpdatebsit.Size = new Size(140, 59);
			btnUpdatebsit.TabIndex = 31;
			btnUpdatebsit.Text = "UPDATE";
			btnUpdatebsit.UseVisualStyleBackColor = false;
			btnUpdatebsit.MouseClick += btnUpdatebsit_MouseClick;
			// 
			// dateTimePickerBSIT
			// 
			dateTimePickerBSIT.Enabled = false;
			dateTimePickerBSIT.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			dateTimePickerBSIT.Location = new Point(3, 419);
			dateTimePickerBSIT.Name = "dateTimePickerBSIT";
			dateTimePickerBSIT.Size = new Size(300, 28);
			dateTimePickerBSIT.TabIndex = 29;
			// 
			// label27
			// 
			label27.AutoSize = true;
			label27.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label27.Location = new Point(3, 391);
			label27.Name = "label27";
			label27.Size = new Size(140, 25);
			label27.TabIndex = 28;
			label27.Text = "Date of Birth:";
			// 
			// label26
			// 
			label26.AutoSize = true;
			label26.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label26.Location = new Point(3, 329);
			label26.Name = "label26";
			label26.Size = new Size(157, 25);
			label26.TabIndex = 27;
			label26.Text = "Email Address:";
			// 
			// label25
			// 
			label25.AutoSize = true;
			label25.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label25.Location = new Point(0, 298);
			label25.Name = "label25";
			label25.Size = new Size(98, 25);
			label25.TabIndex = 26;
			label25.Text = "Address:";
			// 
			// bsitGENDER
			// 
			bsitGENDER.Enabled = false;
			bsitGENDER.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			bsitGENDER.FormattingEnabled = true;
			bsitGENDER.Items.AddRange(new object[] { "MALE", "FEMALE" });
			bsitGENDER.Location = new Point(98, 256);
			bsitGENDER.Name = "bsitGENDER";
			bsitGENDER.Size = new Size(108, 29);
			bsitGENDER.TabIndex = 46;
			// 
			// label24
			// 
			label24.AutoSize = true;
			label24.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label24.Location = new Point(3, 259);
			label24.Name = "label24";
			label24.Size = new Size(89, 25);
			label24.TabIndex = 25;
			label24.Text = "Gender:";
			// 
			// label23
			// 
			label23.AutoSize = true;
			label23.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label23.Location = new Point(1, 225);
			label23.Name = "label23";
			label23.Size = new Size(57, 25);
			label23.TabIndex = 24;
			label23.Text = "Age:";
			// 
			// label22
			// 
			label22.AutoSize = true;
			label22.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label22.Location = new Point(0, 191);
			label22.Name = "label22";
			label22.Size = new Size(112, 25);
			label22.TabIndex = 23;
			label22.Text = "Lastname:";
			// 
			// label21
			// 
			label21.AutoSize = true;
			label21.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label21.Location = new Point(0, 157);
			label21.Name = "label21";
			label21.Size = new Size(135, 25);
			label21.TabIndex = 22;
			label21.Text = "Middlename:";
			// 
			// label19
			// 
			label19.AutoSize = true;
			label19.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label19.Location = new Point(11, 89);
			label19.Name = "label19";
			label19.Size = new Size(40, 25);
			label19.TabIndex = 4;
			label19.Text = "ID:";
			// 
			// label10
			// 
			label10.AutoSize = true;
			label10.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label10.Location = new Point(81, 31);
			label10.Name = "label10";
			label10.Size = new Size(157, 32);
			label10.TabIndex = 2;
			label10.Text = "REGISTER";
			// 
			// listViewBSIT
			// 
			listViewBSIT.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			listViewBSIT.Location = new Point(307, 56);
			listViewBSIT.Name = "listViewBSIT";
			listViewBSIT.Size = new Size(1083, 521);
			listViewBSIT.TabIndex = 1;
			listViewBSIT.UseCompatibleStateImageBehavior = false;
			listViewBSIT.View = View.Details;
			listViewBSIT.MouseClick += listViewBSIT_MouseClick;
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label1.Location = new Point(790, 21);
			label1.Name = "label1";
			label1.Size = new Size(76, 32);
			label1.TabIndex = 0;
			label1.Text = "BSIT";
			// 
			// BSBAPANEL
			// 
			BSBAPANEL.BackColor = SystemColors.ActiveCaption;
			BSBAPANEL.Controls.Add(textAddressBSBA);
			BSBAPANEL.Controls.Add(bsbaAgetxt);
			BSBAPANEL.Controls.Add(cbGenderBSBA);
			BSBAPANEL.Controls.Add(dateTimePicker1BSBA);
			BSBAPANEL.Controls.Add(txtLnameBSBA);
			BSBAPANEL.Controls.Add(label37);
			BSBAPANEL.Controls.Add(btnAddBSBA);
			BSBAPANEL.Controls.Add(btnNewBSBA);
			BSBAPANEL.Controls.Add(label36);
			BSBAPANEL.Controls.Add(btnDeleteBSBA);
			BSBAPANEL.Controls.Add(txtEaddressBSBA);
			BSBAPANEL.Controls.Add(btnUpdateBSBA);
			BSBAPANEL.Controls.Add(label35);
			BSBAPANEL.Controls.Add(label11);
			BSBAPANEL.Controls.Add(listViewBSBA);
			BSBAPANEL.Controls.Add(label2);
			BSBAPANEL.Controls.Add(label34);
			BSBAPANEL.Controls.Add(label29);
			BSBAPANEL.Controls.Add(txtIDBSBA);
			BSBAPANEL.Controls.Add(label30);
			BSBAPANEL.Controls.Add(label33);
			BSBAPANEL.Controls.Add(label32);
			BSBAPANEL.Controls.Add(txtFnameBSBA);
			BSBAPANEL.Controls.Add(label31);
			BSBAPANEL.Controls.Add(txtMnameBSBA);
			BSBAPANEL.Location = new Point(174, 100);
			BSBAPANEL.Name = "BSBAPANEL";
			BSBAPANEL.Size = new Size(1406, 593);
			BSBAPANEL.TabIndex = 12;
			BSBAPANEL.Visible = false;
			// 
			// textAddressBSBA
			// 
			textAddressBSBA.Enabled = false;
			textAddressBSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			textAddressBSBA.Location = new Point(98, 298);
			textAddressBSBA.Name = "textAddressBSBA";
			textAddressBSBA.Size = new Size(200, 28);
			textAddressBSBA.TabIndex = 43;
			// 
			// bsbaAgetxt
			// 
			bsbaAgetxt.Enabled = false;
			bsbaAgetxt.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			bsbaAgetxt.Location = new Point(59, 225);
			bsbaAgetxt.Name = "bsbaAgetxt";
			bsbaAgetxt.Size = new Size(39, 28);
			bsbaAgetxt.TabIndex = 43;
			// 
			// cbGenderBSBA
			// 
			cbGenderBSBA.Enabled = false;
			cbGenderBSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			cbGenderBSBA.FormattingEnabled = true;
			cbGenderBSBA.Items.AddRange(new object[] { "MALE", "FEMALE" });
			cbGenderBSBA.Location = new Point(98, 259);
			cbGenderBSBA.Name = "cbGenderBSBA";
			cbGenderBSBA.Size = new Size(108, 29);
			cbGenderBSBA.TabIndex = 47;
			// 
			// dateTimePicker1BSBA
			// 
			dateTimePicker1BSBA.Enabled = false;
			dateTimePicker1BSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			dateTimePicker1BSBA.Location = new Point(3, 419);
			dateTimePicker1BSBA.Name = "dateTimePicker1BSBA";
			dateTimePicker1BSBA.Size = new Size(300, 28);
			dateTimePicker1BSBA.TabIndex = 52;
			// 
			// txtLnameBSBA
			// 
			txtLnameBSBA.Enabled = false;
			txtLnameBSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtLnameBSBA.Location = new Point(118, 191);
			txtLnameBSBA.Name = "txtLnameBSBA";
			txtLnameBSBA.Size = new Size(169, 28);
			txtLnameBSBA.TabIndex = 55;
			// 
			// label37
			// 
			label37.AutoSize = true;
			label37.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label37.Location = new Point(3, 391);
			label37.Name = "label37";
			label37.Size = new Size(140, 25);
			label37.TabIndex = 50;
			label37.Text = "Date of Birth:";
			// 
			// btnAddBSBA
			// 
			btnAddBSBA.BackColor = SystemColors.ButtonShadow;
			btnAddBSBA.Enabled = false;
			btnAddBSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnAddBSBA.ForeColor = Color.MintCream;
			btnAddBSBA.Location = new Point(158, 456);
			btnAddBSBA.Name = "btnAddBSBA";
			btnAddBSBA.Size = new Size(140, 59);
			btnAddBSBA.TabIndex = 56;
			btnAddBSBA.Text = "ADD";
			btnAddBSBA.UseVisualStyleBackColor = false;
			btnAddBSBA.MouseClick += btnAddBSBA_MouseClick;
			// 
			// btnNewBSBA
			// 
			btnNewBSBA.BackColor = SystemColors.ButtonShadow;
			btnNewBSBA.Enabled = false;
			btnNewBSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnNewBSBA.ForeColor = Color.MintCream;
			btnNewBSBA.Location = new Point(3, 456);
			btnNewBSBA.Name = "btnNewBSBA";
			btnNewBSBA.Size = new Size(140, 59);
			btnNewBSBA.TabIndex = 53;
			btnNewBSBA.Text = "NEW";
			btnNewBSBA.UseVisualStyleBackColor = false;
			btnNewBSBA.MouseClick += btnNewBSBA_MouseClick;
			// 
			// label36
			// 
			label36.AutoSize = true;
			label36.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label36.Location = new Point(3, 329);
			label36.Name = "label36";
			label36.Size = new Size(157, 25);
			label36.TabIndex = 49;
			label36.Text = "Email Address:";
			// 
			// btnDeleteBSBA
			// 
			btnDeleteBSBA.BackColor = SystemColors.ButtonShadow;
			btnDeleteBSBA.Enabled = false;
			btnDeleteBSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnDeleteBSBA.ForeColor = Color.MintCream;
			btnDeleteBSBA.Location = new Point(158, 521);
			btnDeleteBSBA.Name = "btnDeleteBSBA";
			btnDeleteBSBA.Size = new Size(140, 59);
			btnDeleteBSBA.TabIndex = 57;
			btnDeleteBSBA.Text = "DELETE";
			btnDeleteBSBA.UseVisualStyleBackColor = false;
			btnDeleteBSBA.MouseClick += btnDeleteBSBA_MouseClick;
			// 
			// txtEaddressBSBA
			// 
			txtEaddressBSBA.Enabled = false;
			txtEaddressBSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtEaddressBSBA.Location = new Point(6, 357);
			txtEaddressBSBA.Name = "txtEaddressBSBA";
			txtEaddressBSBA.Size = new Size(281, 28);
			txtEaddressBSBA.TabIndex = 48;
			// 
			// btnUpdateBSBA
			// 
			btnUpdateBSBA.BackColor = SystemColors.ButtonShadow;
			btnUpdateBSBA.Enabled = false;
			btnUpdateBSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnUpdateBSBA.ForeColor = Color.MintCream;
			btnUpdateBSBA.Location = new Point(3, 521);
			btnUpdateBSBA.Name = "btnUpdateBSBA";
			btnUpdateBSBA.Size = new Size(140, 59);
			btnUpdateBSBA.TabIndex = 55;
			btnUpdateBSBA.Text = "UPDATE";
			btnUpdateBSBA.UseVisualStyleBackColor = false;
			btnUpdateBSBA.MouseClick += btnUpdateBSBA_MouseClick;
			// 
			// label35
			// 
			label35.AutoSize = true;
			label35.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label35.Location = new Point(0, 298);
			label35.Name = "label35";
			label35.Size = new Size(98, 25);
			label35.TabIndex = 47;
			label35.Text = "Address:";
			// 
			// label11
			// 
			label11.AutoSize = true;
			label11.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label11.Location = new Point(81, 31);
			label11.Name = "label11";
			label11.Size = new Size(157, 32);
			label11.TabIndex = 21;
			label11.Text = "REGISTER";
			// 
			// listViewBSBA
			// 
			listViewBSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			listViewBSBA.Location = new Point(307, 56);
			listViewBSBA.Name = "listViewBSBA";
			listViewBSBA.Size = new Size(1083, 521);
			listViewBSBA.TabIndex = 1;
			listViewBSBA.UseCompatibleStateImageBehavior = false;
			listViewBSBA.View = View.Details;
			listViewBSBA.MouseClick += listViewBSBA_MouseClick;
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label2.Location = new Point(790, 21);
			label2.Name = "label2";
			label2.Size = new Size(90, 32);
			label2.TabIndex = 0;
			label2.Text = "BSBA";
			// 
			// label34
			// 
			label34.AutoSize = true;
			label34.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label34.Location = new Point(3, 259);
			label34.Name = "label34";
			label34.Size = new Size(89, 25);
			label34.TabIndex = 45;
			label34.Text = "Gender:";
			// 
			// label29
			// 
			label29.AutoSize = true;
			label29.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label29.Location = new Point(11, 89);
			label29.Name = "label29";
			label29.Size = new Size(40, 25);
			label29.TabIndex = 23;
			label29.Text = "ID:";
			// 
			// txtIDBSBA
			// 
			txtIDBSBA.Enabled = false;
			txtIDBSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtIDBSBA.Location = new Point(55, 86);
			txtIDBSBA.Name = "txtIDBSBA";
			txtIDBSBA.Size = new Size(136, 28);
			txtIDBSBA.TabIndex = 35;
			// 
			// label30
			// 
			label30.AutoSize = true;
			label30.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label30.Location = new Point(0, 126);
			label30.Name = "label30";
			label30.Size = new Size(113, 25);
			label30.TabIndex = 37;
			label30.Text = "Firstname:";
			// 
			// label33
			// 
			label33.AutoSize = true;
			label33.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label33.Location = new Point(1, 225);
			label33.Name = "label33";
			label33.Size = new Size(57, 25);
			label33.TabIndex = 43;
			label33.Text = "Age:";
			// 
			// label32
			// 
			label32.AutoSize = true;
			label32.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label32.Location = new Point(0, 191);
			label32.Name = "label32";
			label32.Size = new Size(112, 25);
			label32.TabIndex = 41;
			label32.Text = "Lastname:";
			// 
			// txtFnameBSBA
			// 
			txtFnameBSBA.Enabled = false;
			txtFnameBSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtFnameBSBA.Location = new Point(118, 126);
			txtFnameBSBA.Name = "txtFnameBSBA";
			txtFnameBSBA.Size = new Size(169, 28);
			txtFnameBSBA.TabIndex = 38;
			// 
			// label31
			// 
			label31.AutoSize = true;
			label31.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label31.Location = new Point(0, 157);
			label31.Name = "label31";
			label31.Size = new Size(135, 25);
			label31.TabIndex = 39;
			label31.Text = "Middlename:";
			// 
			// txtMnameBSBA
			// 
			txtMnameBSBA.Enabled = false;
			txtMnameBSBA.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtMnameBSBA.Location = new Point(137, 157);
			txtMnameBSBA.Name = "txtMnameBSBA";
			txtMnameBSBA.Size = new Size(150, 28);
			txtMnameBSBA.TabIndex = 40;
			// 
			// BSNPANEL
			// 
			BSNPANEL.BackColor = SystemColors.ActiveCaption;
			BSNPANEL.Controls.Add(btnDeleteBSN);
			BSNPANEL.Controls.Add(dateTimePickerBSN);
			BSNPANEL.Controls.Add(btnUpdateBSN);
			BSNPANEL.Controls.Add(txtAddressBSN);
			BSNPANEL.Controls.Add(btnAddBSN);
			BSNPANEL.Controls.Add(label45);
			BSNPANEL.Controls.Add(btnNewBSN);
			BSNPANEL.Controls.Add(txtMnameBSN);
			BSNPANEL.Controls.Add(txtEaddressBSN);
			BSNPANEL.Controls.Add(txtFnameBSN);
			BSNPANEL.Controls.Add(label44);
			BSNPANEL.Controls.Add(label12);
			BSNPANEL.Controls.Add(listViewBSN);
			BSNPANEL.Controls.Add(label43);
			BSNPANEL.Controls.Add(label3);
			BSNPANEL.Controls.Add(cbGenderBSN);
			BSNPANEL.Controls.Add(label28);
			BSNPANEL.Controls.Add(label42);
			BSNPANEL.Controls.Add(txtIdBSN);
			BSNPANEL.Controls.Add(txtAgeBSN);
			BSNPANEL.Controls.Add(label38);
			BSNPANEL.Controls.Add(label41);
			BSNPANEL.Controls.Add(label39);
			BSNPANEL.Controls.Add(txtLnameBSN);
			BSNPANEL.Controls.Add(label40);
			BSNPANEL.Location = new Point(174, 100);
			BSNPANEL.Name = "BSNPANEL";
			BSNPANEL.Size = new Size(1406, 593);
			BSNPANEL.TabIndex = 13;
			BSNPANEL.Visible = false;
			// 
			// btnDeleteBSN
			// 
			btnDeleteBSN.BackColor = SystemColors.ButtonShadow;
			btnDeleteBSN.Enabled = false;
			btnDeleteBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnDeleteBSN.ForeColor = Color.MintCream;
			btnDeleteBSN.Location = new Point(158, 521);
			btnDeleteBSN.Name = "btnDeleteBSN";
			btnDeleteBSN.Size = new Size(140, 59);
			btnDeleteBSN.TabIndex = 59;
			btnDeleteBSN.Text = "DELETE";
			btnDeleteBSN.UseVisualStyleBackColor = false;
			btnDeleteBSN.MouseClick += btnDeleteBSN_MouseClick;
			// 
			// dateTimePickerBSN
			// 
			dateTimePickerBSN.Enabled = false;
			dateTimePickerBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			dateTimePickerBSN.Location = new Point(3, 419);
			dateTimePickerBSN.Name = "dateTimePickerBSN";
			dateTimePickerBSN.Size = new Size(300, 28);
			dateTimePickerBSN.TabIndex = 65;
			// 
			// btnUpdateBSN
			// 
			btnUpdateBSN.BackColor = SystemColors.ButtonShadow;
			btnUpdateBSN.Enabled = false;
			btnUpdateBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnUpdateBSN.ForeColor = Color.MintCream;
			btnUpdateBSN.Location = new Point(3, 521);
			btnUpdateBSN.Name = "btnUpdateBSN";
			btnUpdateBSN.Size = new Size(140, 59);
			btnUpdateBSN.TabIndex = 58;
			btnUpdateBSN.Text = "UPDATE";
			btnUpdateBSN.UseVisualStyleBackColor = false;
			btnUpdateBSN.MouseClick += btnUpdateBSN_MouseClick;
			// 
			// txtAddressBSN
			// 
			txtAddressBSN.Enabled = false;
			txtAddressBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAddressBSN.Location = new Point(98, 298);
			txtAddressBSN.Name = "txtAddressBSN";
			txtAddressBSN.Size = new Size(200, 28);
			txtAddressBSN.TabIndex = 66;
			// 
			// btnAddBSN
			// 
			btnAddBSN.BackColor = SystemColors.ButtonShadow;
			btnAddBSN.Enabled = false;
			btnAddBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnAddBSN.ForeColor = Color.MintCream;
			btnAddBSN.Location = new Point(158, 456);
			btnAddBSN.Name = "btnAddBSN";
			btnAddBSN.Size = new Size(140, 59);
			btnAddBSN.TabIndex = 57;
			btnAddBSN.Text = "ADD";
			btnAddBSN.UseVisualStyleBackColor = false;
			btnAddBSN.MouseClick += btnAddBSN_MouseClick;
			// 
			// label45
			// 
			label45.AutoSize = true;
			label45.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label45.Location = new Point(3, 391);
			label45.Name = "label45";
			label45.Size = new Size(140, 25);
			label45.TabIndex = 64;
			label45.Text = "Date of Birth:";
			// 
			// btnNewBSN
			// 
			btnNewBSN.BackColor = SystemColors.ButtonShadow;
			btnNewBSN.Enabled = false;
			btnNewBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnNewBSN.ForeColor = Color.MintCream;
			btnNewBSN.Location = new Point(3, 456);
			btnNewBSN.Name = "btnNewBSN";
			btnNewBSN.Size = new Size(140, 59);
			btnNewBSN.TabIndex = 54;
			btnNewBSN.Text = "NEW";
			btnNewBSN.UseVisualStyleBackColor = false;
			btnNewBSN.MouseClick += btnNewBSN_MouseClick;
			// 
			// txtMnameBSN
			// 
			txtMnameBSN.Enabled = false;
			txtMnameBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtMnameBSN.Location = new Point(127, 157);
			txtMnameBSN.Name = "txtMnameBSN";
			txtMnameBSN.Size = new Size(150, 28);
			txtMnameBSN.TabIndex = 48;
			// 
			// txtEaddressBSN
			// 
			txtEaddressBSN.Enabled = false;
			txtEaddressBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtEaddressBSN.Location = new Point(3, 357);
			txtEaddressBSN.Name = "txtEaddressBSN";
			txtEaddressBSN.Size = new Size(281, 28);
			txtEaddressBSN.TabIndex = 63;
			// 
			// txtFnameBSN
			// 
			txtFnameBSN.Enabled = false;
			txtFnameBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtFnameBSN.Location = new Point(107, 126);
			txtFnameBSN.Name = "txtFnameBSN";
			txtFnameBSN.Size = new Size(169, 28);
			txtFnameBSN.TabIndex = 46;
			// 
			// label44
			// 
			label44.AutoSize = true;
			label44.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label44.Location = new Point(3, 329);
			label44.Name = "label44";
			label44.Size = new Size(157, 25);
			label44.TabIndex = 62;
			label44.Text = "Email Address:";
			// 
			// label12
			// 
			label12.AutoSize = true;
			label12.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label12.Location = new Point(81, 31);
			label12.Name = "label12";
			label12.Size = new Size(157, 32);
			label12.TabIndex = 21;
			label12.Text = "REGISTER";
			// 
			// listViewBSN
			// 
			listViewBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			listViewBSN.Location = new Point(307, 56);
			listViewBSN.Name = "listViewBSN";
			listViewBSN.Size = new Size(1083, 521);
			listViewBSN.TabIndex = 1;
			listViewBSN.UseCompatibleStateImageBehavior = false;
			listViewBSN.View = View.Details;
			listViewBSN.MouseClick += listViewBSN_MouseClick;
			// 
			// label43
			// 
			label43.AutoSize = true;
			label43.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label43.Location = new Point(0, 298);
			label43.Name = "label43";
			label43.Size = new Size(98, 25);
			label43.TabIndex = 61;
			label43.Text = "Address:";
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label3.Location = new Point(790, 21);
			label3.Name = "label3";
			label3.Size = new Size(72, 32);
			label3.TabIndex = 0;
			label3.Text = "BSN";
			// 
			// cbGenderBSN
			// 
			cbGenderBSN.Enabled = false;
			cbGenderBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			cbGenderBSN.FormattingEnabled = true;
			cbGenderBSN.Items.AddRange(new object[] { "MALE", "FEMALE" });
			cbGenderBSN.Location = new Point(98, 256);
			cbGenderBSN.Name = "cbGenderBSN";
			cbGenderBSN.Size = new Size(108, 29);
			cbGenderBSN.TabIndex = 60;
			// 
			// label28
			// 
			label28.AutoSize = true;
			label28.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label28.Location = new Point(11, 89);
			label28.Name = "label28";
			label28.Size = new Size(40, 25);
			label28.TabIndex = 44;
			label28.Text = "ID:";
			// 
			// label42
			// 
			label42.AutoSize = true;
			label42.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label42.Location = new Point(3, 259);
			label42.Name = "label42";
			label42.Size = new Size(89, 25);
			label42.TabIndex = 59;
			label42.Text = "Gender:";
			// 
			// txtIdBSN
			// 
			txtIdBSN.Enabled = false;
			txtIdBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtIdBSN.Location = new Point(55, 86);
			txtIdBSN.Name = "txtIdBSN";
			txtIdBSN.Size = new Size(136, 28);
			txtIdBSN.TabIndex = 43;
			// 
			// txtAgeBSN
			// 
			txtAgeBSN.Enabled = false;
			txtAgeBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAgeBSN.Location = new Point(57, 225);
			txtAgeBSN.Name = "txtAgeBSN";
			txtAgeBSN.Size = new Size(39, 28);
			txtAgeBSN.TabIndex = 58;
			// 
			// label38
			// 
			label38.AutoSize = true;
			label38.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label38.Location = new Point(0, 126);
			label38.Name = "label38";
			label38.Size = new Size(113, 25);
			label38.TabIndex = 45;
			label38.Text = "Firstname:";
			// 
			// label41
			// 
			label41.AutoSize = true;
			label41.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label41.Location = new Point(1, 225);
			label41.Name = "label41";
			label41.Size = new Size(57, 25);
			label41.TabIndex = 57;
			label41.Text = "Age:";
			// 
			// label39
			// 
			label39.AutoSize = true;
			label39.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label39.Location = new Point(0, 157);
			label39.Name = "label39";
			label39.Size = new Size(135, 25);
			label39.TabIndex = 47;
			label39.Text = "Middlename:";
			// 
			// txtLnameBSN
			// 
			txtLnameBSN.Enabled = false;
			txtLnameBSN.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtLnameBSN.Location = new Point(108, 188);
			txtLnameBSN.Name = "txtLnameBSN";
			txtLnameBSN.Size = new Size(169, 28);
			txtLnameBSN.TabIndex = 56;
			// 
			// label40
			// 
			label40.AutoSize = true;
			label40.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label40.Location = new Point(0, 191);
			label40.Name = "label40";
			label40.Size = new Size(112, 25);
			label40.TabIndex = 49;
			label40.Text = "Lastname:";
			// 
			// BSCEPANEL
			// 
			BSCEPANEL.BackColor = SystemColors.ActiveCaption;
			BSCEPANEL.Controls.Add(btnBSCENew);
			BSCEPANEL.Controls.Add(txtLnameBSCE);
			BSCEPANEL.Controls.Add(btnDeleteBSCE);
			BSCEPANEL.Controls.Add(txtMnameBSCE);
			BSCEPANEL.Controls.Add(btnUpdateBSCE);
			BSCEPANEL.Controls.Add(txtFnameBSCE);
			BSCEPANEL.Controls.Add(label13);
			BSCEPANEL.Controls.Add(btnAddBSCE);
			BSCEPANEL.Controls.Add(listViewBSCE);
			BSCEPANEL.Controls.Add(dateTimePickerBSCE);
			BSCEPANEL.Controls.Add(label4);
			BSCEPANEL.Controls.Add(label54);
			BSCEPANEL.Controls.Add(label46);
			BSCEPANEL.Controls.Add(txtEaddressBSCE);
			BSCEPANEL.Controls.Add(txtIdBSCEE);
			BSCEPANEL.Controls.Add(label53);
			BSCEPANEL.Controls.Add(label47);
			BSCEPANEL.Controls.Add(txtAddressBSCE);
			BSCEPANEL.Controls.Add(label48);
			BSCEPANEL.Controls.Add(label52);
			BSCEPANEL.Controls.Add(label49);
			BSCEPANEL.Controls.Add(cbGenderBSCE);
			BSCEPANEL.Controls.Add(label51);
			BSCEPANEL.Controls.Add(label50);
			BSCEPANEL.Controls.Add(txtAgeBSCE);
			BSCEPANEL.Location = new Point(174, 100);
			BSCEPANEL.Name = "BSCEPANEL";
			BSCEPANEL.Size = new Size(1406, 593);
			BSCEPANEL.TabIndex = 15;
			BSCEPANEL.Visible = false;
			// 
			// btnBSCENew
			// 
			btnBSCENew.BackColor = SystemColors.ButtonShadow;
			btnBSCENew.Enabled = false;
			btnBSCENew.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnBSCENew.ForeColor = Color.MintCream;
			btnBSCENew.Location = new Point(4, 456);
			btnBSCENew.Name = "btnBSCENew";
			btnBSCENew.Size = new Size(140, 59);
			btnBSCENew.TabIndex = 55;
			btnBSCENew.Text = "NEW";
			btnBSCENew.UseVisualStyleBackColor = false;
			btnBSCENew.MouseClick += btnBSCENew_MouseClick;
			// 
			// txtLnameBSCE
			// 
			txtLnameBSCE.Enabled = false;
			txtLnameBSCE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtLnameBSCE.Location = new Point(107, 188);
			txtLnameBSCE.Name = "txtLnameBSCE";
			txtLnameBSCE.Size = new Size(169, 28);
			txtLnameBSCE.TabIndex = 74;
			// 
			// btnDeleteBSCE
			// 
			btnDeleteBSCE.BackColor = SystemColors.ButtonShadow;
			btnDeleteBSCE.Enabled = false;
			btnDeleteBSCE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnDeleteBSCE.ForeColor = Color.MintCream;
			btnDeleteBSCE.Location = new Point(158, 521);
			btnDeleteBSCE.Name = "btnDeleteBSCE";
			btnDeleteBSCE.Size = new Size(140, 59);
			btnDeleteBSCE.TabIndex = 88;
			btnDeleteBSCE.Text = "DELETE";
			btnDeleteBSCE.UseVisualStyleBackColor = false;
			btnDeleteBSCE.MouseClick += btnDeleteBSCE_MouseClick;
			// 
			// txtMnameBSCE
			// 
			txtMnameBSCE.Enabled = false;
			txtMnameBSCE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtMnameBSCE.Location = new Point(127, 157);
			txtMnameBSCE.Name = "txtMnameBSCE";
			txtMnameBSCE.Size = new Size(150, 28);
			txtMnameBSCE.TabIndex = 72;
			// 
			// btnUpdateBSCE
			// 
			btnUpdateBSCE.BackColor = SystemColors.ButtonShadow;
			btnUpdateBSCE.Enabled = false;
			btnUpdateBSCE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnUpdateBSCE.ForeColor = Color.MintCream;
			btnUpdateBSCE.Location = new Point(3, 521);
			btnUpdateBSCE.Name = "btnUpdateBSCE";
			btnUpdateBSCE.Size = new Size(140, 59);
			btnUpdateBSCE.TabIndex = 87;
			btnUpdateBSCE.Text = "UPDATE";
			btnUpdateBSCE.UseVisualStyleBackColor = false;
			btnUpdateBSCE.MouseClick += btnUpdateBSCE_MouseClick;
			// 
			// txtFnameBSCE
			// 
			txtFnameBSCE.Enabled = false;
			txtFnameBSCE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtFnameBSCE.Location = new Point(107, 126);
			txtFnameBSCE.Name = "txtFnameBSCE";
			txtFnameBSCE.Size = new Size(169, 28);
			txtFnameBSCE.TabIndex = 70;
			// 
			// label13
			// 
			label13.AutoSize = true;
			label13.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label13.Location = new Point(81, 31);
			label13.Name = "label13";
			label13.Size = new Size(157, 32);
			label13.TabIndex = 21;
			label13.Text = "REGISTER";
			// 
			// btnAddBSCE
			// 
			btnAddBSCE.BackColor = SystemColors.ButtonShadow;
			btnAddBSCE.Enabled = false;
			btnAddBSCE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnAddBSCE.ForeColor = Color.MintCream;
			btnAddBSCE.Location = new Point(158, 456);
			btnAddBSCE.Name = "btnAddBSCE";
			btnAddBSCE.Size = new Size(140, 59);
			btnAddBSCE.TabIndex = 86;
			btnAddBSCE.Text = "ADD";
			btnAddBSCE.UseVisualStyleBackColor = false;
			btnAddBSCE.MouseClick += btnAddBSCE_MouseClick;
			// 
			// listViewBSCE
			// 
			listViewBSCE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			listViewBSCE.Location = new Point(307, 56);
			listViewBSCE.Name = "listViewBSCE";
			listViewBSCE.Size = new Size(1083, 521);
			listViewBSCE.TabIndex = 1;
			listViewBSCE.UseCompatibleStateImageBehavior = false;
			listViewBSCE.View = View.Details;
			listViewBSCE.MouseClick += listViewBSCE_MouseClick;
			// 
			// dateTimePickerBSCE
			// 
			dateTimePickerBSCE.Enabled = false;
			dateTimePickerBSCE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			dateTimePickerBSCE.Location = new Point(3, 419);
			dateTimePickerBSCE.Name = "dateTimePickerBSCE";
			dateTimePickerBSCE.Size = new Size(300, 28);
			dateTimePickerBSCE.TabIndex = 84;
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label4.Location = new Point(790, 21);
			label4.Name = "label4";
			label4.Size = new Size(91, 32);
			label4.TabIndex = 0;
			label4.Text = "BSCE";
			// 
			// label54
			// 
			label54.AutoSize = true;
			label54.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label54.Location = new Point(3, 391);
			label54.Name = "label54";
			label54.Size = new Size(140, 25);
			label54.TabIndex = 83;
			label54.Text = "Date of Birth:";
			// 
			// label46
			// 
			label46.AutoSize = true;
			label46.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label46.Location = new Point(11, 89);
			label46.Name = "label46";
			label46.Size = new Size(40, 25);
			label46.TabIndex = 68;
			label46.Text = "ID:";
			// 
			// txtEaddressBSCE
			// 
			txtEaddressBSCE.Enabled = false;
			txtEaddressBSCE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtEaddressBSCE.Location = new Point(3, 357);
			txtEaddressBSCE.Name = "txtEaddressBSCE";
			txtEaddressBSCE.Size = new Size(281, 28);
			txtEaddressBSCE.TabIndex = 82;
			// 
			// txtIdBSCEE
			// 
			txtIdBSCEE.Enabled = false;
			txtIdBSCEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtIdBSCEE.Location = new Point(55, 86);
			txtIdBSCEE.Name = "txtIdBSCEE";
			txtIdBSCEE.Size = new Size(136, 28);
			txtIdBSCEE.TabIndex = 67;
			// 
			// label53
			// 
			label53.AutoSize = true;
			label53.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label53.Location = new Point(3, 329);
			label53.Name = "label53";
			label53.Size = new Size(157, 25);
			label53.TabIndex = 81;
			label53.Text = "Email Address:";
			// 
			// label47
			// 
			label47.AutoSize = true;
			label47.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label47.Location = new Point(0, 126);
			label47.Name = "label47";
			label47.Size = new Size(113, 25);
			label47.TabIndex = 69;
			label47.Text = "Firstname:";
			// 
			// txtAddressBSCE
			// 
			txtAddressBSCE.Enabled = false;
			txtAddressBSCE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAddressBSCE.Location = new Point(98, 298);
			txtAddressBSCE.Name = "txtAddressBSCE";
			txtAddressBSCE.Size = new Size(200, 28);
			txtAddressBSCE.TabIndex = 80;
			// 
			// label48
			// 
			label48.AutoSize = true;
			label48.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label48.Location = new Point(0, 157);
			label48.Name = "label48";
			label48.Size = new Size(135, 25);
			label48.TabIndex = 71;
			label48.Text = "Middlename:";
			// 
			// label52
			// 
			label52.AutoSize = true;
			label52.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label52.Location = new Point(0, 298);
			label52.Name = "label52";
			label52.Size = new Size(98, 25);
			label52.TabIndex = 79;
			label52.Text = "Address:";
			// 
			// label49
			// 
			label49.AutoSize = true;
			label49.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label49.Location = new Point(0, 191);
			label49.Name = "label49";
			label49.Size = new Size(112, 25);
			label49.TabIndex = 73;
			label49.Text = "Lastname:";
			// 
			// cbGenderBSCE
			// 
			cbGenderBSCE.Enabled = false;
			cbGenderBSCE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			cbGenderBSCE.FormattingEnabled = true;
			cbGenderBSCE.Items.AddRange(new object[] { "MALE", "FEMALE" });
			cbGenderBSCE.Location = new Point(98, 256);
			cbGenderBSCE.Name = "cbGenderBSCE";
			cbGenderBSCE.Size = new Size(108, 29);
			cbGenderBSCE.TabIndex = 78;
			// 
			// label51
			// 
			label51.AutoSize = true;
			label51.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label51.Location = new Point(3, 259);
			label51.Name = "label51";
			label51.Size = new Size(89, 25);
			label51.TabIndex = 77;
			label51.Text = "Gender:";
			// 
			// label50
			// 
			label50.AutoSize = true;
			label50.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label50.Location = new Point(1, 225);
			label50.Name = "label50";
			label50.Size = new Size(57, 25);
			label50.TabIndex = 75;
			label50.Text = "Age:";
			// 
			// txtAgeBSCE
			// 
			txtAgeBSCE.Enabled = false;
			txtAgeBSCE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAgeBSCE.Location = new Point(57, 225);
			txtAgeBSCE.Name = "txtAgeBSCE";
			txtAgeBSCE.Size = new Size(39, 28);
			txtAgeBSCE.TabIndex = 76;
			// 
			// PANELBSEE
			// 
			PANELBSEE.BackColor = SystemColors.ActiveCaption;
			PANELBSEE.Controls.Add(btnAddbsee);
			PANELBSEE.Controls.Add(btnNewbsee);
			PANELBSEE.Controls.Add(btnDeleteBSEE);
			PANELBSEE.Controls.Add(dateTimePickerBSEE);
			PANELBSEE.Controls.Add(btnUpdateBSEE);
			PANELBSEE.Controls.Add(label63);
			PANELBSEE.Controls.Add(txtAddressBSEE);
			PANELBSEE.Controls.Add(txtEaddressBSEE);
			PANELBSEE.Controls.Add(label62);
			PANELBSEE.Controls.Add(txtLnameBSEE);
			PANELBSEE.Controls.Add(label61);
			PANELBSEE.Controls.Add(txtMnameBSEE);
			PANELBSEE.Controls.Add(label14);
			PANELBSEE.Controls.Add(cbGenderBSEE);
			PANELBSEE.Controls.Add(listView1BSEE);
			PANELBSEE.Controls.Add(label60);
			PANELBSEE.Controls.Add(label5);
			PANELBSEE.Controls.Add(txtAgeBSEE);
			PANELBSEE.Controls.Add(label57);
			PANELBSEE.Controls.Add(label59);
			PANELBSEE.Controls.Add(label55);
			PANELBSEE.Controls.Add(txtIdBSEE);
			PANELBSEE.Controls.Add(label56);
			PANELBSEE.Controls.Add(label58);
			PANELBSEE.Controls.Add(txtFnameBSEE);
			PANELBSEE.Location = new Point(174, 100);
			PANELBSEE.Name = "PANELBSEE";
			PANELBSEE.Size = new Size(1404, 593);
			PANELBSEE.TabIndex = 16;
			PANELBSEE.Visible = false;
			// 
			// btnAddbsee
			// 
			btnAddbsee.BackColor = SystemColors.ButtonShadow;
			btnAddbsee.Enabled = false;
			btnAddbsee.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnAddbsee.ForeColor = Color.MintCream;
			btnAddbsee.Location = new Point(158, 456);
			btnAddbsee.Name = "btnAddbsee";
			btnAddbsee.Size = new Size(140, 59);
			btnAddbsee.TabIndex = 87;
			btnAddbsee.Text = "ADD";
			btnAddbsee.UseVisualStyleBackColor = false;
			btnAddbsee.MouseClick += btnAddbsee_MouseClick;
			// 
			// btnNewbsee
			// 
			btnNewbsee.BackColor = SystemColors.ButtonShadow;
			btnNewbsee.Enabled = false;
			btnNewbsee.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnNewbsee.ForeColor = Color.MintCream;
			btnNewbsee.Location = new Point(4, 456);
			btnNewbsee.Name = "btnNewbsee";
			btnNewbsee.Size = new Size(140, 59);
			btnNewbsee.TabIndex = 56;
			btnNewbsee.Text = "NEW";
			btnNewbsee.UseVisualStyleBackColor = false;
			btnNewbsee.Click += btnNewbsee_Click;
			btnNewbsee.MouseClick += btnNewbsee_MouseClick_1;
			// 
			// btnDeleteBSEE
			// 
			btnDeleteBSEE.BackColor = SystemColors.ButtonShadow;
			btnDeleteBSEE.Enabled = false;
			btnDeleteBSEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnDeleteBSEE.ForeColor = Color.MintCream;
			btnDeleteBSEE.Location = new Point(158, 521);
			btnDeleteBSEE.Name = "btnDeleteBSEE";
			btnDeleteBSEE.Size = new Size(140, 59);
			btnDeleteBSEE.TabIndex = 89;
			btnDeleteBSEE.Text = "DELETE";
			btnDeleteBSEE.UseVisualStyleBackColor = false;
			btnDeleteBSEE.MouseClick += btnDeleteBSEE_MouseClick;
			// 
			// dateTimePickerBSEE
			// 
			dateTimePickerBSEE.Enabled = false;
			dateTimePickerBSEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			dateTimePickerBSEE.Location = new Point(3, 419);
			dateTimePickerBSEE.Name = "dateTimePickerBSEE";
			dateTimePickerBSEE.Size = new Size(300, 28);
			dateTimePickerBSEE.TabIndex = 98;
			// 
			// btnUpdateBSEE
			// 
			btnUpdateBSEE.BackColor = SystemColors.ButtonShadow;
			btnUpdateBSEE.Enabled = false;
			btnUpdateBSEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnUpdateBSEE.ForeColor = Color.MintCream;
			btnUpdateBSEE.Location = new Point(3, 521);
			btnUpdateBSEE.Name = "btnUpdateBSEE";
			btnUpdateBSEE.Size = new Size(140, 59);
			btnUpdateBSEE.TabIndex = 88;
			btnUpdateBSEE.Text = "UPDATE";
			btnUpdateBSEE.UseVisualStyleBackColor = false;
			btnUpdateBSEE.MouseClick += btnUpdateBSEE_MouseClick;
			// 
			// label63
			// 
			label63.AutoSize = true;
			label63.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label63.Location = new Point(3, 391);
			label63.Name = "label63";
			label63.Size = new Size(140, 25);
			label63.TabIndex = 101;
			label63.Text = "Date of Birth:";
			// 
			// txtAddressBSEE
			// 
			txtAddressBSEE.Enabled = false;
			txtAddressBSEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAddressBSEE.Location = new Point(98, 298);
			txtAddressBSEE.Name = "txtAddressBSEE";
			txtAddressBSEE.Size = new Size(200, 28);
			txtAddressBSEE.TabIndex = 103;
			// 
			// txtEaddressBSEE
			// 
			txtEaddressBSEE.Enabled = false;
			txtEaddressBSEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtEaddressBSEE.Location = new Point(3, 357);
			txtEaddressBSEE.Name = "txtEaddressBSEE";
			txtEaddressBSEE.Size = new Size(281, 28);
			txtEaddressBSEE.TabIndex = 99;
			// 
			// label62
			// 
			label62.AutoSize = true;
			label62.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label62.Location = new Point(3, 329);
			label62.Name = "label62";
			label62.Size = new Size(157, 25);
			label62.TabIndex = 100;
			label62.Text = "Email Address:";
			// 
			// txtLnameBSEE
			// 
			txtLnameBSEE.Enabled = false;
			txtLnameBSEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtLnameBSEE.Location = new Point(108, 188);
			txtLnameBSEE.Name = "txtLnameBSEE";
			txtLnameBSEE.Size = new Size(169, 28);
			txtLnameBSEE.TabIndex = 95;
			// 
			// label61
			// 
			label61.AutoSize = true;
			label61.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label61.Location = new Point(0, 298);
			label61.Name = "label61";
			label61.Size = new Size(98, 25);
			label61.TabIndex = 102;
			label61.Text = "Address:";
			// 
			// txtMnameBSEE
			// 
			txtMnameBSEE.Enabled = false;
			txtMnameBSEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtMnameBSEE.Location = new Point(127, 157);
			txtMnameBSEE.Name = "txtMnameBSEE";
			txtMnameBSEE.Size = new Size(150, 28);
			txtMnameBSEE.TabIndex = 93;
			// 
			// label14
			// 
			label14.AutoSize = true;
			label14.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label14.Location = new Point(81, 31);
			label14.Name = "label14";
			label14.Size = new Size(157, 32);
			label14.TabIndex = 21;
			label14.Text = "REGISTER";
			// 
			// cbGenderBSEE
			// 
			cbGenderBSEE.Enabled = false;
			cbGenderBSEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			cbGenderBSEE.FormattingEnabled = true;
			cbGenderBSEE.Items.AddRange(new object[] { "MALE", "FEMALE" });
			cbGenderBSEE.Location = new Point(98, 256);
			cbGenderBSEE.Name = "cbGenderBSEE";
			cbGenderBSEE.Size = new Size(108, 29);
			cbGenderBSEE.TabIndex = 101;
			// 
			// listView1BSEE
			// 
			listView1BSEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			listView1BSEE.Location = new Point(307, 56);
			listView1BSEE.Name = "listView1BSEE";
			listView1BSEE.Size = new Size(1083, 521);
			listView1BSEE.TabIndex = 1;
			listView1BSEE.UseCompatibleStateImageBehavior = false;
			listView1BSEE.View = View.Details;
			listView1BSEE.MouseClick += listView1BSEE_MouseClick;
			// 
			// label60
			// 
			label60.AutoSize = true;
			label60.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label60.Location = new Point(3, 259);
			label60.Name = "label60";
			label60.Size = new Size(89, 25);
			label60.TabIndex = 100;
			label60.Text = "Gender:";
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label5.Location = new Point(790, 21);
			label5.Name = "label5";
			label5.Size = new Size(90, 32);
			label5.TabIndex = 0;
			label5.Text = "BSEE";
			// 
			// txtAgeBSEE
			// 
			txtAgeBSEE.Enabled = false;
			txtAgeBSEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAgeBSEE.Location = new Point(57, 225);
			txtAgeBSEE.Name = "txtAgeBSEE";
			txtAgeBSEE.Size = new Size(39, 28);
			txtAgeBSEE.TabIndex = 99;
			// 
			// label57
			// 
			label57.AutoSize = true;
			label57.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label57.Location = new Point(0, 126);
			label57.Name = "label57";
			label57.Size = new Size(113, 25);
			label57.TabIndex = 94;
			label57.Text = "Firstname:";
			// 
			// label59
			// 
			label59.AutoSize = true;
			label59.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label59.Location = new Point(1, 225);
			label59.Name = "label59";
			label59.Size = new Size(57, 25);
			label59.TabIndex = 98;
			label59.Text = "Age:";
			// 
			// label55
			// 
			label55.AutoSize = true;
			label55.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label55.Location = new Point(11, 89);
			label55.Name = "label55";
			label55.Size = new Size(40, 25);
			label55.TabIndex = 91;
			label55.Text = "ID:";
			// 
			// txtIdBSEE
			// 
			txtIdBSEE.Enabled = false;
			txtIdBSEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtIdBSEE.Location = new Point(55, 86);
			txtIdBSEE.Name = "txtIdBSEE";
			txtIdBSEE.Size = new Size(136, 28);
			txtIdBSEE.TabIndex = 90;
			// 
			// label56
			// 
			label56.AutoSize = true;
			label56.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label56.Location = new Point(0, 157);
			label56.Name = "label56";
			label56.Size = new Size(135, 25);
			label56.TabIndex = 92;
			label56.Text = "Middlename:";
			// 
			// label58
			// 
			label58.AutoSize = true;
			label58.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label58.Location = new Point(0, 191);
			label58.Name = "label58";
			label58.Size = new Size(112, 25);
			label58.TabIndex = 96;
			label58.Text = "Lastname:";
			// 
			// txtFnameBSEE
			// 
			txtFnameBSEE.Enabled = false;
			txtFnameBSEE.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtFnameBSEE.Location = new Point(118, 123);
			txtFnameBSEE.Name = "txtFnameBSEE";
			txtFnameBSEE.Size = new Size(159, 28);
			txtFnameBSEE.TabIndex = 95;
			// 
			// BSCJPANEL
			// 
			BSCJPANEL.BackColor = SystemColors.ActiveCaption;
			BSCJPANEL.Controls.Add(btnDeleteBSCJ);
			BSCJPANEL.Controls.Add(txtMnameBSCJ);
			BSCJPANEL.Controls.Add(btnUpdateBSCJ);
			BSCJPANEL.Controls.Add(txtFnameBSCJ);
			BSCJPANEL.Controls.Add(btnAddBSCJ);
			BSCJPANEL.Controls.Add(label15);
			BSCJPANEL.Controls.Add(btnNewBSCJ);
			BSCJPANEL.Controls.Add(listViewBSCJ);
			BSCJPANEL.Controls.Add(dateTimePickerBSCJ);
			BSCJPANEL.Controls.Add(label6);
			BSCJPANEL.Controls.Add(label72);
			BSCJPANEL.Controls.Add(label64);
			BSCJPANEL.Controls.Add(txtEaddressBSCJ);
			BSCJPANEL.Controls.Add(txtIdBSCJ);
			BSCJPANEL.Controls.Add(label71);
			BSCJPANEL.Controls.Add(label65);
			BSCJPANEL.Controls.Add(txtAddressBSCJ);
			BSCJPANEL.Controls.Add(label66);
			BSCJPANEL.Controls.Add(label70);
			BSCJPANEL.Controls.Add(label67);
			BSCJPANEL.Controls.Add(cbGenderBSCJ);
			BSCJPANEL.Controls.Add(txtLnameBSCJ);
			BSCJPANEL.Controls.Add(label69);
			BSCJPANEL.Controls.Add(label68);
			BSCJPANEL.Controls.Add(txtAgeBSCJ);
			BSCJPANEL.Location = new Point(174, 100);
			BSCJPANEL.Name = "BSCJPANEL";
			BSCJPANEL.Size = new Size(1406, 593);
			BSCJPANEL.TabIndex = 17;
			BSCJPANEL.Visible = false;
			// 
			// btnDeleteBSCJ
			// 
			btnDeleteBSCJ.BackColor = SystemColors.ButtonShadow;
			btnDeleteBSCJ.Enabled = false;
			btnDeleteBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnDeleteBSCJ.ForeColor = Color.MintCream;
			btnDeleteBSCJ.Location = new Point(158, 521);
			btnDeleteBSCJ.Name = "btnDeleteBSCJ";
			btnDeleteBSCJ.Size = new Size(140, 59);
			btnDeleteBSCJ.TabIndex = 114;
			btnDeleteBSCJ.Text = "DELETE";
			btnDeleteBSCJ.UseVisualStyleBackColor = false;
			btnDeleteBSCJ.MouseClick += btnDeleteBSCJ_MouseClick;
			// 
			// txtMnameBSCJ
			// 
			txtMnameBSCJ.Enabled = false;
			txtMnameBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtMnameBSCJ.Location = new Point(127, 157);
			txtMnameBSCJ.Name = "txtMnameBSCJ";
			txtMnameBSCJ.Size = new Size(150, 28);
			txtMnameBSCJ.TabIndex = 98;
			// 
			// btnUpdateBSCJ
			// 
			btnUpdateBSCJ.BackColor = SystemColors.ButtonShadow;
			btnUpdateBSCJ.Enabled = false;
			btnUpdateBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnUpdateBSCJ.ForeColor = Color.MintCream;
			btnUpdateBSCJ.Location = new Point(3, 521);
			btnUpdateBSCJ.Name = "btnUpdateBSCJ";
			btnUpdateBSCJ.Size = new Size(140, 59);
			btnUpdateBSCJ.TabIndex = 113;
			btnUpdateBSCJ.Text = "UPDATE";
			btnUpdateBSCJ.UseVisualStyleBackColor = false;
			btnUpdateBSCJ.MouseClick += btnUpdateBSCJ_MouseClick;
			// 
			// txtFnameBSCJ
			// 
			txtFnameBSCJ.Enabled = false;
			txtFnameBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtFnameBSCJ.Location = new Point(107, 126);
			txtFnameBSCJ.Name = "txtFnameBSCJ";
			txtFnameBSCJ.Size = new Size(169, 28);
			txtFnameBSCJ.TabIndex = 96;
			// 
			// btnAddBSCJ
			// 
			btnAddBSCJ.BackColor = SystemColors.ButtonShadow;
			btnAddBSCJ.Enabled = false;
			btnAddBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnAddBSCJ.ForeColor = Color.MintCream;
			btnAddBSCJ.Location = new Point(158, 456);
			btnAddBSCJ.Name = "btnAddBSCJ";
			btnAddBSCJ.Size = new Size(140, 59);
			btnAddBSCJ.TabIndex = 112;
			btnAddBSCJ.Text = "ADD";
			btnAddBSCJ.UseVisualStyleBackColor = false;
			btnAddBSCJ.MouseClick += btnAddBSCJ_MouseClick;
			// 
			// label15
			// 
			label15.AutoSize = true;
			label15.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label15.Location = new Point(81, 31);
			label15.Name = "label15";
			label15.Size = new Size(157, 32);
			label15.TabIndex = 21;
			label15.Text = "REGISTER";
			// 
			// btnNewBSCJ
			// 
			btnNewBSCJ.BackColor = SystemColors.ButtonShadow;
			btnNewBSCJ.Enabled = false;
			btnNewBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnNewBSCJ.ForeColor = Color.MintCream;
			btnNewBSCJ.Location = new Point(3, 456);
			btnNewBSCJ.Name = "btnNewBSCJ";
			btnNewBSCJ.Size = new Size(140, 59);
			btnNewBSCJ.TabIndex = 111;
			btnNewBSCJ.Text = "NEW";
			btnNewBSCJ.UseVisualStyleBackColor = false;
			btnNewBSCJ.MouseClick += btnNewBSCJ_MouseClick;
			// 
			// listViewBSCJ
			// 
			listViewBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			listViewBSCJ.Location = new Point(307, 56);
			listViewBSCJ.Name = "listViewBSCJ";
			listViewBSCJ.Size = new Size(1083, 521);
			listViewBSCJ.TabIndex = 1;
			listViewBSCJ.UseCompatibleStateImageBehavior = false;
			listViewBSCJ.View = View.Details;
			listViewBSCJ.MouseClick += listViewBSCJ_MouseClick;
			// 
			// dateTimePickerBSCJ
			// 
			dateTimePickerBSCJ.Enabled = false;
			dateTimePickerBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			dateTimePickerBSCJ.Location = new Point(3, 419);
			dateTimePickerBSCJ.Name = "dateTimePickerBSCJ";
			dateTimePickerBSCJ.Size = new Size(300, 28);
			dateTimePickerBSCJ.TabIndex = 110;
			// 
			// label6
			// 
			label6.AutoSize = true;
			label6.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label6.Location = new Point(790, 21);
			label6.Name = "label6";
			label6.Size = new Size(86, 32);
			label6.TabIndex = 0;
			label6.Text = "BSCJ";
			// 
			// label72
			// 
			label72.AutoSize = true;
			label72.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label72.Location = new Point(3, 391);
			label72.Name = "label72";
			label72.Size = new Size(140, 25);
			label72.TabIndex = 109;
			label72.Text = "Date of Birth:";
			// 
			// label64
			// 
			label64.AutoSize = true;
			label64.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label64.Location = new Point(11, 89);
			label64.Name = "label64";
			label64.Size = new Size(40, 25);
			label64.TabIndex = 92;
			label64.Text = "ID:";
			// 
			// txtEaddressBSCJ
			// 
			txtEaddressBSCJ.Enabled = false;
			txtEaddressBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtEaddressBSCJ.Location = new Point(3, 357);
			txtEaddressBSCJ.Name = "txtEaddressBSCJ";
			txtEaddressBSCJ.Size = new Size(281, 28);
			txtEaddressBSCJ.TabIndex = 108;
			// 
			// txtIdBSCJ
			// 
			txtIdBSCJ.Enabled = false;
			txtIdBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtIdBSCJ.Location = new Point(55, 86);
			txtIdBSCJ.Name = "txtIdBSCJ";
			txtIdBSCJ.Size = new Size(136, 28);
			txtIdBSCJ.TabIndex = 91;
			// 
			// label71
			// 
			label71.AutoSize = true;
			label71.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label71.Location = new Point(3, 329);
			label71.Name = "label71";
			label71.Size = new Size(157, 25);
			label71.TabIndex = 107;
			label71.Text = "Email Address:";
			// 
			// label65
			// 
			label65.AutoSize = true;
			label65.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label65.Location = new Point(0, 126);
			label65.Name = "label65";
			label65.Size = new Size(113, 25);
			label65.TabIndex = 95;
			label65.Text = "Firstname:";
			// 
			// txtAddressBSCJ
			// 
			txtAddressBSCJ.Enabled = false;
			txtAddressBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAddressBSCJ.Location = new Point(98, 298);
			txtAddressBSCJ.Name = "txtAddressBSCJ";
			txtAddressBSCJ.Size = new Size(200, 28);
			txtAddressBSCJ.TabIndex = 106;
			// 
			// label66
			// 
			label66.AutoSize = true;
			label66.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label66.Location = new Point(0, 157);
			label66.Name = "label66";
			label66.Size = new Size(135, 25);
			label66.TabIndex = 97;
			label66.Text = "Middlename:";
			// 
			// label70
			// 
			label70.AutoSize = true;
			label70.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label70.Location = new Point(0, 298);
			label70.Name = "label70";
			label70.Size = new Size(98, 25);
			label70.TabIndex = 105;
			label70.Text = "Address:";
			// 
			// label67
			// 
			label67.AutoSize = true;
			label67.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label67.Location = new Point(0, 191);
			label67.Name = "label67";
			label67.Size = new Size(112, 25);
			label67.TabIndex = 99;
			label67.Text = "Lastname:";
			// 
			// cbGenderBSCJ
			// 
			cbGenderBSCJ.Enabled = false;
			cbGenderBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			cbGenderBSCJ.FormattingEnabled = true;
			cbGenderBSCJ.Items.AddRange(new object[] { "MALE", "FEMALE" });
			cbGenderBSCJ.Location = new Point(98, 256);
			cbGenderBSCJ.Name = "cbGenderBSCJ";
			cbGenderBSCJ.Size = new Size(108, 29);
			cbGenderBSCJ.TabIndex = 104;
			// 
			// txtLnameBSCJ
			// 
			txtLnameBSCJ.Enabled = false;
			txtLnameBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtLnameBSCJ.Location = new Point(118, 191);
			txtLnameBSCJ.Name = "txtLnameBSCJ";
			txtLnameBSCJ.Size = new Size(169, 28);
			txtLnameBSCJ.TabIndex = 100;
			// 
			// label69
			// 
			label69.AutoSize = true;
			label69.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label69.Location = new Point(3, 259);
			label69.Name = "label69";
			label69.Size = new Size(89, 25);
			label69.TabIndex = 103;
			label69.Text = "Gender:";
			// 
			// label68
			// 
			label68.AutoSize = true;
			label68.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label68.Location = new Point(1, 225);
			label68.Name = "label68";
			label68.Size = new Size(57, 25);
			label68.TabIndex = 102;
			label68.Text = "Age:";
			// 
			// txtAgeBSCJ
			// 
			txtAgeBSCJ.Enabled = false;
			txtAgeBSCJ.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAgeBSCJ.Location = new Point(57, 225);
			txtAgeBSCJ.Name = "txtAgeBSCJ";
			txtAgeBSCJ.Size = new Size(39, 28);
			txtAgeBSCJ.TabIndex = 101;
			// 
			// BSHMPANEL
			// 
			BSHMPANEL.BackColor = SystemColors.ActiveCaption;
			BSHMPANEL.Controls.Add(btnDeleteBSHM);
			BSHMPANEL.Controls.Add(txtMnameBSHM);
			BSHMPANEL.Controls.Add(btnUpdateBSHM);
			BSHMPANEL.Controls.Add(txtFnameBSHM);
			BSHMPANEL.Controls.Add(btnAddBSHM);
			BSHMPANEL.Controls.Add(label16);
			BSHMPANEL.Controls.Add(btnNewBSHM);
			BSHMPANEL.Controls.Add(listViewBSHM);
			BSHMPANEL.Controls.Add(dateTimePickerBSHM);
			BSHMPANEL.Controls.Add(label7);
			BSHMPANEL.Controls.Add(label81);
			BSHMPANEL.Controls.Add(label73);
			BSHMPANEL.Controls.Add(txtEaddressBSHM);
			BSHMPANEL.Controls.Add(txtIdBSHM);
			BSHMPANEL.Controls.Add(label80);
			BSHMPANEL.Controls.Add(label74);
			BSHMPANEL.Controls.Add(txtAddressBSHM);
			BSHMPANEL.Controls.Add(label75);
			BSHMPANEL.Controls.Add(label79);
			BSHMPANEL.Controls.Add(label76);
			BSHMPANEL.Controls.Add(cbGenderBSHM);
			BSHMPANEL.Controls.Add(txtLnameBSHM);
			BSHMPANEL.Controls.Add(label78);
			BSHMPANEL.Controls.Add(label77);
			BSHMPANEL.Controls.Add(txtAgeBSHM);
			BSHMPANEL.Location = new Point(174, 100);
			BSHMPANEL.Name = "BSHMPANEL";
			BSHMPANEL.Size = new Size(1406, 593);
			BSHMPANEL.TabIndex = 18;
			BSHMPANEL.Visible = false;
			// 
			// btnDeleteBSHM
			// 
			btnDeleteBSHM.BackColor = SystemColors.ButtonShadow;
			btnDeleteBSHM.Enabled = false;
			btnDeleteBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnDeleteBSHM.ForeColor = Color.MintCream;
			btnDeleteBSHM.Location = new Point(158, 521);
			btnDeleteBSHM.Name = "btnDeleteBSHM";
			btnDeleteBSHM.Size = new Size(140, 59);
			btnDeleteBSHM.TabIndex = 116;
			btnDeleteBSHM.Text = "DELETE";
			btnDeleteBSHM.UseVisualStyleBackColor = false;
			btnDeleteBSHM.MouseClick += btnDeleteBSHM_MouseClick;
			// 
			// txtMnameBSHM
			// 
			txtMnameBSHM.Enabled = false;
			txtMnameBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtMnameBSHM.Location = new Point(127, 157);
			txtMnameBSHM.Name = "txtMnameBSHM";
			txtMnameBSHM.Size = new Size(150, 28);
			txtMnameBSHM.TabIndex = 100;
			// 
			// btnUpdateBSHM
			// 
			btnUpdateBSHM.BackColor = SystemColors.ButtonShadow;
			btnUpdateBSHM.Enabled = false;
			btnUpdateBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnUpdateBSHM.ForeColor = Color.MintCream;
			btnUpdateBSHM.Location = new Point(3, 521);
			btnUpdateBSHM.Name = "btnUpdateBSHM";
			btnUpdateBSHM.Size = new Size(140, 59);
			btnUpdateBSHM.TabIndex = 115;
			btnUpdateBSHM.Text = "UPDATE";
			btnUpdateBSHM.UseVisualStyleBackColor = false;
			btnUpdateBSHM.MouseClick += btnUpdateBSHM_MouseClick;
			// 
			// txtFnameBSHM
			// 
			txtFnameBSHM.Enabled = false;
			txtFnameBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtFnameBSHM.Location = new Point(107, 126);
			txtFnameBSHM.Name = "txtFnameBSHM";
			txtFnameBSHM.Size = new Size(169, 28);
			txtFnameBSHM.TabIndex = 99;
			// 
			// btnAddBSHM
			// 
			btnAddBSHM.BackColor = SystemColors.ButtonShadow;
			btnAddBSHM.Enabled = false;
			btnAddBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnAddBSHM.ForeColor = Color.MintCream;
			btnAddBSHM.Location = new Point(158, 456);
			btnAddBSHM.Name = "btnAddBSHM";
			btnAddBSHM.Size = new Size(140, 59);
			btnAddBSHM.TabIndex = 114;
			btnAddBSHM.Text = "ADD";
			btnAddBSHM.UseVisualStyleBackColor = false;
			btnAddBSHM.MouseClick += btnAddBSHM_MouseClick;
			// 
			// label16
			// 
			label16.AutoSize = true;
			label16.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label16.Location = new Point(81, 31);
			label16.Name = "label16";
			label16.Size = new Size(157, 32);
			label16.TabIndex = 22;
			label16.Text = "REGISTER";
			// 
			// btnNewBSHM
			// 
			btnNewBSHM.BackColor = SystemColors.ButtonShadow;
			btnNewBSHM.Enabled = false;
			btnNewBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnNewBSHM.ForeColor = Color.MintCream;
			btnNewBSHM.Location = new Point(3, 456);
			btnNewBSHM.Name = "btnNewBSHM";
			btnNewBSHM.Size = new Size(140, 59);
			btnNewBSHM.TabIndex = 113;
			btnNewBSHM.Text = "NEW";
			btnNewBSHM.UseVisualStyleBackColor = false;
			btnNewBSHM.MouseClick += btnNewBSHM_MouseClick;
			// 
			// listViewBSHM
			// 
			listViewBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			listViewBSHM.Location = new Point(307, 56);
			listViewBSHM.Name = "listViewBSHM";
			listViewBSHM.Size = new Size(1083, 521);
			listViewBSHM.TabIndex = 1;
			listViewBSHM.UseCompatibleStateImageBehavior = false;
			listViewBSHM.View = View.Details;
			listViewBSHM.MouseClick += listViewBSHM_MouseClick;
			// 
			// dateTimePickerBSHM
			// 
			dateTimePickerBSHM.Enabled = false;
			dateTimePickerBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			dateTimePickerBSHM.Location = new Point(3, 419);
			dateTimePickerBSHM.Name = "dateTimePickerBSHM";
			dateTimePickerBSHM.Size = new Size(300, 28);
			dateTimePickerBSHM.TabIndex = 112;
			// 
			// label7
			// 
			label7.AutoSize = true;
			label7.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label7.Location = new Point(790, 21);
			label7.Name = "label7";
			label7.Size = new Size(95, 32);
			label7.TabIndex = 0;
			label7.Text = "BSHM";
			// 
			// label81
			// 
			label81.AutoSize = true;
			label81.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label81.Location = new Point(3, 391);
			label81.Name = "label81";
			label81.Size = new Size(140, 25);
			label81.TabIndex = 111;
			label81.Text = "Date of Birth:";
			// 
			// label73
			// 
			label73.AutoSize = true;
			label73.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label73.Location = new Point(11, 89);
			label73.Name = "label73";
			label73.Size = new Size(40, 25);
			label73.TabIndex = 93;
			label73.Text = "ID:";
			// 
			// txtEaddressBSHM
			// 
			txtEaddressBSHM.Enabled = false;
			txtEaddressBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtEaddressBSHM.Location = new Point(3, 357);
			txtEaddressBSHM.Name = "txtEaddressBSHM";
			txtEaddressBSHM.Size = new Size(281, 28);
			txtEaddressBSHM.TabIndex = 110;
			// 
			// txtIdBSHM
			// 
			txtIdBSHM.Enabled = false;
			txtIdBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtIdBSHM.Location = new Point(55, 86);
			txtIdBSHM.Name = "txtIdBSHM";
			txtIdBSHM.Size = new Size(136, 28);
			txtIdBSHM.TabIndex = 92;
			// 
			// label80
			// 
			label80.AutoSize = true;
			label80.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label80.Location = new Point(3, 329);
			label80.Name = "label80";
			label80.Size = new Size(157, 25);
			label80.TabIndex = 109;
			label80.Text = "Email Address:";
			// 
			// label74
			// 
			label74.AutoSize = true;
			label74.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label74.Location = new Point(0, 126);
			label74.Name = "label74";
			label74.Size = new Size(113, 25);
			label74.TabIndex = 96;
			label74.Text = "Firstname:";
			// 
			// txtAddressBSHM
			// 
			txtAddressBSHM.Enabled = false;
			txtAddressBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAddressBSHM.Location = new Point(98, 298);
			txtAddressBSHM.Name = "txtAddressBSHM";
			txtAddressBSHM.Size = new Size(200, 28);
			txtAddressBSHM.TabIndex = 108;
			// 
			// label75
			// 
			label75.AutoSize = true;
			label75.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label75.Location = new Point(0, 157);
			label75.Name = "label75";
			label75.Size = new Size(135, 25);
			label75.TabIndex = 98;
			label75.Text = "Middlename:";
			// 
			// label79
			// 
			label79.AutoSize = true;
			label79.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label79.Location = new Point(0, 298);
			label79.Name = "label79";
			label79.Size = new Size(98, 25);
			label79.TabIndex = 107;
			label79.Text = "Address:";
			// 
			// label76
			// 
			label76.AutoSize = true;
			label76.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label76.Location = new Point(0, 191);
			label76.Name = "label76";
			label76.Size = new Size(112, 25);
			label76.TabIndex = 101;
			label76.Text = "Lastname:";
			// 
			// cbGenderBSHM
			// 
			cbGenderBSHM.Enabled = false;
			cbGenderBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			cbGenderBSHM.FormattingEnabled = true;
			cbGenderBSHM.Items.AddRange(new object[] { "MALE", "FEMALE" });
			cbGenderBSHM.Location = new Point(98, 256);
			cbGenderBSHM.Name = "cbGenderBSHM";
			cbGenderBSHM.Size = new Size(108, 29);
			cbGenderBSHM.TabIndex = 106;
			// 
			// txtLnameBSHM
			// 
			txtLnameBSHM.Enabled = false;
			txtLnameBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtLnameBSHM.Location = new Point(118, 191);
			txtLnameBSHM.Name = "txtLnameBSHM";
			txtLnameBSHM.Size = new Size(169, 28);
			txtLnameBSHM.TabIndex = 102;
			// 
			// label78
			// 
			label78.AutoSize = true;
			label78.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label78.Location = new Point(3, 259);
			label78.Name = "label78";
			label78.Size = new Size(89, 25);
			label78.TabIndex = 105;
			label78.Text = "Gender:";
			// 
			// label77
			// 
			label77.AutoSize = true;
			label77.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label77.Location = new Point(1, 225);
			label77.Name = "label77";
			label77.Size = new Size(57, 25);
			label77.TabIndex = 103;
			label77.Text = "Age:";
			// 
			// txtAgeBSHM
			// 
			txtAgeBSHM.Enabled = false;
			txtAgeBSHM.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAgeBSHM.Location = new Point(57, 225);
			txtAgeBSHM.Name = "txtAgeBSHM";
			txtAgeBSHM.Size = new Size(39, 28);
			txtAgeBSHM.TabIndex = 104;
			// 
			// BSEDPANEL
			// 
			BSEDPANEL.BackColor = SystemColors.ActiveCaption;
			BSEDPANEL.Controls.Add(btnDeleteBSED);
			BSEDPANEL.Controls.Add(txtMnameBSED);
			BSEDPANEL.Controls.Add(btnUpdateBSED);
			BSEDPANEL.Controls.Add(txtFnameBSED);
			BSEDPANEL.Controls.Add(btnAddBSED);
			BSEDPANEL.Controls.Add(label17);
			BSEDPANEL.Controls.Add(btnNewBSED);
			BSEDPANEL.Controls.Add(listViewBSED);
			BSEDPANEL.Controls.Add(dateTimePickerBSED);
			BSEDPANEL.Controls.Add(label8);
			BSEDPANEL.Controls.Add(label90);
			BSEDPANEL.Controls.Add(label82);
			BSEDPANEL.Controls.Add(label89);
			BSEDPANEL.Controls.Add(txtEaddressBSED);
			BSEDPANEL.Controls.Add(txtIdBSED);
			BSEDPANEL.Controls.Add(label83);
			BSEDPANEL.Controls.Add(txtAddressBSED);
			BSEDPANEL.Controls.Add(label84);
			BSEDPANEL.Controls.Add(label88);
			BSEDPANEL.Controls.Add(label85);
			BSEDPANEL.Controls.Add(cbGenderBSED);
			BSEDPANEL.Controls.Add(txtLnameBSED);
			BSEDPANEL.Controls.Add(label87);
			BSEDPANEL.Controls.Add(label86);
			BSEDPANEL.Controls.Add(txtAgeBSED);
			BSEDPANEL.Location = new Point(174, 100);
			BSEDPANEL.Name = "BSEDPANEL";
			BSEDPANEL.Size = new Size(1406, 593);
			BSEDPANEL.TabIndex = 19;
			BSEDPANEL.Visible = false;
			BSEDPANEL.Paint += BSEDPANEL_Paint;
			// 
			// btnDeleteBSED
			// 
			btnDeleteBSED.BackColor = SystemColors.ButtonShadow;
			btnDeleteBSED.Enabled = false;
			btnDeleteBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnDeleteBSED.ForeColor = Color.MintCream;
			btnDeleteBSED.Location = new Point(158, 521);
			btnDeleteBSED.Name = "btnDeleteBSED";
			btnDeleteBSED.Size = new Size(140, 59);
			btnDeleteBSED.TabIndex = 118;
			btnDeleteBSED.Text = "DELETE";
			btnDeleteBSED.UseVisualStyleBackColor = false;
			btnDeleteBSED.MouseClick += btnDeleteBSED_MouseClick;
			// 
			// txtMnameBSED
			// 
			txtMnameBSED.Enabled = false;
			txtMnameBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtMnameBSED.Location = new Point(127, 157);
			txtMnameBSED.Name = "txtMnameBSED";
			txtMnameBSED.Size = new Size(150, 28);
			txtMnameBSED.TabIndex = 102;
			// 
			// btnUpdateBSED
			// 
			btnUpdateBSED.BackColor = SystemColors.ButtonShadow;
			btnUpdateBSED.Enabled = false;
			btnUpdateBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnUpdateBSED.ForeColor = Color.MintCream;
			btnUpdateBSED.Location = new Point(3, 521);
			btnUpdateBSED.Name = "btnUpdateBSED";
			btnUpdateBSED.Size = new Size(140, 59);
			btnUpdateBSED.TabIndex = 117;
			btnUpdateBSED.Text = "UPDATE";
			btnUpdateBSED.UseVisualStyleBackColor = false;
			btnUpdateBSED.MouseClick += btnUpdateBSED_MouseClick;
			// 
			// txtFnameBSED
			// 
			txtFnameBSED.Enabled = false;
			txtFnameBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtFnameBSED.Location = new Point(107, 126);
			txtFnameBSED.Name = "txtFnameBSED";
			txtFnameBSED.Size = new Size(169, 28);
			txtFnameBSED.TabIndex = 100;
			// 
			// btnAddBSED
			// 
			btnAddBSED.BackColor = SystemColors.ButtonShadow;
			btnAddBSED.Enabled = false;
			btnAddBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnAddBSED.ForeColor = Color.MintCream;
			btnAddBSED.Location = new Point(158, 456);
			btnAddBSED.Name = "btnAddBSED";
			btnAddBSED.Size = new Size(140, 59);
			btnAddBSED.TabIndex = 116;
			btnAddBSED.Text = "ADD";
			btnAddBSED.UseVisualStyleBackColor = false;
			btnAddBSED.MouseClick += btnAddBSED_MouseClick;
			// 
			// label17
			// 
			label17.AutoSize = true;
			label17.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label17.Location = new Point(81, 31);
			label17.Name = "label17";
			label17.Size = new Size(157, 32);
			label17.TabIndex = 21;
			label17.Text = "REGISTER";
			// 
			// btnNewBSED
			// 
			btnNewBSED.BackColor = SystemColors.ButtonShadow;
			btnNewBSED.Enabled = false;
			btnNewBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnNewBSED.ForeColor = Color.MintCream;
			btnNewBSED.Location = new Point(3, 456);
			btnNewBSED.Name = "btnNewBSED";
			btnNewBSED.Size = new Size(140, 59);
			btnNewBSED.TabIndex = 115;
			btnNewBSED.Text = "NEW";
			btnNewBSED.UseVisualStyleBackColor = false;
			btnNewBSED.MouseClick += btnNewBSED_MouseClick;
			// 
			// listViewBSED
			// 
			listViewBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			listViewBSED.Location = new Point(307, 56);
			listViewBSED.Name = "listViewBSED";
			listViewBSED.Size = new Size(1083, 521);
			listViewBSED.TabIndex = 1;
			listViewBSED.UseCompatibleStateImageBehavior = false;
			listViewBSED.View = View.Details;
			listViewBSED.MouseClick += listViewBSED_MouseClick;
			// 
			// dateTimePickerBSED
			// 
			dateTimePickerBSED.Enabled = false;
			dateTimePickerBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			dateTimePickerBSED.Location = new Point(3, 419);
			dateTimePickerBSED.Name = "dateTimePickerBSED";
			dateTimePickerBSED.Size = new Size(300, 28);
			dateTimePickerBSED.TabIndex = 114;
			// 
			// label8
			// 
			label8.AutoSize = true;
			label8.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label8.Location = new Point(790, 21);
			label8.Name = "label8";
			label8.Size = new Size(91, 32);
			label8.TabIndex = 0;
			label8.Text = "BSED";
			// 
			// label90
			// 
			label90.AutoSize = true;
			label90.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label90.Location = new Point(3, 391);
			label90.Name = "label90";
			label90.Size = new Size(140, 25);
			label90.TabIndex = 113;
			label90.Text = "Date of Birth:";
			// 
			// label82
			// 
			label82.AutoSize = true;
			label82.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label82.Location = new Point(11, 89);
			label82.Name = "label82";
			label82.Size = new Size(40, 25);
			label82.TabIndex = 94;
			label82.Text = "ID:";
			// 
			// label89
			// 
			label89.AutoSize = true;
			label89.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label89.Location = new Point(3, 329);
			label89.Name = "label89";
			label89.Size = new Size(157, 25);
			label89.TabIndex = 111;
			label89.Text = "Email Address:";
			// 
			// txtEaddressBSED
			// 
			txtEaddressBSED.Enabled = false;
			txtEaddressBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtEaddressBSED.Location = new Point(3, 357);
			txtEaddressBSED.Name = "txtEaddressBSED";
			txtEaddressBSED.Size = new Size(281, 28);
			txtEaddressBSED.TabIndex = 112;
			// 
			// txtIdBSED
			// 
			txtIdBSED.Enabled = false;
			txtIdBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtIdBSED.Location = new Point(55, 86);
			txtIdBSED.Name = "txtIdBSED";
			txtIdBSED.Size = new Size(136, 28);
			txtIdBSED.TabIndex = 93;
			// 
			// label83
			// 
			label83.AutoSize = true;
			label83.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label83.Location = new Point(-2, 127);
			label83.Name = "label83";
			label83.Size = new Size(113, 25);
			label83.TabIndex = 97;
			label83.Text = "Firstname:";
			// 
			// txtAddressBSED
			// 
			txtAddressBSED.Enabled = false;
			txtAddressBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAddressBSED.Location = new Point(98, 298);
			txtAddressBSED.Name = "txtAddressBSED";
			txtAddressBSED.Size = new Size(200, 28);
			txtAddressBSED.TabIndex = 110;
			// 
			// label84
			// 
			label84.AutoSize = true;
			label84.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label84.Location = new Point(0, 157);
			label84.Name = "label84";
			label84.Size = new Size(135, 25);
			label84.TabIndex = 101;
			label84.Text = "Middlename:";
			// 
			// label88
			// 
			label88.AutoSize = true;
			label88.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label88.Location = new Point(0, 298);
			label88.Name = "label88";
			label88.Size = new Size(98, 25);
			label88.TabIndex = 109;
			label88.Text = "Address:";
			// 
			// label85
			// 
			label85.AutoSize = true;
			label85.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label85.Location = new Point(0, 191);
			label85.Name = "label85";
			label85.Size = new Size(112, 25);
			label85.TabIndex = 103;
			label85.Text = "Lastname:";
			// 
			// cbGenderBSED
			// 
			cbGenderBSED.Enabled = false;
			cbGenderBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			cbGenderBSED.FormattingEnabled = true;
			cbGenderBSED.Items.AddRange(new object[] { "MALE", "FEMALE" });
			cbGenderBSED.Location = new Point(98, 256);
			cbGenderBSED.Name = "cbGenderBSED";
			cbGenderBSED.Size = new Size(108, 29);
			cbGenderBSED.TabIndex = 108;
			// 
			// txtLnameBSED
			// 
			txtLnameBSED.Enabled = false;
			txtLnameBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtLnameBSED.Location = new Point(118, 191);
			txtLnameBSED.Name = "txtLnameBSED";
			txtLnameBSED.Size = new Size(169, 28);
			txtLnameBSED.TabIndex = 104;
			// 
			// label87
			// 
			label87.AutoSize = true;
			label87.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label87.Location = new Point(3, 259);
			label87.Name = "label87";
			label87.Size = new Size(89, 25);
			label87.TabIndex = 107;
			label87.Text = "Gender:";
			// 
			// label86
			// 
			label86.AutoSize = true;
			label86.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label86.Location = new Point(1, 225);
			label86.Name = "label86";
			label86.Size = new Size(57, 25);
			label86.TabIndex = 105;
			label86.Text = "Age:";
			// 
			// txtAgeBSED
			// 
			txtAgeBSED.Enabled = false;
			txtAgeBSED.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAgeBSED.Location = new Point(57, 225);
			txtAgeBSED.Name = "txtAgeBSED";
			txtAgeBSED.Size = new Size(39, 28);
			txtAgeBSED.TabIndex = 106;
			// 
			// SHSPANEL
			// 
			SHSPANEL.BackColor = SystemColors.ActiveCaption;
			SHSPANEL.Controls.Add(btnDeleteSHS);
			SHSPANEL.Controls.Add(txtMnameSHS);
			SHSPANEL.Controls.Add(btnUpdateSHS);
			SHSPANEL.Controls.Add(txtFnameSHS);
			SHSPANEL.Controls.Add(btnAddSHS);
			SHSPANEL.Controls.Add(label18);
			SHSPANEL.Controls.Add(btnNewSHS);
			SHSPANEL.Controls.Add(listViewSHS);
			SHSPANEL.Controls.Add(dateTimePickerSHS);
			SHSPANEL.Controls.Add(label9);
			SHSPANEL.Controls.Add(label99);
			SHSPANEL.Controls.Add(label91);
			SHSPANEL.Controls.Add(txtEaddressSHS);
			SHSPANEL.Controls.Add(txtIdSHS);
			SHSPANEL.Controls.Add(label98);
			SHSPANEL.Controls.Add(label92);
			SHSPANEL.Controls.Add(txtAddressSHS);
			SHSPANEL.Controls.Add(label93);
			SHSPANEL.Controls.Add(label97);
			SHSPANEL.Controls.Add(label94);
			SHSPANEL.Controls.Add(cbGenderSHS);
			SHSPANEL.Controls.Add(txtLnameSHS);
			SHSPANEL.Controls.Add(label96);
			SHSPANEL.Controls.Add(label95);
			SHSPANEL.Controls.Add(txtAgeSHS);
			SHSPANEL.Location = new Point(172, 100);
			SHSPANEL.Name = "SHSPANEL";
			SHSPANEL.Size = new Size(1408, 593);
			SHSPANEL.TabIndex = 20;
			SHSPANEL.Visible = false;
			// 
			// btnDeleteSHS
			// 
			btnDeleteSHS.BackColor = SystemColors.ButtonShadow;
			btnDeleteSHS.Enabled = false;
			btnDeleteSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnDeleteSHS.ForeColor = Color.MintCream;
			btnDeleteSHS.Location = new Point(157, 521);
			btnDeleteSHS.Name = "btnDeleteSHS";
			btnDeleteSHS.Size = new Size(140, 59);
			btnDeleteSHS.TabIndex = 119;
			btnDeleteSHS.Text = "DELETE";
			btnDeleteSHS.UseVisualStyleBackColor = false;
			btnDeleteSHS.MouseClick += button4_MouseClick;
			// 
			// txtMnameSHS
			// 
			txtMnameSHS.Enabled = false;
			txtMnameSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtMnameSHS.Location = new Point(127, 157);
			txtMnameSHS.Name = "txtMnameSHS";
			txtMnameSHS.Size = new Size(150, 28);
			txtMnameSHS.TabIndex = 103;
			txtMnameSHS.TextChanged += textBox3_TextChanged;
			// 
			// btnUpdateSHS
			// 
			btnUpdateSHS.BackColor = SystemColors.ButtonShadow;
			btnUpdateSHS.Enabled = false;
			btnUpdateSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnUpdateSHS.ForeColor = Color.MintCream;
			btnUpdateSHS.Location = new Point(3, 521);
			btnUpdateSHS.Name = "btnUpdateSHS";
			btnUpdateSHS.Size = new Size(140, 59);
			btnUpdateSHS.TabIndex = 118;
			btnUpdateSHS.Text = "UPDATE";
			btnUpdateSHS.UseVisualStyleBackColor = false;
			btnUpdateSHS.MouseClick += btnUpdateSHS_MouseClick;
			// 
			// txtFnameSHS
			// 
			txtFnameSHS.Enabled = false;
			txtFnameSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtFnameSHS.Location = new Point(107, 126);
			txtFnameSHS.Name = "txtFnameSHS";
			txtFnameSHS.Size = new Size(169, 28);
			txtFnameSHS.TabIndex = 101;
			// 
			// btnAddSHS
			// 
			btnAddSHS.BackColor = SystemColors.ButtonShadow;
			btnAddSHS.Enabled = false;
			btnAddSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnAddSHS.ForeColor = Color.MintCream;
			btnAddSHS.Location = new Point(158, 456);
			btnAddSHS.Name = "btnAddSHS";
			btnAddSHS.Size = new Size(140, 59);
			btnAddSHS.TabIndex = 117;
			btnAddSHS.Text = "ADD";
			btnAddSHS.UseVisualStyleBackColor = false;
			btnAddSHS.MouseClick += btnAddSHS_MouseClick;
			// 
			// label18
			// 
			label18.AutoSize = true;
			label18.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label18.Location = new Point(81, 31);
			label18.Name = "label18";
			label18.Size = new Size(157, 32);
			label18.TabIndex = 21;
			label18.Text = "REGISTER";
			// 
			// btnNewSHS
			// 
			btnNewSHS.BackColor = SystemColors.ButtonShadow;
			btnNewSHS.Enabled = false;
			btnNewSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			btnNewSHS.ForeColor = Color.MintCream;
			btnNewSHS.Location = new Point(3, 456);
			btnNewSHS.Name = "btnNewSHS";
			btnNewSHS.Size = new Size(140, 59);
			btnNewSHS.TabIndex = 116;
			btnNewSHS.Text = "NEW";
			btnNewSHS.UseVisualStyleBackColor = false;
			btnNewSHS.MouseClick += btnNewSHS_MouseClick;
			// 
			// listViewSHS
			// 
			listViewSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			listViewSHS.Location = new Point(307, 56);
			listViewSHS.Name = "listViewSHS";
			listViewSHS.Size = new Size(1083, 521);
			listViewSHS.TabIndex = 1;
			listViewSHS.UseCompatibleStateImageBehavior = false;
			listViewSHS.View = View.Details;
			listViewSHS.MouseClick += listViewSHS_MouseClick;
			// 
			// dateTimePickerSHS
			// 
			dateTimePickerSHS.Enabled = false;
			dateTimePickerSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			dateTimePickerSHS.Location = new Point(3, 419);
			dateTimePickerSHS.Name = "dateTimePickerSHS";
			dateTimePickerSHS.Size = new Size(300, 28);
			dateTimePickerSHS.TabIndex = 115;
			// 
			// label9
			// 
			label9.AutoSize = true;
			label9.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label9.Location = new Point(790, 21);
			label9.Name = "label9";
			label9.Size = new Size(72, 32);
			label9.TabIndex = 0;
			label9.Text = "SHS";
			// 
			// label99
			// 
			label99.AutoSize = true;
			label99.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label99.Location = new Point(3, 391);
			label99.Name = "label99";
			label99.Size = new Size(140, 25);
			label99.TabIndex = 114;
			label99.Text = "Date of Birth:";
			// 
			// label91
			// 
			label91.AutoSize = true;
			label91.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label91.Location = new Point(11, 89);
			label91.Name = "label91";
			label91.Size = new Size(40, 25);
			label91.TabIndex = 95;
			label91.Text = "ID:";
			// 
			// txtEaddressSHS
			// 
			txtEaddressSHS.Enabled = false;
			txtEaddressSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtEaddressSHS.Location = new Point(3, 357);
			txtEaddressSHS.Name = "txtEaddressSHS";
			txtEaddressSHS.Size = new Size(281, 28);
			txtEaddressSHS.TabIndex = 113;
			txtEaddressSHS.TextChanged += textBox7_TextChanged;
			// 
			// txtIdSHS
			// 
			txtIdSHS.Enabled = false;
			txtIdSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtIdSHS.Location = new Point(55, 86);
			txtIdSHS.Name = "txtIdSHS";
			txtIdSHS.Size = new Size(136, 28);
			txtIdSHS.TabIndex = 96;
			// 
			// label98
			// 
			label98.AutoSize = true;
			label98.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label98.Location = new Point(3, 329);
			label98.Name = "label98";
			label98.Size = new Size(157, 25);
			label98.TabIndex = 112;
			label98.Text = "Email Address:";
			// 
			// label92
			// 
			label92.AutoSize = true;
			label92.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label92.Location = new Point(0, 126);
			label92.Name = "label92";
			label92.Size = new Size(113, 25);
			label92.TabIndex = 98;
			label92.Text = "Firstname:";
			// 
			// txtAddressSHS
			// 
			txtAddressSHS.Enabled = false;
			txtAddressSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAddressSHS.Location = new Point(98, 298);
			txtAddressSHS.Name = "txtAddressSHS";
			txtAddressSHS.Size = new Size(200, 28);
			txtAddressSHS.TabIndex = 111;
			// 
			// label93
			// 
			label93.AutoSize = true;
			label93.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label93.Location = new Point(0, 157);
			label93.Name = "label93";
			label93.Size = new Size(135, 25);
			label93.TabIndex = 102;
			label93.Text = "Middlename:";
			// 
			// label97
			// 
			label97.AutoSize = true;
			label97.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label97.Location = new Point(0, 298);
			label97.Name = "label97";
			label97.Size = new Size(98, 25);
			label97.TabIndex = 110;
			label97.Text = "Address:";
			// 
			// label94
			// 
			label94.AutoSize = true;
			label94.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label94.Location = new Point(0, 191);
			label94.Name = "label94";
			label94.Size = new Size(112, 25);
			label94.TabIndex = 104;
			label94.Text = "Lastname:";
			// 
			// cbGenderSHS
			// 
			cbGenderSHS.Enabled = false;
			cbGenderSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			cbGenderSHS.FormattingEnabled = true;
			cbGenderSHS.Items.AddRange(new object[] { "MALE", "FEMALE" });
			cbGenderSHS.Location = new Point(98, 256);
			cbGenderSHS.Name = "cbGenderSHS";
			cbGenderSHS.Size = new Size(108, 29);
			cbGenderSHS.TabIndex = 109;
			// 
			// txtLnameSHS
			// 
			txtLnameSHS.Enabled = false;
			txtLnameSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtLnameSHS.Location = new Point(118, 191);
			txtLnameSHS.Name = "txtLnameSHS";
			txtLnameSHS.Size = new Size(159, 28);
			txtLnameSHS.TabIndex = 105;
			// 
			// label96
			// 
			label96.AutoSize = true;
			label96.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label96.Location = new Point(3, 259);
			label96.Name = "label96";
			label96.Size = new Size(89, 25);
			label96.TabIndex = 108;
			label96.Text = "Gender:";
			// 
			// label95
			// 
			label95.AutoSize = true;
			label95.Font = new Font("Arial", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label95.Location = new Point(1, 225);
			label95.Name = "label95";
			label95.Size = new Size(57, 25);
			label95.TabIndex = 106;
			label95.Text = "Age:";
			// 
			// txtAgeSHS
			// 
			txtAgeSHS.Enabled = false;
			txtAgeSHS.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtAgeSHS.Location = new Point(57, 225);
			txtAgeSHS.Name = "txtAgeSHS";
			txtAgeSHS.Size = new Size(39, 28);
			txtAgeSHS.TabIndex = 107;
			// 
			// btnLogout
			// 
			btnLogout.Location = new Point(11, 528);
			btnLogout.Name = "btnLogout";
			btnLogout.Size = new Size(139, 59);
			btnLogout.TabIndex = 21;
			btnLogout.Text = "LOGOUT";
			btnLogout.UseVisualStyleBackColor = true;
			btnLogout.MouseClick += btnLogout_MouseClick;
			// 
			// btnCourses
			// 
			btnCourses.Location = new Point(13, 20);
			btnCourses.Name = "btnCourses";
			btnCourses.Size = new Size(139, 58);
			btnCourses.TabIndex = 22;
			btnCourses.Text = "COURSES";
			btnCourses.UseVisualStyleBackColor = true;
			btnCourses.MouseClick += btnCourses_MouseClick;
			// 
			// panel2
			// 
			panel2.BackColor = SystemColors.ActiveCaption;
			panel2.Location = new Point(175, -1);
			panel2.Name = "panel2";
			panel2.Size = new Size(1405, 95);
			panel2.TabIndex = 23;
			// 
			// panel3
			// 
			panel3.BackColor = SystemColors.ActiveBorder;
			panel3.Location = new Point(1, 90);
			panel3.Name = "panel3";
			panel3.Size = new Size(171, 603);
			panel3.TabIndex = 25;
			// 
			// panel4
			// 
			panel4.BackColor = SystemColors.ActiveBorder;
			panel4.Controls.Add(btnERC);
			panel4.Controls.Add(btnSCHEDULE);
			panel4.Controls.Add(btnCourses);
			panel4.Controls.Add(btnLogout);
			panel4.Controls.Add(btnEDIT);
			panel4.Location = new Point(0, 90);
			panel4.Name = "panel4";
			panel4.Size = new Size(171, 603);
			panel4.TabIndex = 26;
			panel4.Visible = false;
			// 
			// btnERC
			// 
			btnERC.Location = new Point(13, 218);
			btnERC.Name = "btnERC";
			btnERC.Size = new Size(139, 58);
			btnERC.TabIndex = 30;
			btnERC.Text = "ERC";
			btnERC.UseVisualStyleBackColor = true;
			btnERC.MouseClick += btnERC_MouseClick;
			// 
			// btnSCHEDULE
			// 
			btnSCHEDULE.Location = new Point(11, 147);
			btnSCHEDULE.Name = "btnSCHEDULE";
			btnSCHEDULE.Size = new Size(139, 58);
			btnSCHEDULE.TabIndex = 27;
			btnSCHEDULE.Text = "SCHEDULE";
			btnSCHEDULE.UseVisualStyleBackColor = true;
			btnSCHEDULE.MouseClick += btnSCHEDULE_MouseClick;
			// 
			// PANELSDBSIT
			// 
			PANELSDBSIT.BackColor = Color.DarkViolet;
			PANELSDBSIT.Controls.Add(label100);
			PANELSDBSIT.Controls.Add(listViewSDBSIT);
			PANELSDBSIT.ForeColor = SystemColors.Window;
			PANELSDBSIT.Location = new Point(175, 100);
			PANELSDBSIT.Name = "PANELSDBSIT";
			PANELSDBSIT.Size = new Size(1405, 593);
			PANELSDBSIT.TabIndex = 27;
			PANELSDBSIT.Visible = false;
			// 
			// label100
			// 
			label100.AutoSize = true;
			label100.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label100.ForeColor = Color.Black;
			label100.Location = new Point(692, 99);
			label100.Name = "label100";
			label100.Size = new Size(76, 32);
			label100.TabIndex = 1;
			label100.Text = "BSIT";
			// 
			// listViewSDBSIT
			// 
			listViewSDBSIT.Location = new Point(380, 134);
			listViewSDBSIT.Name = "listViewSDBSIT";
			listViewSDBSIT.Size = new Size(689, 340);
			listViewSDBSIT.TabIndex = 0;
			listViewSDBSIT.UseCompatibleStateImageBehavior = false;
			listViewSDBSIT.View = View.Details;
			// 
			// panel5
			// 
			panel5.BackColor = SystemColors.ActiveCaption;
			panel5.Controls.Add(btnSDBSIT);
			panel5.Controls.Add(btnSDSHS);
			panel5.Controls.Add(btnSDBSBA);
			panel5.Controls.Add(btnSDBSED);
			panel5.Controls.Add(btnSDBSN);
			panel5.Controls.Add(btnSDBSHM);
			panel5.Controls.Add(btnSDBSCE);
			panel5.Controls.Add(btnSDBSCJ);
			panel5.Controls.Add(btnSDBSEE);
			panel5.Location = new Point(176, -1);
			panel5.Name = "panel5";
			panel5.Size = new Size(1402, 95);
			panel5.TabIndex = 28;
			panel5.Visible = false;
			// 
			// btnSDBSIT
			// 
			btnSDBSIT.BackColor = Color.DarkViolet;
			btnSDBSIT.Location = new Point(37, 22);
			btnSDBSIT.Name = "btnSDBSIT";
			btnSDBSIT.Size = new Size(125, 46);
			btnSDBSIT.TabIndex = 0;
			btnSDBSIT.Text = "BSIT";
			btnSDBSIT.UseVisualStyleBackColor = false;
			btnSDBSIT.MouseClick += btnSDBSIT_MouseClick;
			// 
			// btnSDSHS
			// 
			btnSDSHS.BackColor = Color.Peru;
			btnSDSHS.Location = new Point(1263, 22);
			btnSDSHS.Name = "btnSDSHS";
			btnSDSHS.Size = new Size(125, 46);
			btnSDSHS.TabIndex = 8;
			btnSDSHS.Text = "SHS";
			btnSDSHS.UseVisualStyleBackColor = false;
			btnSDSHS.MouseClick += btnSDSHS_MouseClick;
			// 
			// btnSDBSBA
			// 
			btnSDBSBA.BackColor = Color.Yellow;
			btnSDBSBA.Location = new Point(180, 22);
			btnSDBSBA.Name = "btnSDBSBA";
			btnSDBSBA.Size = new Size(125, 46);
			btnSDBSBA.TabIndex = 1;
			btnSDBSBA.Text = "BSBA";
			btnSDBSBA.UseVisualStyleBackColor = false;
			btnSDBSBA.MouseClick += btnSDBSBA_MouseClick;
			// 
			// btnSDBSED
			// 
			btnSDBSED.BackColor = Color.DodgerBlue;
			btnSDBSED.Location = new Point(1103, 22);
			btnSDBSED.Name = "btnSDBSED";
			btnSDBSED.Size = new Size(125, 46);
			btnSDBSED.TabIndex = 7;
			btnSDBSED.Text = "BSED";
			btnSDBSED.UseVisualStyleBackColor = false;
			btnSDBSED.MouseClick += btnSDBSED_MouseClick;
			// 
			// btnSDBSN
			// 
			btnSDBSN.BackColor = Color.Green;
			btnSDBSN.Location = new Point(326, 22);
			btnSDBSN.Name = "btnSDBSN";
			btnSDBSN.Size = new Size(125, 46);
			btnSDBSN.TabIndex = 2;
			btnSDBSN.Text = "BSN";
			btnSDBSN.UseVisualStyleBackColor = false;
			btnSDBSN.MouseClick += btnSDBSN_MouseClick;
			// 
			// btnSDBSHM
			// 
			btnSDBSHM.BackColor = Color.Pink;
			btnSDBSHM.Location = new Point(943, 22);
			btnSDBSHM.Name = "btnSDBSHM";
			btnSDBSHM.Size = new Size(125, 46);
			btnSDBSHM.TabIndex = 6;
			btnSDBSHM.Text = "BSHM";
			btnSDBSHM.UseVisualStyleBackColor = false;
			btnSDBSHM.MouseClick += button6_MouseClick;
			// 
			// btnSDBSCE
			// 
			btnSDBSCE.BackColor = Color.Orange;
			btnSDBSCE.Location = new Point(483, 22);
			btnSDBSCE.Name = "btnSDBSCE";
			btnSDBSCE.Size = new Size(125, 46);
			btnSDBSCE.TabIndex = 3;
			btnSDBSCE.Text = "BSCE";
			btnSDBSCE.UseVisualStyleBackColor = false;
			btnSDBSCE.MouseClick += btnSDBSCE_MouseClick;
			// 
			// btnSDBSCJ
			// 
			btnSDBSCJ.BackColor = Color.Red;
			btnSDBSCJ.Location = new Point(792, 22);
			btnSDBSCJ.Name = "btnSDBSCJ";
			btnSDBSCJ.Size = new Size(125, 46);
			btnSDBSCJ.TabIndex = 5;
			btnSDBSCJ.Text = "BSCJ";
			btnSDBSCJ.UseVisualStyleBackColor = false;
			btnSDBSCJ.MouseClick += btnSDBSCJ_MouseClick;
			// 
			// btnSDBSEE
			// 
			btnSDBSEE.BackColor = Color.Blue;
			btnSDBSEE.Location = new Point(638, 22);
			btnSDBSEE.Name = "btnSDBSEE";
			btnSDBSEE.Size = new Size(125, 46);
			btnSDBSEE.TabIndex = 4;
			btnSDBSEE.Text = "BSEE";
			btnSDBSEE.UseVisualStyleBackColor = false;
			btnSDBSEE.MouseClick += btnSDBSEE_MouseClick;
			// 
			// PANELSDBSN
			// 
			PANELSDBSN.BackColor = Color.Green;
			PANELSDBSN.Controls.Add(label101);
			PANELSDBSN.Controls.Add(listViewSDBSN);
			PANELSDBSN.ForeColor = SystemColors.Window;
			PANELSDBSN.Location = new Point(175, 100);
			PANELSDBSN.Name = "PANELSDBSN";
			PANELSDBSN.Size = new Size(1405, 593);
			PANELSDBSN.TabIndex = 29;
			PANELSDBSN.Visible = false;
			// 
			// label101
			// 
			label101.AutoSize = true;
			label101.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label101.ForeColor = Color.Black;
			label101.Location = new Point(692, 99);
			label101.Name = "label101";
			label101.Size = new Size(72, 32);
			label101.TabIndex = 1;
			label101.Text = "BSN";
			// 
			// listViewSDBSN
			// 
			listViewSDBSN.Location = new Point(380, 134);
			listViewSDBSN.Name = "listViewSDBSN";
			listViewSDBSN.Size = new Size(689, 340);
			listViewSDBSN.TabIndex = 0;
			listViewSDBSN.UseCompatibleStateImageBehavior = false;
			listViewSDBSN.View = View.Details;
			// 
			// Form2
			// 
			AutoScaleDimensions = new SizeF(10F, 25F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(1577, 683);
			Controls.Add(PANELSDBSN);
			Controls.Add(panel5);
			Controls.Add(PANELSDBSIT);
			Controls.Add(panel4);
			Controls.Add(panel3);
			Controls.Add(pictureBox1);
			Controls.Add(SHSPANEL);
			Controls.Add(BSEDPANEL);
			Controls.Add(BSHMPANEL);
			Controls.Add(BSCJPANEL);
			Controls.Add(PANELBSEE);
			Controls.Add(BSCEPANEL);
			Controls.Add(BSNPANEL);
			Controls.Add(BSBAPANEL);
			Controls.Add(BSITPANEL);
			Controls.Add(panel1);
			Controls.Add(panel2);
			Name = "Form2";
			Text = "Form2";
			Load += Form2_Load;
			panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			BSITPANEL.ResumeLayout(false);
			BSITPANEL.PerformLayout();
			BSBAPANEL.ResumeLayout(false);
			BSBAPANEL.PerformLayout();
			BSNPANEL.ResumeLayout(false);
			BSNPANEL.PerformLayout();
			BSCEPANEL.ResumeLayout(false);
			BSCEPANEL.PerformLayout();
			PANELBSEE.ResumeLayout(false);
			PANELBSEE.PerformLayout();
			BSCJPANEL.ResumeLayout(false);
			BSCJPANEL.PerformLayout();
			BSHMPANEL.ResumeLayout(false);
			BSHMPANEL.PerformLayout();
			BSEDPANEL.ResumeLayout(false);
			BSEDPANEL.PerformLayout();
			SHSPANEL.ResumeLayout(false);
			SHSPANEL.PerformLayout();
			panel4.ResumeLayout(false);
			PANELSDBSIT.ResumeLayout(false);
			PANELSDBSIT.PerformLayout();
			panel5.ResumeLayout(false);
			PANELSDBSN.ResumeLayout(false);
			PANELSDBSN.PerformLayout();
			ResumeLayout(false);
		}

		#endregion

		private Button BSITbtn;
		private Button BSBAbtn;
		private Button BSNbtn;
		private Button BSCEbtn;
		private Button BSEEbtn;
		private Button BSCJbtn;
		private Button BSHMbtn;
		private Button BSEDbtn;
		private Button SHSbtn;
		private Panel panel1;
		private Button btnEDIT;
		private Panel BSITPANEL;
		private ListView listViewBSIT;
		private Label label1;
		private Panel BSBAPANEL;
		private ListView listViewBSBA;
		private Label label2;
		private Panel BSNPANEL;
		private ListView listViewBSN;
		private Label label3;
		private Panel BSCEPANEL;
		private ListView listViewBSCE;
		private Label label4;
		private Panel SHSPANEL;
		private Panel PANELBSEE;
		private ListView listView1BSEE;
		private Label label5;
		private Panel BSCJPANEL;
		private ListView listViewBSCJ;
		private Label label6;
		private Panel BSHMPANEL;
		private ListView listViewBSHM;
		private Label label7;
		private Panel BSEDPANEL;
		private ListView listViewBSED;
		private Label label8;
		private ListView listViewSHS;
		private Label label9;
		private PictureBox pictureBox1;
		private Label label10;
		private Label label11;
		private Label label12;
		private Label label13;
		private Label label14;
		private Label label15;
		private Label label16;
		private Label label17;
		private Label label18;
		private Label label19;
		private TextBox textBoxIDBSIT;
		private Label label22;
		private TextBox textBoxMNAMEBSIT;
		private Label label21;
		private TextBox textBoxFNAMEBSIT;
		private TextBox textBoxAGEBSIT;
		private Label label23;
		private ComboBox bsitGENDER;
		private Label label24;
		private TextBox txtEaddressBSIT;
		private Label label25;
		private Label label26;
		private DateTimePicker dateTimePickerBSIT;
		private Label label27;
		private TextBox txtFnameBSBA;
		private Button btnAddBSBA;
		private Button btnUpdatebsit;
		private TextBox ID1;
		private Button Add1;
		private Button New1;
		private Button btnDeletebsit;
		private TextBox txtFnameBSIT;
		private TextBox txtMnameBSIT;
		private TextBox txtLnameBSIT;
		private TextBox txtAgeBSIT;
		private TextBox txtAddressBSIT;
		private Button btnLogout;
		private Label label20;
		private Label label29;
		private TextBox txtIDBSBA;
		private Label label30;
		private Label label31;
		private TextBox txtMnameBSBA;
		private Label label32;
		private TextBox txtLnameBSCE;
		private Label label33;
		private TextBox txtEaddressBSN;
		private Label label34;
		private ComboBox cbGenderBSCE;
		private Label label35;
		private TextBox txtAddressBSN;
		private Label label36;
		private Label label37;
		private TextBox txtEaddressBSBA;
		private DateTimePicker dateTimePicker1BSBA;
		private Button btnNewBSBA;
		private Button btnUpdateBSBA;
		private Button btnDeleteBSBA;
		private TextBox txtLnameBSBA;
		private TextBox txtFnameBSIT1;
		private TextBox bsbaAgetxt;
		private ComboBox cbGenderBSBA;
		private TextBox textAddressBSBA;
		private TextBox txtIdBSN;
		private Label label28;
		private Label label38;
		private TextBox txtFnameBSN;
		private Label label39;
		private TextBox txtMnameBSN;
		private Label label40;
		private TextBox txtLnameBSN;
		private Label label41;
		private TextBox txtAgeBSN;
		private Label label42;
		private ComboBox cbGenderBSN;
		private Label label43;
		private Label label44;
		private Label label45;
		private DateTimePicker dateTimePickerBSN;
		private Button btnDeleteBSN;
		private Button btnUpdateBSN;
		private Button btnAddBSN;
		private Button btnNewBSN;
		private TextBox txtIdBSCEE;
		private Label label46;
		private Label label47;
		private TextBox txtFnameBSCE;
		private Label label48;
		private TextBox txtMnameBSCE;
		private Label label49;
		private Label label50;
		private TextBox txtAgeBSCE;
		private Label label51;
		private Label label52;
		private TextBox txtAddressBSCE;
		private Label label53;
		private TextBox txtEaddressBSCE;
		private Label label54;
		private DateTimePicker dateTimePickerBSCE;
		private Button btnBSCENew;
		private Button btnAddBSCE;
		private Button btnUpdateBSCE;
		private Button btnDeleteBSCE;
		private Button btnNewBSCJ;
		private Button btnUpdateBSEE;
		private Button btnDeleteBSEE;
		private TextBox txtMnameBSCJ;
		private Label label55;
		private Label label56;
		private TextBox txtMnameBSEE;
		private Label label57;
		private TextBox txtLnameBSEE;
		private Label label58;
		private Label label59;
		private TextBox txtAgeBSEE;
		private Label label60;
		private ComboBox cbGenderBSEE;
		private Label label61;
		private TextBox txtAddressBSEE;
		private TextBox txtFnameBSEE;
		private TextBox txtEaddressBSEE;
		private Label label62;
		private DateTimePicker dateTimePickerBSEE;
		private Label label63;
		private TextBox txtIdBSEE;
		private Button btnNewbsee;
		private Button btnAddbsee;
		private TextBox txtIdBSCJ;
		private Label label64;
		private Label label65;
		private TextBox txtFnameBSCJ;
		private Label label66;
		private Label label67;
		private TextBox txtLnameBSCJ;
		private TextBox txtAgeBSCJ;
		private Label label68;
		private Label label69;
		private ComboBox cbGenderBSCJ;
		private Label label70;
		private TextBox txtAddressBSCJ;
		private Label label71;
		private TextBox txtEaddressBSCJ;
		private Label label72;
		private DateTimePicker dateTimePickerBSCJ;
		private Button btnAddBSCJ;
		private Button btnUpdateBSCJ;
		private Button btnDeleteBSCJ;
		private TextBox txtIdBSHM;
		private Label label73;
		private Label label74;
		private Label label75;
		private TextBox txtFnameBSHM;
		private TextBox txtMnameBSHM;
		private Label label76;
		private TextBox txtLnameBSHM;
		private Label label77;
		private TextBox txtAgeBSHM;
		private Label label78;
		private ComboBox cbGenderBSHM;
		private Label label79;
		private TextBox txtAddressBSHM;
		private Label label80;
		private TextBox txtEaddressBSHM;
		private Label label81;
		private DateTimePicker dateTimePickerBSHM;
		private Button btnNewBSHM;
		private Button btnAddBSHM;
		private Button btnUpdateBSHM;
		private Button btnDeleteBSHM;
		private TextBox txtIdBSED;
		private Label label82;
		private Label label83;
		private TextBox txtFnameBSED;
		private Label label84;
		private TextBox txtMnameBSED;
		private Label label85;
		private TextBox txtLnameBSED;
		private Label label86;
		private TextBox txtAgeBSED;
		private Label label87;
		private ComboBox cbGenderBSED;
		private Label label88;
		private TextBox txtAddressBSED;
		private Label label89;
		private TextBox txtEaddressBSED;
		private Label label90;
		private DateTimePicker dateTimePickerBSED;
		private Button btnNewBSED;
		private Button btnAddBSED;
		private Button btnUpdateBSED;
		private Button btnDeleteBSED;
		private Label label91;
		private TextBox txtIdSHS;
		private Label label92;
		private TextBox txtFnameSHS;
		private Label label93;
		private TextBox txtMnameSHS;
		private Label label94;
		private TextBox txtLnameSHS;
		private Label label95;
		private TextBox txtAgeSHS;
		private Label label96;
		private ComboBox cbGenderSHS;
		private Label label97;
		private TextBox txtAddressSHS;
		private Label label98;
		private TextBox txtEaddressSHS;
		private Label label99;
		private DateTimePicker dateTimePickerSHS;
		private Button btnNewSHS;
		private Button btnAddSHS;
		private Button btnUpdateSHS;
		private Button btnDeleteSHS;
		private Button btnCourses;
		private Panel panel2;
		private Panel panel3;
		private Panel panel4;
		private Button btnSCHEDULE;
		private Panel PANELSDBSIT;
		private Panel panel5;
		private Button btnSDBSIT;
		private Button btnSDSHS;
		private Button btnSDBSBA;
		private Button btnSDBSED;
		private Button btnSDBSN;
		private Button btnSDBSHM;
		private Button btnSDBSCE;
		private Button btnSDBSCJ;
		private Button btnSDBSEE;
		private Label label100;
		private ListView listViewSDBSIT;
		private Panel PANELSDBSN;
		private Label label101;
		private ListView listViewSDBSN;
		private Button btnERC;
	}
}