﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
	public partial class Form3 : Form
	{
		string role;
		public Form3(string userRole)
		{
			InitializeComponent();
			role = userRole;
		}

		private void btnAdd_MouseClick(object sender, MouseEventArgs e)
		{
			dataGridView1.Rows.Add(
			txtOffer.Text,
			txtSub.Text,
			txtTitle.Text,
			txtTime.Text,
			txtSchedule.Text

			);

			
		}

		private void btnPrint_MouseClick(object sender, MouseEventArgs e)
		{
			printDialog1.Document = printDocument1;

			if (printDialog1.ShowDialog() == DialogResult.OK)
			{
				printDocument1.Print();
			}
		}

		private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			Graphics g = e.Graphics;

			Font headerFont = new Font("Arial", 18, FontStyle.Bold);
			Font titleFont = new Font("Arial", 14, FontStyle.Bold);
			Font normalFont = new Font("Arial", 11);

			
			g.DrawImage(pictureBox1.Image, 50, 20, 100, 100);

			
			g.DrawString("ST. JOHN PAUL II COLLEGE OF DAVAO",
				headerFont, Brushes.Black, 180, 30);

			g.DrawString("Enrollment Registration Certificate",
				titleFont, Brushes.Black, 220, 70);

			
			g.DrawString( txtName.Text,
				normalFont, Brushes.Black, 50, 150);

			g.DrawString(txtCourse.Text,
				normalFont, Brushes.Black, 50, 180);

			g.DrawString( txtId.Text,
				normalFont, Brushes.Black, 500, 150);

			g.DrawString(  txtYear.Text,
				normalFont, Brushes.Black, 500, 180);

			
			int startX = 50;
			int startY = 250;

			
			g.DrawString("Offer Code", normalFont, Brushes.Black, startX, startY);
			g.DrawString("Subject", normalFont, Brushes.Black, startX + 120, startY);
			g.DrawString("Title", normalFont, Brushes.Black, startX + 250, startY);
			g.DrawString("Time", normalFont, Brushes.Black, startX + 450, startY);
			g.DrawString("Schedule", normalFont, Brushes.Black, startX + 550, startY);

			
			g.DrawLine(Pens.Black, startX, startY + 20, 750, startY + 20);

			startY += 40;

			
			foreach (DataGridViewRow row in dataGridView1.Rows)
			{
				if (!row.IsNewRow)
				{
					g.DrawString(row.Cells[0].Value?.ToString(),
						normalFont, Brushes.Black, startX, startY);

					g.DrawString(row.Cells[1].Value?.ToString(),
						normalFont, Brushes.Black, startX + 120, startY);

					g.DrawString(row.Cells[2].Value?.ToString(),
						normalFont, Brushes.Black, startX + 250, startY);

					g.DrawString(row.Cells[3].Value?.ToString(),
						normalFont, Brushes.Black, startX + 450, startY);

					g.DrawString(row.Cells[4].Value?.ToString(),
						normalFont, Brushes.Black, startX + 550, startY);

					startY += 30;
				}
			}
		}

		private void btnBack_MouseClick(object sender, MouseEventArgs e)
		{
			Form2 form = new Form2(role);
			form.Show();
			this.Hide();
		}
	}
}
