﻿namespace WinFormsApp1
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			studentbtn = new Button();
			facultybtn = new Button();
			adminbtn = new Button();
			panel1 = new Panel();
			studentuser = new TextBox();
			label3 = new Label();
			textpass1 = new TextBox();
			label2 = new Label();
			label1 = new Label();
			loginbtn1 = new Button();
			textuser1 = new TextBox();
			panel2 = new Panel();
			txtpass1 = new TextBox();
			label6 = new Label();
			loginbtn2 = new Button();
			label4 = new Label();
			label5 = new Label();
			textpass2 = new TextBox();
			panel3 = new Panel();
			loginbtn3 = new Button();
			label9 = new Label();
			label7 = new Label();
			label8 = new Label();
			textuser2 = new TextBox();
			panel4 = new Panel();
			pictureBox2 = new PictureBox();
			pictureBox1 = new PictureBox();
			panel5 = new Panel();
			panel6 = new Panel();
			label10 = new Label();
			panel1.SuspendLayout();
			panel2.SuspendLayout();
			panel3.SuspendLayout();
			panel4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			panel6.SuspendLayout();
			SuspendLayout();
			// 
			// studentbtn
			// 
			studentbtn.BackColor = SystemColors.ControlLightLight;
			studentbtn.Location = new Point(56, 175);
			studentbtn.Name = "studentbtn";
			studentbtn.Size = new Size(154, 92);
			studentbtn.TabIndex = 0;
			studentbtn.Text = "STUDENT";
			studentbtn.UseVisualStyleBackColor = false;
			studentbtn.Click += studentbtn_Click;
			studentbtn.MouseClick += studentbtn_MouseClick;
			// 
			// facultybtn
			// 
			facultybtn.Location = new Point(368, 175);
			facultybtn.Name = "facultybtn";
			facultybtn.Size = new Size(154, 92);
			facultybtn.TabIndex = 1;
			facultybtn.Text = "FACULTY";
			facultybtn.UseVisualStyleBackColor = true;
			facultybtn.MouseClick += facultybtn_MouseClick;
			// 
			// adminbtn
			// 
			adminbtn.Location = new Point(209, 298);
			adminbtn.Name = "adminbtn";
			adminbtn.Size = new Size(154, 92);
			adminbtn.TabIndex = 2;
			adminbtn.Text = "ADMIN";
			adminbtn.UseVisualStyleBackColor = true;
			adminbtn.MouseClick += adminbtn_MouseClick;
			// 
			// panel1
			// 
			panel1.BackColor = SystemColors.GradientActiveCaption;
			panel1.Controls.Add(studentuser);
			panel1.Controls.Add(label3);
			panel1.Controls.Add(textpass1);
			panel1.Controls.Add(label2);
			panel1.Controls.Add(label1);
			panel1.Controls.Add(loginbtn1);
			panel1.Location = new Point(-3, 132);
			panel1.Name = "panel1";
			panel1.Size = new Size(835, 499);
			panel1.TabIndex = 3;
			panel1.Visible = false;
			// 
			// studentuser
			// 
			studentuser.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			studentuser.Location = new Point(38, 197);
			studentuser.Name = "studentuser";
			studentuser.Size = new Size(271, 40);
			studentuser.TabIndex = 9;
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label3.Location = new Point(424, 241);
			label3.Name = "label3";
			label3.Size = new Size(144, 32);
			label3.TabIndex = 5;
			label3.Text = "STUDENT";
			// 
			// textpass1
			// 
			textpass1.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			textpass1.Location = new Point(38, 320);
			textpass1.Name = "textpass1";
			textpass1.Size = new Size(271, 40);
			textpass1.TabIndex = 4;
			textpass1.UseSystemPasswordChar = true;
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label2.Location = new Point(37, 274);
			label2.Name = "label2";
			label2.Size = new Size(151, 32);
			label2.TabIndex = 3;
			label2.Text = "Password: ";
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label1.Location = new Point(37, 142);
			label1.Name = "label1";
			label1.Size = new Size(150, 32);
			label1.TabIndex = 1;
			label1.Text = "Username:";
			// 
			// loginbtn1
			// 
			loginbtn1.Location = new Point(385, 338);
			loginbtn1.Name = "loginbtn1";
			loginbtn1.Size = new Size(161, 68);
			loginbtn1.TabIndex = 0;
			loginbtn1.Text = "LOGIN";
			loginbtn1.UseVisualStyleBackColor = true;
			loginbtn1.Click += loginbtn1_Click;
			// 
			// textuser1
			// 
			textuser1.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			textuser1.Location = new Point(38, 197);
			textuser1.Name = "textuser1";
			textuser1.Size = new Size(271, 40);
			textuser1.TabIndex = 7;
			// 
			// panel2
			// 
			panel2.BackColor = SystemColors.GradientActiveCaption;
			panel2.Controls.Add(txtpass1);
			panel2.Controls.Add(label6);
			panel2.Controls.Add(loginbtn2);
			panel2.Controls.Add(textuser1);
			panel2.Controls.Add(label4);
			panel2.Controls.Add(label5);
			panel2.Location = new Point(-3, 132);
			panel2.Name = "panel2";
			panel2.Size = new Size(835, 499);
			panel2.TabIndex = 4;
			panel2.Visible = false;
			// 
			// txtpass1
			// 
			txtpass1.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			txtpass1.Location = new Point(38, 320);
			txtpass1.Name = "txtpass1";
			txtpass1.Size = new Size(271, 40);
			txtpass1.TabIndex = 8;
			txtpass1.UseSystemPasswordChar = true;
			// 
			// label6
			// 
			label6.AutoSize = true;
			label6.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label6.Location = new Point(424, 241);
			label6.Name = "label6";
			label6.Size = new Size(136, 32);
			label6.TabIndex = 6;
			label6.Text = "FACULTY";
			// 
			// loginbtn2
			// 
			loginbtn2.Location = new Point(385, 338);
			loginbtn2.Name = "loginbtn2";
			loginbtn2.Size = new Size(161, 68);
			loginbtn2.TabIndex = 6;
			loginbtn2.Text = "LOGIN";
			loginbtn2.UseVisualStyleBackColor = true;
			loginbtn2.Click += loginbtn2_Click;
			loginbtn2.MouseClick += loginbtn2_MouseClick;
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label4.Location = new Point(37, 142);
			label4.Name = "label4";
			label4.Size = new Size(150, 32);
			label4.TabIndex = 6;
			label4.Text = "Username:";
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label5.Location = new Point(37, 274);
			label5.Name = "label5";
			label5.Size = new Size(151, 32);
			label5.TabIndex = 6;
			label5.Text = "Password: ";
			// 
			// textpass2
			// 
			textpass2.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			textpass2.Location = new Point(38, 320);
			textpass2.Name = "textpass2";
			textpass2.Size = new Size(271, 40);
			textpass2.TabIndex = 9;
			textpass2.UseSystemPasswordChar = true;
			// 
			// panel3
			// 
			panel3.BackColor = SystemColors.GradientActiveCaption;
			panel3.Controls.Add(loginbtn3);
			panel3.Controls.Add(label9);
			panel3.Controls.Add(textpass2);
			panel3.Controls.Add(label7);
			panel3.Controls.Add(label8);
			panel3.Controls.Add(textuser2);
			panel3.Location = new Point(-3, 132);
			panel3.Name = "panel3";
			panel3.Size = new Size(835, 499);
			panel3.TabIndex = 5;
			panel3.Visible = false;
			// 
			// loginbtn3
			// 
			loginbtn3.Location = new Point(385, 338);
			loginbtn3.Name = "loginbtn3";
			loginbtn3.Size = new Size(161, 68);
			loginbtn3.TabIndex = 8;
			loginbtn3.Text = "LOGIN";
			loginbtn3.UseVisualStyleBackColor = true;
			loginbtn3.Click += loginbtn3_Click;
			loginbtn3.MouseClick += loginbtn3_MouseClick;
			// 
			// label9
			// 
			label9.AutoSize = true;
			label9.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label9.Location = new Point(424, 241);
			label9.Name = "label9";
			label9.Size = new Size(104, 32);
			label9.TabIndex = 8;
			label9.Text = "ADMIN";
			// 
			// label7
			// 
			label7.AutoSize = true;
			label7.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label7.Location = new Point(37, 142);
			label7.Name = "label7";
			label7.Size = new Size(150, 32);
			label7.TabIndex = 8;
			label7.Text = "Username:";
			// 
			// label8
			// 
			label8.AutoSize = true;
			label8.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label8.Location = new Point(37, 274);
			label8.Name = "label8";
			label8.Size = new Size(151, 32);
			label8.TabIndex = 8;
			label8.Text = "Password: ";
			// 
			// textuser2
			// 
			textuser2.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			textuser2.Location = new Point(38, 197);
			textuser2.Name = "textuser2";
			textuser2.Size = new Size(271, 40);
			textuser2.TabIndex = 8;
			// 
			// panel4
			// 
			panel4.BackColor = SystemColors.Highlight;
			panel4.Controls.Add(pictureBox2);
			panel4.Controls.Add(pictureBox1);
			panel4.Controls.Add(panel5);
			panel4.Location = new Point(-3, 1);
			panel4.Name = "panel4";
			panel4.Size = new Size(1389, 133);
			panel4.TabIndex = 6;
			// 
			// pictureBox2
			// 
			pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
			pictureBox2.Location = new Point(177, 0);
			pictureBox2.Name = "pictureBox2";
			pictureBox2.Size = new Size(1212, 133);
			pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
			pictureBox2.TabIndex = 9;
			pictureBox2.TabStop = false;
			// 
			// pictureBox1
			// 
			pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
			pictureBox1.Location = new Point(3, 0);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new Size(177, 133);
			pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
			pictureBox1.TabIndex = 8;
			pictureBox1.TabStop = false;
			// 
			// panel5
			// 
			panel5.Location = new Point(1039, 132);
			panel5.Name = "panel5";
			panel5.Size = new Size(300, 150);
			panel5.TabIndex = 7;
			// 
			// panel6
			// 
			panel6.BackColor = Color.Silver;
			panel6.Controls.Add(label10);
			panel6.Controls.Add(studentbtn);
			panel6.Controls.Add(facultybtn);
			panel6.Controls.Add(adminbtn);
			panel6.Location = new Point(830, 132);
			panel6.Name = "panel6";
			panel6.Size = new Size(556, 502);
			panel6.TabIndex = 7;
			// 
			// label10
			// 
			label10.AutoSize = true;
			label10.Font = new Font("Arial", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
			label10.Location = new Point(196, 118);
			label10.Name = "label10";
			label10.Size = new Size(167, 32);
			label10.TabIndex = 3;
			label10.Text = "Select a role";
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(10F, 25F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(1384, 621);
			Controls.Add(panel6);
			Controls.Add(panel4);
			Controls.Add(panel3);
			Controls.Add(panel2);
			Controls.Add(panel1);
			Name = "Form1";
			Text = "Form1";
			Load += Form1_Load;
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			panel2.ResumeLayout(false);
			panel2.PerformLayout();
			panel3.ResumeLayout(false);
			panel3.PerformLayout();
			panel4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			panel6.ResumeLayout(false);
			panel6.PerformLayout();
			ResumeLayout(false);
		}

		#endregion

		private Button studentbtn;
		private Button facultybtn;
		private Button adminbtn;
		private Panel panel1;
		private TextBox textuser1;
		private Label label1;
		private Button loginbtn1;
		private Label label3;
		private TextBox textpass1;
		private Label label2;
		private Panel panel2;
		private Label label4;
		private Label label5;
		private TextBox textpass2;
		private Label label6;
		private Button loginbtn2;
		private TextBox textuser2;
		private Panel panel3;
		private Button loginbtn3;
		private Label label9;
		private TextBox txtpass3;
		private Label label7;
		private Label label8;
		private TextBox textuser3;
		private TextBox txtpass1;
		private TextBox studentuser;
		private Panel panel4;
		private Panel panel5;
		private Panel panel6;
		private Label label10;
		private PictureBox pictureBox1;
		private PictureBox pictureBox2;
	}
}
