namespace WinFormsApp1
{
	public partial class Form1 : Form
	{
		string role = "";
		public Form1()
		{
			InitializeComponent();
		}

		private void studentbtn_Click(object sender, EventArgs e)
		{

		}

		private void studentbtn_MouseClick(object sender, MouseEventArgs e)
		{
			studentbtn.Enabled = false;
			facultybtn.Enabled = true;
			adminbtn.Enabled = true;
			panel1.Visible = true;
			panel2.Visible = false;
			panel3.Visible = false;
		}

		private void facultybtn_MouseClick(object sender, MouseEventArgs e)
		{
			studentbtn.Enabled = true;
			facultybtn.Enabled = false;
			adminbtn.Enabled = true;
			panel1.Visible = false;
			panel2.Visible = true;
			panel3.Visible = false;
		}

		private void adminbtn_MouseClick(object sender, MouseEventArgs e)
		{
			studentbtn.Enabled = true;
			facultybtn.Enabled = true;
			adminbtn.Enabled = false;
			panel1.Visible = false;
			panel2.Visible = false;
			panel3.Visible = true;
		}

		private void loginbtn1_Click(object sender, EventArgs e)
		{
			if (studentuser.Text == "Student" && textpass1.Text == "Student123")
			{
				

				role = "Student";

				Form2 form = new Form2(role);
				form.Show();
				this.Hide();
			}
			else
			{
				MessageBox.Show("Invalid Login");
			}
		}

		private void loginbtn2_Click(object sender, EventArgs e)
		{

		}

		private void loginbtn2_MouseClick(object sender, MouseEventArgs e)
		{
			if (textuser1.Text == "Faculty" && txtpass1.Text == "Faculty123")
			{
				

				role = "Faculty";

				Form2 form = new Form2(role);
				form.Show();
				this.Hide();
			}
			else
			{
				MessageBox.Show("Invalid Login");
			}
		}

		private void loginbtn3_Click(object sender, EventArgs e)
		{

		}

		private void loginbtn3_MouseClick(object sender, MouseEventArgs e)
		{
			if (textuser2.Text == "Admin" && textpass2.Text == "Admin123")
			{
				

				role = "Admin";

				Form2 form = new Form2(role);
				form.Show();
				this.Hide();
			}
			else
			{
				MessageBox.Show("Invalid Login");
			}
		}

		private void Form1_Load(object sender, EventArgs e)
		{

		}
	}
}
