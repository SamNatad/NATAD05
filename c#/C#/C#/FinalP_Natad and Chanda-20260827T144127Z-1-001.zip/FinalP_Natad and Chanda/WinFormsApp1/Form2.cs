﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WinFormsApp1
{
	public partial class Form2 : Form
	{
		string role;


		public Form2(string userRole)
		{
			InitializeComponent();
			role = userRole;
		}

		private void BSITbtn_Click(object sender, EventArgs e)
		{

		}

		private void BSITbtn_MouseClick(object sender, MouseEventArgs e)
		{
			BSITbtn.Enabled = false;
			BSBAbtn.Enabled = true;
			BSNbtn.Enabled = true;
			BSCEbtn.Enabled = true;
			BSEEbtn.Enabled = true;
			BSCJbtn.Enabled = true;
			BSHMbtn.Enabled = true;
			BSEDbtn.Enabled = true;
			SHSbtn.Enabled = true;

			BSITPANEL.Visible = true;
			BSBAPANEL.Visible = false;
			BSNPANEL.Visible = false;
			BSCEPANEL.Visible = false;
			PANELBSEE.Visible = false;
			BSCJPANEL.Visible = false;
			BSHMPANEL.Visible = false;
			BSEDPANEL.Visible = false;




		}

		private void BSBAbtn_MouseClick(object sender, MouseEventArgs e)
		{
			BSITbtn.Enabled = true;
			BSBAbtn.Enabled = false;
			BSNbtn.Enabled = true;
			BSCEbtn.Enabled = true;
			BSEEbtn.Enabled = true;
			BSCJbtn.Enabled = true;
			BSHMbtn.Enabled = true;
			BSEDbtn.Enabled = true;
			SHSbtn.Enabled = true;

			BSITPANEL.Visible = false;
			BSBAPANEL.Visible = true;
			BSNPANEL.Visible = false;
			BSCEPANEL.Visible = false;
			PANELBSEE.Visible = false;
			BSCJPANEL.Visible = false;
			BSHMPANEL.Visible = false;
			BSEDPANEL.Visible = false;
			SHSPANEL.Visible = false;


		}

		private void BSNbtn_MouseClick(object sender, MouseEventArgs e)
		{
			BSITbtn.Enabled = true;
			BSBAbtn.Enabled = true;
			BSNbtn.Enabled = false;
			BSCEbtn.Enabled = true;
			BSEEbtn.Enabled = true;
			BSCJbtn.Enabled = true;
			BSHMbtn.Enabled = true;
			BSEDbtn.Enabled = true;
			SHSbtn.Enabled = true;

			BSITPANEL.Visible = false;
			BSBAPANEL.Visible = false;
			BSNPANEL.Visible = true;
			BSCEPANEL.Visible = false;
			PANELBSEE.Visible = false;
			BSCJPANEL.Visible = false;
			BSHMPANEL.Visible = false;
			BSEDPANEL.Visible = false;
			SHSPANEL.Visible = false;


		}

		private void BSCEbtn_MouseClick(object sender, MouseEventArgs e)
		{
			BSITbtn.Enabled = true;
			BSBAbtn.Enabled = true;
			BSNbtn.Enabled = true;
			BSCEbtn.Enabled = false;
			BSEEbtn.Enabled = true;
			BSCJbtn.Enabled = true;
			BSHMbtn.Enabled = true;
			BSEDbtn.Enabled = true;
			SHSbtn.Enabled = true;

			BSITPANEL.Visible = false;
			BSBAPANEL.Visible = false;
			BSNPANEL.Visible = false;
			BSCEPANEL.Visible = true;
			PANELBSEE.Visible = false;
			BSCJPANEL.Visible = false;
			BSHMPANEL.Visible = false;
			BSEDPANEL.Visible = false;
			SHSPANEL.Visible = false;



		}

		private void BSEEbtn_MouseClick(object sender, MouseEventArgs e)
		{
			BSITbtn.Enabled = true;
			BSBAbtn.Enabled = true;
			BSNbtn.Enabled = true;
			BSCEbtn.Enabled = true;
			BSEEbtn.Enabled = false;
			BSCJbtn.Enabled = true;
			BSHMbtn.Enabled = true;
			BSEDbtn.Enabled = true;
			SHSbtn.Enabled = true;

			BSITPANEL.Visible = false;
			BSBAPANEL.Visible = false;
			BSNPANEL.Visible = false;
			BSCEPANEL.Visible = false;
			PANELBSEE.Visible = true;
			BSCJPANEL.Visible = false;
			BSHMPANEL.Visible = false;
			BSEDPANEL.Visible = false;
			SHSPANEL.Visible = false;


		}

		private void BSCJbtn_MouseClick(object sender, MouseEventArgs e)
		{
			BSITbtn.Enabled = true;
			BSBAbtn.Enabled = true;
			BSNbtn.Enabled = true;
			BSCEbtn.Enabled = true;
			BSEEbtn.Enabled = true;
			BSCJbtn.Enabled = false;
			BSHMbtn.Enabled = true;
			BSEDbtn.Enabled = true;
			SHSbtn.Enabled = true;

			BSITPANEL.Visible = false;
			BSBAPANEL.Visible = false;
			BSNPANEL.Visible = false;
			BSCEPANEL.Visible = false;
			PANELBSEE.Visible = false;
			BSCJPANEL.Visible = true;
			BSHMPANEL.Visible = false;
			BSEDPANEL.Visible = false;
			SHSPANEL.Visible = false;



		}

		private void BSHMbtn_MouseClick(object sender, MouseEventArgs e)
		{
			BSITbtn.Enabled = true;
			BSBAbtn.Enabled = true;
			BSNbtn.Enabled = true;
			BSCEbtn.Enabled = true;
			BSEEbtn.Enabled = true;
			BSCJbtn.Enabled = true;
			BSHMbtn.Enabled = false;
			BSEDbtn.Enabled = true;
			SHSbtn.Enabled = true;


			PANELSDBSIT.Visible = false;
			PANELSDBSN.Visible = false;

			BSITPANEL.Visible = false;
			BSBAPANEL.Visible = false;
			BSNPANEL.Visible = false;
			BSCEPANEL.Visible = false;
			PANELBSEE.Visible = false;
			BSCJPANEL.Visible = false;
			BSHMPANEL.Visible = true;
			BSEDPANEL.Visible = false;
			SHSPANEL.Visible = false;



		}

		private void BSEDbtn_MouseClick(object sender, MouseEventArgs e)
		{
			BSITbtn.Enabled = true;
			BSBAbtn.Enabled = true;
			BSNbtn.Enabled = true;
			BSCEbtn.Enabled = true;
			BSEEbtn.Enabled = true;
			BSCJbtn.Enabled = true;
			BSHMbtn.Enabled = true;
			BSEDbtn.Enabled = false;
			SHSbtn.Enabled = true;

			BSITPANEL.Visible = false;
			BSBAPANEL.Visible = false;
			BSNPANEL.Visible = false;
			BSCEPANEL.Visible = false;
			PANELBSEE.Visible = false;
			BSCJPANEL.Visible = false;
			BSHMPANEL.Visible = false;
			BSEDPANEL.Visible = true;
			SHSPANEL.Visible = false;


		}

		private void SHSbtn_MouseClick(object sender, MouseEventArgs e)
		{
			BSITbtn.Enabled = true;
			BSBAbtn.Enabled = true;
			BSNbtn.Enabled = true;
			BSCEbtn.Enabled = true;
			BSEEbtn.Enabled = true;
			BSCJbtn.Enabled = true;
			BSHMbtn.Enabled = true;
			BSEDbtn.Enabled = true;
			SHSbtn.Enabled = false;

			BSITPANEL.Visible = false;
			BSBAPANEL.Visible = false;
			BSNPANEL.Visible = false;
			BSCEPANEL.Visible = false;
			PANELBSEE.Visible = false;
			BSCJPANEL.Visible = false;
			BSHMPANEL.Visible = false;
			BSEDPANEL.Visible = false;
			SHSPANEL.Visible = true;


		}

		private void Form2_Load(object sender, EventArgs e)
		{
			if (role == "Student")
			{
				btnEDIT.Enabled = false;
				btnERC.Enabled = false;
			}
			else if (role == "Faculty")
			{
				btnEDIT.Enabled = false;
				btnERC.Enabled = false;

			}
			else if (role == "Admin")
			{
				btnEDIT.Enabled = true;
				btnERC.Enabled = true;
			}
			listViewBSIT.Columns.Add("ID", 80);
			listViewBSIT.Columns.Add("Firstname", 120);
			listViewBSIT.Columns.Add("Middlename", 120);
			listViewBSIT.Columns.Add("Lastname", 120);
			listViewBSIT.Columns.Add("Age", 50);
			listViewBSIT.Columns.Add("Gender", 100);
			listViewBSIT.Columns.Add("Address", 150);
			listViewBSIT.Columns.Add("Email Address", 180);
			listViewBSIT.Columns.Add("Date Of Birth", 150);

			listViewBSBA.Columns.Add("ID", 80);
			listViewBSBA.Columns.Add("Firstname", 120);
			listViewBSBA.Columns.Add("Middlename", 120);
			listViewBSBA.Columns.Add("Lastname", 120);
			listViewBSBA.Columns.Add("Age", 50);
			listViewBSBA.Columns.Add("Gender", 100);
			listViewBSBA.Columns.Add("Address", 150);
			listViewBSBA.Columns.Add("Email Address", 180);
			listViewBSBA.Columns.Add("Date Of Birth", 150);

			listViewBSN.Columns.Add("ID", 80);
			listViewBSN.Columns.Add("Firstname", 120);
			listViewBSN.Columns.Add("Middlename", 120);
			listViewBSN.Columns.Add("Lastname", 120);
			listViewBSN.Columns.Add("Age", 50);
			listViewBSN.Columns.Add("Gender", 100);
			listViewBSN.Columns.Add("Address", 150);
			listViewBSN.Columns.Add("Email Address", 180);
			listViewBSN.Columns.Add("Date Of Birth", 150);

			listViewBSCE.Columns.Add("ID", 80);
			listViewBSCE.Columns.Add("Firstname", 120);
			listViewBSCE.Columns.Add("Middlename", 120);
			listViewBSCE.Columns.Add("Lastname", 120);
			listViewBSCE.Columns.Add("Age", 50);
			listViewBSCE.Columns.Add("Gender", 100);
			listViewBSCE.Columns.Add("Address", 150);
			listViewBSCE.Columns.Add("Email Address", 180);
			listViewBSCE.Columns.Add("Date Of Birth", 150);

			listView1BSEE.Columns.Add("ID", 80);
			listView1BSEE.Columns.Add("Firstname", 120);
			listView1BSEE.Columns.Add("Middlename", 120);
			listView1BSEE.Columns.Add("Lastname", 120);
			listView1BSEE.Columns.Add("Age", 50);
			listView1BSEE.Columns.Add("Gender", 100);
			listView1BSEE.Columns.Add("Address", 150);
			listView1BSEE.Columns.Add("Email Address", 180);
			listView1BSEE.Columns.Add("Date Of Birth", 150);

			listViewBSCJ.Columns.Add("ID", 80);
			listViewBSCJ.Columns.Add("Firstname", 120);
			listViewBSCJ.Columns.Add("Middlename", 120);
			listViewBSCJ.Columns.Add("Lastname", 120);
			listViewBSCJ.Columns.Add("Age", 50);
			listViewBSCJ.Columns.Add("Gender", 100);
			listViewBSCJ.Columns.Add("Address", 150);
			listViewBSCJ.Columns.Add("Email Address", 180);
			listViewBSCJ.Columns.Add("Date Of Birth", 150);

			listViewBSHM.Columns.Add("ID", 80);
			listViewBSHM.Columns.Add("Firstname", 120);
			listViewBSHM.Columns.Add("Middlename", 120);
			listViewBSHM.Columns.Add("Lastname", 120);
			listViewBSHM.Columns.Add("Age", 50);
			listViewBSHM.Columns.Add("Gender", 100);
			listViewBSHM.Columns.Add("Address", 150);
			listViewBSHM.Columns.Add("Email Address", 180);
			listViewBSHM.Columns.Add("Date Of Birth", 150);

			listViewBSED.Columns.Add("ID", 80);
			listViewBSED.Columns.Add("Firstname", 120);
			listViewBSED.Columns.Add("Middlename", 120);
			listViewBSED.Columns.Add("Lastname", 120);
			listViewBSED.Columns.Add("Age", 50);
			listViewBSED.Columns.Add("Gender", 100);
			listViewBSED.Columns.Add("Address", 150);
			listViewBSED.Columns.Add("Email Address", 180);
			listViewBSED.Columns.Add("Date Of Birth", 150);

			listViewSHS.Columns.Add("ID", 80);
			listViewSHS.Columns.Add("Firstname", 120);
			listViewSHS.Columns.Add("Middlename", 120);
			listViewSHS.Columns.Add("Lastname", 120);
			listViewSHS.Columns.Add("Age", 50);
			listViewSHS.Columns.Add("Gender", 100);
			listViewSHS.Columns.Add("Address", 150);
			listViewSHS.Columns.Add("Email Address", 180);
			listViewSHS.Columns.Add("Date Of Birth", 150);


			listViewSDBSIT.Columns.Add("Code", 100);
			listViewSDBSIT.Columns.Add("Subject", 250);
			listViewSDBSIT.Columns.Add("Units", 80);

			listViewSDBSIT.Items.Add(new ListViewItem(new string[] { "CC102", "Computer Programming 1", "3" }));
			listViewSDBSIT.Items.Add(new ListViewItem(new string[] { "CC103", "Computer Programming 2", "3" }));
			listViewSDBSIT.Items.Add(new ListViewItem(new string[] { "GENELECTA", "Living in IT Era", "3" }));
			listViewSDBSIT.Items.Add(new ListViewItem(new string[] { "PELECT101", "Multimedia System", "3" }));

			listViewSDBSN.Columns.Add("Code", 100);
			listViewSDBSN.Columns.Add("Subject", 250);
			listViewSDBSN.Columns.Add("Units", 80);

			listViewSDBSN.Items.Add(new ListViewItem(new string[] { "BSN101", "Anatomy and Physiology", "3" }));
			listViewSDBSN.Items.Add(new ListViewItem(new string[] { "BSN102", "Fundamentals of Nursing", "3" }));
			listViewSDBSN.Items.Add(new ListViewItem(new string[] { "BSN103", "Biochemistry", "3" }));





			listViewBSIT.Items.Clear();

			foreach (Class1 student in StudentDataStore.bsitstudents)
			{
				ListViewItem item = new ListViewItem(student.ID);
				item.SubItems.Add(student.Firstname);
				item.SubItems.Add(student.Middlename);
				item.SubItems.Add(student.Lastname);
				item.SubItems.Add(student.Age);
				item.SubItems.Add(student.Gender);
				item.SubItems.Add(student.Address);
				item.SubItems.Add(student.EmailAddress);
				item.SubItems.Add(student.DateofBirth);

				listViewBSIT.Items.Add(item);

			}
			listViewBSBA.Items.Clear();

			foreach (Class1 student in StudentDataStore.bsbastudents)
			{
				ListViewItem item = new ListViewItem(student.ID);
				item.SubItems.Add(student.Firstname);
				item.SubItems.Add(student.Middlename);
				item.SubItems.Add(student.Lastname);
				item.SubItems.Add(student.Age);
				item.SubItems.Add(student.Gender);
				item.SubItems.Add(student.Address);
				item.SubItems.Add(student.EmailAddress);
				item.SubItems.Add(student.DateofBirth);

				listViewBSBA.Items.Add(item);

			}
			listViewBSN.Items.Clear();

			foreach (Class1 student in StudentDataStore.bsnstudents)
			{
				ListViewItem item = new ListViewItem(student.ID);
				item.SubItems.Add(student.Firstname);
				item.SubItems.Add(student.Middlename);
				item.SubItems.Add(student.Lastname);
				item.SubItems.Add(student.Age);
				item.SubItems.Add(student.Gender);
				item.SubItems.Add(student.Address);
				item.SubItems.Add(student.EmailAddress);
				item.SubItems.Add(student.DateofBirth);

				listViewBSN.Items.Add(item);

			}

			listViewBSCE.Items.Clear();

			foreach (Class1 student in StudentDataStore.bscestudents)
			{
				ListViewItem item = new ListViewItem(student.ID);
				item.SubItems.Add(student.Firstname);
				item.SubItems.Add(student.Middlename);
				item.SubItems.Add(student.Lastname);
				item.SubItems.Add(student.Age);
				item.SubItems.Add(student.Gender);
				item.SubItems.Add(student.Address);
				item.SubItems.Add(student.EmailAddress);
				item.SubItems.Add(student.DateofBirth);

				listViewBSCE.Items.Add(item);

			}

			listView1BSEE.Items.Clear();

			foreach (Class1 student in StudentDataStore.bseestudents)
			{
				ListViewItem item = new ListViewItem(student.ID);
				item.SubItems.Add(student.Firstname);
				item.SubItems.Add(student.Middlename);
				item.SubItems.Add(student.Lastname);
				item.SubItems.Add(student.Age);
				item.SubItems.Add(student.Gender);
				item.SubItems.Add(student.Address);
				item.SubItems.Add(student.EmailAddress);
				item.SubItems.Add(student.DateofBirth);

				listView1BSEE.Items.Add(item);

			}

			listViewBSCJ.Items.Clear();

			foreach (Class1 student in StudentDataStore.bscjstudents)
			{
				ListViewItem item = new ListViewItem(student.ID);
				item.SubItems.Add(student.Firstname);
				item.SubItems.Add(student.Middlename);
				item.SubItems.Add(student.Lastname);
				item.SubItems.Add(student.Age);
				item.SubItems.Add(student.Gender);
				item.SubItems.Add(student.Address);
				item.SubItems.Add(student.EmailAddress);
				item.SubItems.Add(student.DateofBirth);

				listViewBSCJ.Items.Add(item);

			}


			listViewBSHM.Items.Clear();

			foreach (Class1 student in StudentDataStore.bshmstudents)
			{
				ListViewItem item = new ListViewItem(student.ID);
				item.SubItems.Add(student.Firstname);
				item.SubItems.Add(student.Middlename);
				item.SubItems.Add(student.Lastname);
				item.SubItems.Add(student.Age);
				item.SubItems.Add(student.Gender);
				item.SubItems.Add(student.Address);
				item.SubItems.Add(student.EmailAddress);
				item.SubItems.Add(student.DateofBirth);

				listViewBSHM.Items.Add(item);

			}


			listViewBSED.Items.Clear();

			foreach (Class1 student in StudentDataStore.bsedstudents)
			{
				ListViewItem item = new ListViewItem(student.ID);
				item.SubItems.Add(student.Firstname);
				item.SubItems.Add(student.Middlename);
				item.SubItems.Add(student.Lastname);
				item.SubItems.Add(student.Age);
				item.SubItems.Add(student.Gender);
				item.SubItems.Add(student.Address);
				item.SubItems.Add(student.EmailAddress);
				item.SubItems.Add(student.DateofBirth);

				listViewBSED.Items.Add(item);

			}

			listViewSHS.Items.Clear();

			foreach (Class1 student in StudentDataStore.shsstudents)
			{
				ListViewItem item = new ListViewItem(student.ID);
				item.SubItems.Add(student.Firstname);
				item.SubItems.Add(student.Middlename);
				item.SubItems.Add(student.Lastname);
				item.SubItems.Add(student.Age);
				item.SubItems.Add(student.Gender);
				item.SubItems.Add(student.Address);
				item.SubItems.Add(student.EmailAddress);
				item.SubItems.Add(student.DateofBirth);

				listViewSHS.Items.Add(item);

			}

















		}

		private void btnEDIT_MouseClick(object sender, MouseEventArgs e)
		{

			MessageBox.Show("You can start edit now");
			btnEDIT.Visible = false;
			New1.Enabled = true;
			btnNewBSBA.Enabled = true;
			btnNewBSN.Enabled = true;
			btnBSCENew.Enabled = true;
			btnNewbsee.Enabled = true;
			btnNewBSCJ.Enabled = true;
			btnNewBSHM.Enabled = true;
			btnNewBSED.Enabled = true;
			btnNewSHS.Enabled = true;



		}

		private void New1_MouseClick(object sender, MouseEventArgs e)
		{
			New1.Enabled = false;
			Add1.Enabled = true;
			ID1.Enabled = true;
			txtFnameBSIT1.Enabled = true;
			txtMnameBSIT.Enabled = true;
			txtLnameBSIT.Enabled = true;
			txtAgeBSIT.Enabled = true;
			bsitGENDER.Enabled = true;
			txtAddressBSIT.Enabled = true;
			txtEaddressBSIT.Enabled = true;
			dateTimePickerBSIT.Enabled = true;


		}

		private void Add1_MouseClick(object sender, MouseEventArgs e)
		{
			ListViewItem Natad = new ListViewItem(ID1.Text);
			Natad.SubItems.Add(txtFnameBSIT1.Text);
			Natad.SubItems.Add(txtMnameBSIT.Text);
			Natad.SubItems.Add(txtLnameBSIT.Text);
			Natad.SubItems.Add(txtAgeBSIT.Text);
			Natad.SubItems.Add(bsitGENDER.Text);
			Natad.SubItems.Add(txtAddressBSIT.Text);
			Natad.SubItems.Add(txtEaddressBSIT.Text);
			Natad.SubItems.Add(dateTimePickerBSIT.Text);
			listViewBSIT.Items.Add(Natad);

			StudentDataStore.bsitstudents.Add(new Class1
			{
				ID = ID1.Text,
				Firstname = txtFnameBSIT.Text,
				Middlename = txtMnameBSIT.Text,
				Lastname = txtLnameBSIT.Text,
				Age = txtAgeBSIT.Text,
				Gender = bsitGENDER.Text,
				Address = txtAddressBSIT.Text,
				EmailAddress = txtEaddressBSIT.Text,
				DateofBirth = dateTimePickerBSIT.Text



			});



			New1.Enabled = true;
			Add1.Enabled = false;
			ID1.Enabled = false;
			txtFnameBSIT1.Enabled = false;
			txtMnameBSIT.Enabled = false;
			txtLnameBSIT.Enabled = false;
			txtAgeBSIT.Enabled = false;
			bsitGENDER.Enabled = false;
			txtAddressBSIT.Enabled = false;
			txtEaddressBSIT.Enabled = false;
			dateTimePickerBSIT.Enabled = false;


			ID1.Text = " ";
			txtFnameBSIT1.Text = " ";
			txtMnameBSIT.Text = " ";
			txtLnameBSIT.Text = " ";
			txtAgeBSIT.Text = " ";
			bsitGENDER.Text = " ";
			txtAddressBSIT.Text = " ";
			txtEaddressBSIT.Text = " ";
		}

		private void listViewBSIT_MouseClick(object sender, MouseEventArgs e)
		{

			if (role != "Admin")
			{
				return;
			}

			if (listViewBSIT.SelectedItems.Count > 0)
			{
				ID1.Text = listViewBSIT.SelectedItems[0].SubItems[0].Text;
				txtFnameBSIT1.Text = listViewBSIT.SelectedItems[0].SubItems[1].Text;
				txtMnameBSIT.Text = listViewBSIT.SelectedItems[0].SubItems[2].Text;
				txtLnameBSIT.Text = listViewBSIT.SelectedItems[0].SubItems[3].Text;
				txtAgeBSIT.Text = listViewBSIT.SelectedItems[0].SubItems[4].Text;
				bsitGENDER.Text = listViewBSIT.SelectedItems[0].SubItems[5].Text;
				txtAddressBSIT.Text = listViewBSIT.SelectedItems[0].SubItems[6].Text;
				txtEaddressBSIT.Text = listViewBSIT.SelectedItems[0].SubItems[7].Text;
				dateTimePickerBSIT.Text = listViewBSIT.SelectedItems[0].SubItems[8].Text;

				ID1.Enabled = true;
				txtFnameBSIT1.Enabled = true;
				txtMnameBSIT.Enabled = true;
				txtLnameBSIT.Enabled = true;
				txtAgeBSIT.Enabled = true;
				bsitGENDER.Enabled = true;
				txtAddressBSIT.Enabled = true;
				txtEaddressBSIT.Enabled = true;
				dateTimePickerBSIT.Enabled = true;
				Add1.Enabled = false;
				New1.Enabled = false;
				btnUpdatebsit.Enabled = true;
				btnDeletebsit.Enabled = true;





			}
		}

		private void btnUpdatebsit_MouseClick(object sender, MouseEventArgs e)
		{
			listViewBSIT.SelectedItems[0].SubItems[0].Text = ID1.Text;
			listViewBSIT.SelectedItems[0].SubItems[1].Text = txtFnameBSIT1.Text;
			listViewBSIT.SelectedItems[0].SubItems[2].Text = txtMnameBSIT.Text;
			listViewBSIT.SelectedItems[0].SubItems[3].Text = txtLnameBSIT.Text;
			listViewBSIT.SelectedItems[0].SubItems[4].Text = txtAgeBSIT.Text;
			listViewBSIT.SelectedItems[0].SubItems[5].Text = bsitGENDER.Text;
			listViewBSIT.SelectedItems[0].SubItems[6].Text = txtAddressBSIT.Text;
			listViewBSIT.SelectedItems[0].SubItems[7].Text = txtEaddressBSIT.Text;
			listViewBSIT.SelectedItems[0].SubItems[8].Text = dateTimePickerBSIT.Text;



			New1.Enabled = true;
			btnUpdatebsit.Enabled = false;
			btnDeletebsit.Enabled = false;
			ID1.Enabled = false;
			txtFnameBSIT1.Enabled = false;
			txtMnameBSIT.Enabled = false;
			txtLnameBSIT.Enabled = false;
			txtAgeBSIT.Enabled = false;
			bsitGENDER.Enabled = false;
			txtAddressBSIT.Enabled = false;
			txtEaddressBSIT.Enabled = false;
			dateTimePickerBSIT.Enabled = false;


			ID1.Text = " ";
			txtFnameBSIT1.Text = " ";
			txtMnameBSIT.Text = " ";
			txtLnameBSIT.Text = " ";
			txtAgeBSIT.Text = " ";
			bsitGENDER.Text = " ";
			txtAddressBSIT.Text = " ";
			txtEaddressBSIT.Text = " ";


		}

		private void btnDeletebsit_MouseClick(object sender, MouseEventArgs e)
		{
			if (listViewBSIT.SelectedItems.Count > 0)
			{
				int index = listViewBSIT.SelectedItems[0].Index;

				StudentDataStore.bsitstudents.RemoveAt(index);
				listViewBSIT.Items.RemoveAt(index);

				New1.Enabled = true;
				btnUpdatebsit.Enabled = false;
				btnDeletebsit.Enabled = false;
				ID1.Enabled = false;
				txtFnameBSIT1.Enabled = false;
				txtMnameBSIT.Enabled = false;
				txtLnameBSIT.Enabled = false;
				txtAgeBSIT.Enabled = false;
				bsitGENDER.Enabled = false;
				txtAddressBSIT.Enabled = false;
				txtEaddressBSIT.Enabled = false;
				dateTimePickerBSIT.Enabled = false;


				ID1.Text = " ";
				txtFnameBSIT1.Text = " ";
				txtMnameBSIT.Text = " ";
				txtLnameBSIT.Text = " ";
				txtAgeBSIT.Text = " ";
				bsitGENDER.Text = " ";
				txtAddressBSIT.Text = " ";
				txtEaddressBSIT.Text = " ";






			}
		}

		private void btnLogout_MouseClick(object sender, MouseEventArgs e)
		{

			MessageBox.Show("Are you sure you want to logout");

			Form1 form = new Form1();
			form.Show();
			this.Hide();
			
		}

		private void btnNewBSBA_MouseClick(object sender, MouseEventArgs e)
		{
			btnNewBSBA.Enabled = false;
			btnAddBSBA.Enabled = true;
			txtIDBSBA.Enabled = true;
			txtFnameBSBA.Enabled = true;
			txtMnameBSBA.Enabled = true;
			txtLnameBSBA.Enabled = true;
			bsbaAgetxt.Enabled = true;
			cbGenderBSBA.Enabled = true;
			textAddressBSBA.Enabled = true;
			txtEaddressBSBA.Enabled = true;
			dateTimePicker1BSBA.Enabled = true;



		}

		private void btnAddBSBA_MouseClick(object sender, MouseEventArgs e)
		{
			ListViewItem BSBA = new ListViewItem(txtIDBSBA.Text);
			BSBA.SubItems.Add(txtFnameBSBA.Text);
			BSBA.SubItems.Add(txtMnameBSBA.Text);
			BSBA.SubItems.Add(txtLnameBSBA.Text);
			BSBA.SubItems.Add(bsbaAgetxt.Text);
			BSBA.SubItems.Add(cbGenderBSBA.Text);
			BSBA.SubItems.Add(textAddressBSBA.Text);
			BSBA.SubItems.Add(txtEaddressBSBA.Text);
			BSBA.SubItems.Add(dateTimePicker1BSBA.Text);

			listViewBSBA.Items.Add(BSBA);

			StudentDataStore.bsbastudents.Add(new Class1
			{
				ID = txtIDBSBA.Text,
				Firstname = txtFnameBSBA.Text,
				Middlename = txtMnameBSBA.Text,
				Lastname = txtLnameBSBA.Text,
				Age = bsbaAgetxt.Text,
				Gender = cbGenderBSBA.Text,
				Address = textAddressBSBA.Text,
				EmailAddress = txtEaddressBSBA.Text,
				DateofBirth = dateTimePicker1BSBA.Text


			});
			btnNewBSBA.Enabled = true;
			btnAddBSBA.Enabled = false;
			txtIDBSBA.Enabled = false;
			txtFnameBSBA.Enabled = false;
			txtMnameBSBA.Enabled = false;
			txtLnameBSBA.Enabled = false;
			bsbaAgetxt.Enabled = false;
			cbGenderBSBA.Enabled = false;
			textAddressBSBA.Enabled = false;
			txtEaddressBSBA.Enabled = false;
			dateTimePicker1BSBA.Enabled = false;


			txtIDBSBA.Text = " ";
			txtFnameBSBA.Text = " ";
			txtMnameBSBA.Text = " ";
			txtLnameBSBA.Text = " ";
			bsbaAgetxt.Text = " ";
			cbGenderBSBA.Text = " ";
			textAddressBSBA.Text = " ";
			txtEaddressBSBA.Text = " ";




		}

		private void btnUpdateBSBA_MouseClick(object sender, MouseEventArgs e)
		{
			listViewBSBA.SelectedItems[0].SubItems[0].Text = txtIDBSBA.Text;
			listViewBSBA.SelectedItems[0].SubItems[1].Text = txtFnameBSBA.Text;
			listViewBSBA.SelectedItems[0].SubItems[2].Text = txtMnameBSBA.Text;
			listViewBSBA.SelectedItems[0].SubItems[3].Text = txtLnameBSBA.Text;
			listViewBSBA.SelectedItems[0].SubItems[4].Text = bsbaAgetxt.Text;
			listViewBSBA.SelectedItems[0].SubItems[5].Text = cbGenderBSBA.Text;
			listViewBSBA.SelectedItems[0].SubItems[6].Text = textAddressBSBA.Text;
			listViewBSBA.SelectedItems[0].SubItems[7].Text = txtEaddressBSBA.Text;
			listViewBSBA.SelectedItems[0].SubItems[8].Text = dateTimePicker1BSBA.Text;



			btnNewBSBA.Enabled = true;
			txtIDBSBA.Enabled = false;
			txtFnameBSBA.Enabled = false;
			txtMnameBSBA.Enabled = false;
			txtLnameBSBA.Enabled = false;
			bsbaAgetxt.Enabled = false;
			cbGenderBSBA.Enabled = false;
			textAddressBSBA.Enabled = false;
			txtEaddressBSBA.Enabled = false;
			dateTimePicker1BSBA.Enabled = false;



			btnUpdateBSBA.Enabled = false;
			btnDeleteBSBA.Enabled = false;

			txtIDBSBA.Text = " ";
			txtFnameBSBA.Text = " ";
			txtMnameBSBA.Text = " ";
			txtLnameBSBA.Text = " ";
			bsbaAgetxt.Text = " ";
			cbGenderBSBA.Text = " ";
			textAddressBSBA.Text = " ";
			txtEaddressBSBA.Text = " ";



		}

		private void listViewBSBA_MouseClick(object sender, MouseEventArgs e)
		{

			if (role != "Admin")
			{
				return;
			}
			if (listViewBSBA.SelectedItems.Count > 0)
			{
				txtIDBSBA.Text = listViewBSBA.SelectedItems[0].SubItems[0].Text;
				txtFnameBSBA.Text = listViewBSBA.SelectedItems[0].SubItems[1].Text;
				txtMnameBSBA.Text = listViewBSBA.SelectedItems[0].SubItems[2].Text;
				txtLnameBSBA.Text = listViewBSBA.SelectedItems[0].SubItems[3].Text;
				bsbaAgetxt.Text = listViewBSBA.SelectedItems[0].SubItems[4].Text;
				cbGenderBSBA.Text = listViewBSBA.SelectedItems[0].SubItems[5].Text;
				textAddressBSBA.Text = listViewBSBA.SelectedItems[0].SubItems[6].Text;
				txtEaddressBSBA.Text = listViewBSBA.SelectedItems[0].SubItems[7].Text;
				dateTimePicker1BSBA.Text = listViewBSBA.SelectedItems[0].SubItems[8].Text;


				btnNewBSBA.Enabled = false;
				btnAddBSBA.Enabled = false;
				txtIDBSBA.Enabled = true;
				txtFnameBSBA.Enabled = true;
				txtMnameBSBA.Enabled = true;
				txtLnameBSBA.Enabled = true;
				bsbaAgetxt.Enabled = true;
				cbGenderBSBA.Enabled = true;
				textAddressBSBA.Enabled = true;
				txtEaddressBSBA.Enabled = true;
				dateTimePicker1BSBA.Enabled = true;



				btnUpdateBSBA.Enabled = true;
				btnDeleteBSBA.Enabled = true;




			}
		}

		private void btnDeleteBSBA_MouseClick(object sender, MouseEventArgs e)
		{
			if (listViewBSBA.SelectedItems.Count > 0)
			{
				int index = listViewBSBA.SelectedItems[0].Index;

				StudentDataStore.bsbastudents.RemoveAt(index);
				listViewBSBA.Items.RemoveAt(index);

				btnNewBSBA.Enabled = true;
				txtIDBSBA.Enabled = false;
				txtFnameBSBA.Enabled = false;
				txtMnameBSBA.Enabled = false;
				txtLnameBSBA.Enabled = false;
				bsbaAgetxt.Enabled = false;
				cbGenderBSBA.Enabled = false;
				textAddressBSBA.Enabled = false;
				txtEaddressBSBA.Enabled = false;
				dateTimePicker1BSBA.Enabled = false;


				btnUpdateBSBA.Enabled = false;
				btnDeleteBSBA.Enabled = false;

				txtIDBSBA.Text = " ";
				txtFnameBSBA.Text = " ";
				txtMnameBSBA.Text = " ";
				txtLnameBSBA.Text = " ";
				bsbaAgetxt.Text = " ";
				cbGenderBSBA.Text = " ";
				textAddressBSBA.Text = " ";
				txtEaddressBSBA.Text = " ";
			}

		}

		private void btnNewBSN_MouseClick(object sender, MouseEventArgs e)
		{
			btnNewBSN.Enabled = false;
			btnAddBSN.Enabled = true;
			txtIdBSN.Enabled = true;
			txtFnameBSN.Enabled = true;
			txtMnameBSN.Enabled = true;
			txtLnameBSN.Enabled = true;
			txtAgeBSN.Enabled = true;
			cbGenderBSN.Enabled = true;
			txtAddressBSN.Enabled = true;
			txtEaddressBSN.Enabled = true;
			dateTimePickerBSN.Enabled = true;
		}

		private void btnAddBSN_MouseClick(object sender, MouseEventArgs e)
		{
			ListViewItem BSN = new ListViewItem(txtIdBSN.Text);
			BSN.SubItems.Add(txtFnameBSN.Text);
			BSN.SubItems.Add(txtMnameBSN.Text);
			BSN.SubItems.Add(txtLnameBSBA.Text);
			BSN.SubItems.Add(txtAgeBSN.Text);
			BSN.SubItems.Add(cbGenderBSBA.Text);
			BSN.SubItems.Add(txtAddressBSN.Text);
			BSN.SubItems.Add(txtEaddressBSN.Text);
			BSN.SubItems.Add(dateTimePickerBSN.Text);
			listViewBSN.Items.Add(BSN);

			StudentDataStore.bsnstudents.Add(new Class1
			{
				ID = txtIdBSN.Text,
				Firstname = txtFnameBSN.Text,
				Middlename = txtMnameBSN.Text,
				Lastname = txtLnameBSN.Text,
				Age = txtAgeBSN.Text,
				Gender = cbGenderBSN.Text,
				Address = txtAddressBSN.Text,
				EmailAddress = txtEaddressBSN.Text,
				DateofBirth = dateTimePickerBSN.Text


			});
			btnNewBSN.Enabled = true;
			btnAddBSN.Enabled = false;
			txtIdBSN.Enabled = false;
			txtFnameBSN.Enabled = false;
			txtMnameBSN.Enabled = false;
			txtLnameBSN.Enabled = false;
			txtAgeBSN.Enabled = false;
			cbGenderBSN.Enabled = false;
			txtAddressBSN.Enabled = false;
			txtEaddressBSN.Enabled = false;
			dateTimePickerBSN.Enabled = false;


			txtIdBSN.Text = " ";
			txtFnameBSN.Text = " ";
			txtMnameBSN.Text = " ";
			txtLnameBSN.Text = " ";
			txtAgeBSN.Text = " ";
			cbGenderBSN.Text = " ";
			txtAddressBSN.Text = " ";
			txtEaddressBSN.Text = " ";


		}

		private void btnUpdateBSN_MouseClick(object sender, MouseEventArgs e)
		{
			listViewBSN.SelectedItems[0].SubItems[0].Text = txtIdBSN.Text;
			listViewBSN.SelectedItems[0].SubItems[1].Text = txtFnameBSN.Text;
			listViewBSN.SelectedItems[0].SubItems[2].Text = txtMnameBSN.Text;
			listViewBSN.SelectedItems[0].SubItems[3].Text = txtLnameBSN.Text;
			listViewBSN.SelectedItems[0].SubItems[4].Text = txtAgeBSN.Text;
			listViewBSN.SelectedItems[0].SubItems[5].Text = cbGenderBSN.Text;
			listViewBSN.SelectedItems[0].SubItems[6].Text = txtAddressBSN.Text;
			listViewBSN.SelectedItems[0].SubItems[7].Text = txtEaddressBSN.Text;
			listViewBSN.SelectedItems[0].SubItems[8].Text = dateTimePickerBSN.Text;

			btnNewBSN.Enabled = true;
			btnAddBSN.Enabled = false;
			txtIdBSN.Enabled = false;
			txtFnameBSN.Enabled = false;
			txtMnameBSN.Enabled = false;
			txtLnameBSN.Enabled = false;
			txtAgeBSN.Enabled = false;
			cbGenderBSN.Enabled = false;
			txtAddressBSN.Enabled = false;
			txtEaddressBSN.Enabled = false;
			dateTimePickerBSN.Enabled = false;

			btnUpdateBSN.Enabled = false;
			btnDeleteBSN.Enabled = false;

			txtIdBSN.Text = " ";
			txtFnameBSN.Text = " ";
			txtMnameBSN.Text = " ";
			txtLnameBSN.Text = " ";
			txtAgeBSN.Text = " ";
			cbGenderBSN.Text = " ";
			txtAddressBSN.Text = " ";
			txtEaddressBSN.Text = " ";



		}

		private void listViewBSN_MouseClick(object sender, MouseEventArgs e)
		{

			if (role != "Admin")
			{
				return;
			}

			if (listViewBSN.SelectedItems.Count > 0)
			{
				txtIdBSN.Text = listViewBSN.SelectedItems[0].SubItems[0].Text;
				txtFnameBSN.Text = listViewBSN.SelectedItems[0].SubItems[1].Text;
				txtMnameBSN.Text = listViewBSN.SelectedItems[0].SubItems[2].Text;
				txtLnameBSN.Text = listViewBSN.SelectedItems[0].SubItems[3].Text;
				txtAgeBSN.Text = listViewBSN.SelectedItems[0].SubItems[4].Text;
				cbGenderBSN.Text = listViewBSN.SelectedItems[0].SubItems[5].Text;
				txtAddressBSN.Text = listViewBSN.SelectedItems[0].SubItems[6].Text;
				txtEaddressBSN.Text = listViewBSN.SelectedItems[0].SubItems[7].Text;
				dateTimePickerBSN.Text = listViewBSN.SelectedItems[0].SubItems[8].Text;

				btnNewBSN.Enabled = false;
				btnAddBSN.Enabled = false;
				txtIdBSN.Enabled = true;
				txtFnameBSN.Enabled = true;
				txtMnameBSN.Enabled = true;
				txtLnameBSN.Enabled = true;
				txtAgeBSN.Enabled = true;
				cbGenderBSN.Enabled = true;
				txtAddressBSN.Enabled = true;
				txtEaddressBSN.Enabled = true;
				dateTimePickerBSN.Enabled = true;

				btnUpdateBSN.Enabled = true;
				btnDeleteBSN.Enabled = true;




			}
		}

		private void btnDeleteBSN_MouseClick(object sender, MouseEventArgs e)
		{
			if (listViewBSN.SelectedItems.Count > 0)
			{
				int index = listViewBSN.SelectedItems[0].Index;

				StudentDataStore.bsnstudents.RemoveAt(index);
				listViewBSN.Items.RemoveAt(index);

				btnNewBSN.Enabled = true;
				btnAddBSN.Enabled = false;
				txtIdBSN.Enabled = false;
				txtFnameBSN.Enabled = false;
				txtMnameBSN.Enabled = false;
				txtLnameBSN.Enabled = false;
				txtAgeBSN.Enabled = false;
				cbGenderBSN.Enabled = false;
				txtAddressBSN.Enabled = false;
				txtEaddressBSN.Enabled = false;
				dateTimePickerBSN.Enabled = false;

				btnUpdateBSN.Enabled = false;
				btnDeleteBSN.Enabled = false;

				txtIdBSN.Text = " ";
				txtFnameBSN.Text = " ";
				txtMnameBSN.Text = " ";
				txtLnameBSN.Text = " ";
				txtAgeBSN.Text = " ";
				cbGenderBSN.Text = " ";
				txtAddressBSN.Text = " ";
				txtEaddressBSN.Text = " ";
			}
		}

		private void btnNewBSCE_MouseClick(object sender, MouseEventArgs e)
		{

		}

		private void btnAddBSCE_MouseClick(object sender, MouseEventArgs e)
		{


			ListViewItem BSCE = new ListViewItem(txtIdBSCEE.Text);
			BSCE.SubItems.Add(txtFnameBSCE.Text);
			BSCE.SubItems.Add(txtMnameBSCE.Text);
			BSCE.SubItems.Add(txtLnameBSCE.Text);
			BSCE.SubItems.Add(txtAgeBSCE.Text);
			BSCE.SubItems.Add(cbGenderBSCE.Text);
			BSCE.SubItems.Add(txtAddressBSCE.Text);
			BSCE.SubItems.Add(txtEaddressBSCE.Text);
			BSCE.SubItems.Add(dateTimePickerBSCE.Text);

			listViewBSCE.Items.Add(BSCE);
			StudentDataStore.bscestudents.Add(new Class1
			{
				ID = txtIdBSCEE.Text,
				Firstname = txtFnameBSCE.Text,
				Middlename = txtMnameBSCE.Text,
				Lastname = txtLnameBSCE.Text,
				Age = txtAgeBSCE.Text,
				Gender = cbGenderBSCE.Text,
				Address = txtAddressBSCE.Text,
				EmailAddress = txtEaddressBSCE.Text,
				DateofBirth = dateTimePickerBSCE.Text


			});

			btnBSCENew.Enabled = true;
			btnAddBSCE.Enabled = false;
			txtIdBSCEE.Enabled = false;
			txtFnameBSCE.Enabled = false;
			txtMnameBSCE.Enabled = false;
			txtLnameBSCE.Enabled = false;
			txtAgeBSCE.Enabled = false;
			cbGenderBSCE.Enabled = false;
			txtAddressBSCE.Enabled = false;
			txtEaddressBSCE.Enabled = false;
			dateTimePickerBSCE.Enabled = false;


			txtIdBSCEE.Text = " ";
			txtFnameBSCE.Text = " ";
			txtMnameBSCE.Text = " ";
			txtLnameBSCE.Text = " ";
			txtAgeBSCE.Text = " ";
			cbGenderBSCE.Text = " ";
			txtAddressBSCE.Text = " ";
			txtEaddressBSCE.Text = " ";









		}

		private void btnBSNnew_MouseClick(object sender, MouseEventArgs e)
		{

		}

		private void btnBSCENew_MouseClick(object sender, MouseEventArgs e)
		{
			btnBSCENew.Enabled = false;
			btnAddBSCE.Enabled = true;
			txtIdBSCEE.Enabled = true;
			txtFnameBSCE.Enabled = true;
			txtMnameBSCE.Enabled = true;
			txtLnameBSCE.Enabled = true;
			txtAgeBSCE.Enabled = true;
			cbGenderBSCE.Enabled = true;
			txtAddressBSCE.Enabled = true;
			txtEaddressBSCE.Enabled = true;
			dateTimePickerBSCE.Enabled = true;
		}

		private void listViewBSCE_MouseClick(object sender, MouseEventArgs e)
		{

			if (role != "Admin")
			{
				return;
			}
			if (listViewBSCE.SelectedItems.Count > 0)
			{
				txtIdBSCEE.Text = listViewBSCE.SelectedItems[0].SubItems[0].Text;
				txtFnameBSCE.Text = listViewBSCE.SelectedItems[0].SubItems[1].Text;
				txtMnameBSCE.Text = listViewBSCE.SelectedItems[0].SubItems[2].Text;
				txtLnameBSCE.Text = listViewBSCE.SelectedItems[0].SubItems[3].Text;
				txtAgeBSCE.Text = listViewBSCE.SelectedItems[0].SubItems[4].Text;
				cbGenderBSCE.Text = listViewBSCE.SelectedItems[0].SubItems[5].Text;
				txtAddressBSCE.Text = listViewBSCE.SelectedItems[0].SubItems[6].Text;
				txtEaddressBSCE.Text = listViewBSCE.SelectedItems[0].SubItems[7].Text;
				dateTimePickerBSCE.Text = listViewBSCE.SelectedItems[0].SubItems[8].Text;

				btnBSCENew.Enabled = false;
				btnAddBSCE.Enabled = false;
				txtIdBSCEE.Enabled = true;
				txtFnameBSCE.Enabled = true;
				txtMnameBSCE.Enabled = true;
				txtLnameBSCE.Enabled = true;
				txtAgeBSCE.Enabled = true;
				cbGenderBSCE.Enabled = true;
				txtAddressBSCE.Enabled = true;
				txtEaddressBSCE.Enabled = true;
				dateTimePickerBSCE.Enabled = true;

				btnUpdateBSCE.Enabled = true;
				btnDeleteBSCE.Enabled = true;
			}
		}

		private void btnUpdateBSCE_MouseClick(object sender, MouseEventArgs e)
		{


			listViewBSCE.SelectedItems[0].SubItems[0].Text = txtIdBSCEE.Text;
			listViewBSCE.SelectedItems[0].SubItems[1].Text = txtFnameBSCE.Text;
			listViewBSCE.SelectedItems[0].SubItems[2].Text = txtMnameBSCE.Text;
			listViewBSCE.SelectedItems[0].SubItems[3].Text = txtLnameBSCE.Text;
			listViewBSCE.SelectedItems[0].SubItems[4].Text = txtAgeBSCE.Text;
			listViewBSCE.SelectedItems[0].SubItems[5].Text = cbGenderBSCE.Text;
			listViewBSCE.SelectedItems[0].SubItems[6].Text = txtAddressBSCE.Text;
			listViewBSCE.SelectedItems[0].SubItems[7].Text = txtEaddressBSCE.Text;
			listViewBSCE.SelectedItems[0].SubItems[8].Text = dateTimePickerBSCE.Text;

			btnBSCENew.Enabled = true;
			btnAddBSCE.Enabled = false;
			txtIdBSCEE.Enabled = false;
			txtFnameBSCE.Enabled = false;
			txtMnameBSCE.Enabled = false;
			txtLnameBSCE.Enabled = false;
			txtAgeBSCE.Enabled = false;
			cbGenderBSCE.Enabled = false;
			txtAddressBSCE.Enabled = false;
			txtEaddressBSCE.Enabled = false;
			dateTimePickerBSCE.Enabled = false;
			btnUpdateBSCE.Enabled = false;
			btnDeleteBSN.Enabled = false;


			txtIdBSCEE.Text = " ";
			txtFnameBSCE.Text = " ";
			txtMnameBSCE.Text = " ";
			txtLnameBSCE.Text = " ";
			txtAgeBSCE.Text = " ";
			cbGenderBSCE.Text = " ";
			txtAddressBSCE.Text = " ";
			txtEaddressBSCE.Text = " ";
		}

		private void btnDeleteBSCE_MouseClick(object sender, MouseEventArgs e)
		{

			if (listViewBSCE.SelectedItems.Count > 0)
			{
				int index = listViewBSCE.SelectedItems[0].Index;

				StudentDataStore.bscestudents.RemoveAt(index);
				listViewBSCE.Items.RemoveAt(index);

				btnBSCENew.Enabled = true;
				btnAddBSCE.Enabled = false;
				txtIdBSCEE.Enabled = false;
				txtFnameBSCE.Enabled = false;
				txtMnameBSCE.Enabled = false;
				txtLnameBSCE.Enabled = false;
				txtAgeBSCE.Enabled = false;
				cbGenderBSCE.Enabled = false;
				txtAddressBSCE.Enabled = false;
				txtEaddressBSCE.Enabled = false;
				dateTimePickerBSCE.Enabled = false;
				btnUpdateBSCE.Enabled = false;
				btnDeleteBSCE.Enabled = false;

				txtIdBSCEE.Text = " ";
				txtFnameBSCE.Text = " ";
				txtMnameBSCE.Text = " ";
				txtLnameBSCE.Text = " ";
				txtAgeBSCE.Text = " ";
				cbGenderBSCE.Text = " ";
				txtAddressBSCE.Text = " ";
				txtEaddressBSCE.Text = " ";
			}
		}

		private void btnNewBSEE_MouseClick(object sender, MouseEventArgs e)
		{





		}

		private void btnNewbsee_Click(object sender, EventArgs e)
		{

		}

		private void btnNewbsee_MouseClick_1(object sender, MouseEventArgs e)
		{
			btnNewbsee.Enabled = false;
			btnAddbsee.Enabled = true;
			txtIdBSEE.Enabled = true;
			txtFnameBSEE.Enabled = true;
			txtMnameBSEE.Enabled = true;
			txtLnameBSEE.Enabled = true;
			txtAgeBSEE.Enabled = true;
			cbGenderBSEE.Enabled = true;
			txtAddressBSEE.Enabled = true;
			txtEaddressBSEE.Enabled = true;
			dateTimePickerBSEE.Enabled = true;
		}

		private void btnAddbsee_MouseClick(object sender, MouseEventArgs e)
		{
			ListViewItem BSEE = new ListViewItem(txtIdBSEE.Text);
			BSEE.SubItems.Add(txtFnameBSEE.Text);
			BSEE.SubItems.Add(txtMnameBSEE.Text);
			BSEE.SubItems.Add(txtLnameBSEE.Text);
			BSEE.SubItems.Add(txtAgeBSEE.Text);
			BSEE.SubItems.Add(cbGenderBSEE.Text);
			BSEE.SubItems.Add(txtAddressBSEE.Text);
			BSEE.SubItems.Add(txtEaddressBSEE.Text);
			BSEE.SubItems.Add(dateTimePickerBSEE.Text);

			listView1BSEE.Items.Add(BSEE);
			StudentDataStore.bseestudents.Add(new Class1
			{
				ID = txtIdBSEE.Text,
				Firstname = txtFnameBSEE.Text,
				Middlename = txtMnameBSEE.Text,
				Lastname = txtLnameBSEE.Text,
				Age = txtAgeBSEE.Text,
				Gender = cbGenderBSEE.Text,
				Address = txtAddressBSEE.Text,
				EmailAddress = txtEaddressBSEE.Text,
				DateofBirth = dateTimePickerBSEE.Text

			});

			btnNewbsee.Enabled = true;
			btnAddbsee.Enabled = false;
			txtIdBSEE.Enabled = false;
			txtFnameBSEE.Enabled = false;
			txtMnameBSEE.Enabled = false;
			txtLnameBSEE.Enabled = false;
			txtAgeBSEE.Enabled = false;
			cbGenderBSEE.Enabled = false;
			txtAddressBSEE.Enabled = false;
			txtEaddressBSEE.Enabled = false;
			dateTimePickerBSEE.Enabled = false;

			txtIdBSEE.Text = " ";
			txtFnameBSEE.Text = " ";
			txtMnameBSEE.Text = " ";
			txtLnameBSEE.Text = " ";
			txtAgeBSEE.Text = " ";
			cbGenderBSEE.Text = " ";
			txtAddressBSEE.Text = " ";
			txtEaddressBSEE.Text = " ";





		}

		private void btnUpdateBSEE_MouseClick(object sender, MouseEventArgs e)
		{

			listView1BSEE.SelectedItems[0].SubItems[0].Text = txtIdBSEE.Text;
			listView1BSEE.SelectedItems[0].SubItems[1].Text = txtFnameBSEE.Text;
			listView1BSEE.SelectedItems[0].SubItems[2].Text = txtMnameBSEE.Text;
			listView1BSEE.SelectedItems[0].SubItems[3].Text = txtLnameBSEE.Text;
			listView1BSEE.SelectedItems[0].SubItems[4].Text = txtAgeBSEE.Text;
			listView1BSEE.SelectedItems[0].SubItems[5].Text = cbGenderBSEE.Text;
			listView1BSEE.SelectedItems[0].SubItems[6].Text = txtAddressBSEE.Text;
			listView1BSEE.SelectedItems[0].SubItems[7].Text = txtEaddressBSEE.Text;
			listView1BSEE.SelectedItems[0].SubItems[8].Text = dateTimePickerBSEE.Text;

			btnNewbsee.Enabled = true;
			btnAddbsee.Enabled = false;
			txtIdBSEE.Enabled = false;
			txtFnameBSEE.Enabled = false;
			txtMnameBSEE.Enabled = false;
			txtLnameBSEE.Enabled = false;
			txtAgeBSEE.Enabled = false;
			cbGenderBSEE.Enabled = false;
			txtAddressBSEE.Enabled = false;
			txtEaddressBSEE.Enabled = false;
			dateTimePickerBSEE.Enabled = false;
			btnUpdateBSEE.Enabled = false;
			btnDeleteBSEE.Enabled = false;

			txtIdBSEE.Text = " ";
			txtFnameBSEE.Text = " ";
			txtMnameBSEE.Text = " ";
			txtLnameBSEE.Text = " ";
			txtAgeBSEE.Text = " ";
			cbGenderBSEE.Text = " ";
			txtAddressBSEE.Text = " ";
			txtEaddressBSEE.Text = " ";
		}

		private void listView1BSEE_MouseClick(object sender, MouseEventArgs e)
		{

			if (role != "Admin")
			{
				return;
			}
			if (listView1BSEE.SelectedItems.Count > 0)
			{
				txtIdBSEE.Text = listView1BSEE.SelectedItems[0].SubItems[0].Text;
				txtFnameBSEE.Text = listView1BSEE.SelectedItems[0].SubItems[1].Text;
				txtMnameBSEE.Text = listView1BSEE.SelectedItems[0].SubItems[2].Text;
				txtLnameBSEE.Text = listView1BSEE.SelectedItems[0].SubItems[3].Text;
				txtAgeBSEE.Text = listView1BSEE.SelectedItems[0].SubItems[4].Text;
				cbGenderBSEE.Text = listView1BSEE.SelectedItems[0].SubItems[5].Text;
				txtAddressBSEE.Text = listView1BSEE.SelectedItems[0].SubItems[6].Text;
				txtEaddressBSEE.Text = listView1BSEE.SelectedItems[0].SubItems[7].Text;
				dateTimePickerBSEE.Text = listView1BSEE.SelectedItems[0].SubItems[8].Text;

				btnNewbsee.Enabled = false;
				btnAddbsee.Enabled = false;
				txtIdBSEE.Enabled = true;
				txtFnameBSEE.Enabled = true;
				txtMnameBSEE.Enabled = true;
				txtLnameBSEE.Enabled = true;
				txtAgeBSEE.Enabled = true;
				cbGenderBSEE.Enabled = true;
				txtAddressBSEE.Enabled = true;
				txtEaddressBSEE.Enabled = true;
				dateTimePickerBSEE.Enabled = true;
				btnUpdateBSEE.Enabled = true;
				btnDeleteBSEE.Enabled = true;

			}
		}

		private void btnDeleteBSEE_MouseClick(object sender, MouseEventArgs e)
		{
			if (listView1BSEE.SelectedItems.Count > 0)
			{
				int index = listView1BSEE.SelectedItems[0].Index;

				StudentDataStore.bseestudents.RemoveAt(index);
				listView1BSEE.Items.RemoveAt(index);

				btnNewbsee.Enabled = true;
				btnAddbsee.Enabled = false;
				txtIdBSEE.Enabled = false;
				txtFnameBSEE.Enabled = false;
				txtMnameBSEE.Enabled = false;
				txtLnameBSEE.Enabled = false;
				txtAgeBSEE.Enabled = false;
				cbGenderBSEE.Enabled = false;
				txtAddressBSEE.Enabled = false;
				txtEaddressBSEE.Enabled = false;
				dateTimePickerBSEE.Enabled = false;
				btnUpdateBSEE.Enabled = false;
				btnDeleteBSEE.Enabled = false;

				txtIdBSEE.Text = " ";
				txtFnameBSEE.Text = " ";
				txtMnameBSEE.Text = " ";
				txtLnameBSEE.Text = " ";
				txtAgeBSEE.Text = " ";
				cbGenderBSEE.Text = " ";
				txtAddressBSEE.Text = " ";
				txtEaddressBSEE.Text = " ";

			}
		}

		private void btnNewBSCJ_MouseClick(object sender, MouseEventArgs e)
		{
			btnNewBSCJ.Enabled = false;
			btnAddBSCJ.Enabled = true;
			txtIdBSCJ.Enabled = true;
			txtFnameBSCJ.Enabled = true;
			txtMnameBSCJ.Enabled = true;
			txtLnameBSCJ.Enabled = true;
			txtAgeBSCJ.Enabled = true;
			cbGenderBSCJ.Enabled = true;
			txtAddressBSCJ.Enabled = true;
			txtEaddressBSCJ.Enabled = true;
			dateTimePickerBSCJ.Enabled = true;

		}

		private void btnAddBSCJ_MouseClick(object sender, MouseEventArgs e)
		{
			ListViewItem BSCJ = new ListViewItem(txtIdBSCJ.Text);
			BSCJ.SubItems.Add(txtFnameBSCJ.Text);
			BSCJ.SubItems.Add(txtMnameBSCJ.Text);
			BSCJ.SubItems.Add(txtLnameBSCJ.Text);
			BSCJ.SubItems.Add(txtAgeBSCJ.Text);
			BSCJ.SubItems.Add(cbGenderBSCJ.Text);
			BSCJ.SubItems.Add(txtAddressBSCJ.Text);
			BSCJ.SubItems.Add(txtEaddressBSCJ.Text);
			BSCJ.SubItems.Add(dateTimePickerBSCJ.Text);

			listViewBSCJ.Items.Add(BSCJ);
			StudentDataStore.bscjstudents.Add(new Class1
			{
				ID = txtIdBSCJ.Text,
				Firstname = txtFnameBSCJ.Text,
				Middlename = txtMnameBSCJ.Text,
				Lastname = txtLnameBSCJ.Text,
				Age = txtAgeBSCJ.Text,
				Gender = cbGenderBSCJ.Text,
				Address = txtAddressBSCJ.Text,
				EmailAddress = txtEaddressBSCJ.Text,
				DateofBirth = dateTimePickerBSCJ.Text
			});
			btnNewBSCJ.Enabled = true;
			btnAddBSCJ.Enabled = false;
			txtIdBSCJ.Enabled = false;
			txtFnameBSCJ.Enabled = false;
			txtMnameBSCJ.Enabled = false;
			txtLnameBSCJ.Enabled = false;
			txtAgeBSCJ.Enabled = false;
			cbGenderBSCJ.Enabled = false;
			txtAddressBSCJ.Enabled = false;
			txtEaddressBSCJ.Enabled = false;
			dateTimePickerBSCJ.Enabled = false;

			txtIdBSCJ.Text = " ";
			txtFnameBSCJ.Text = " ";
			txtMnameBSCJ.Text = " ";
			txtLnameBSCJ.Text = " ";
			txtAgeBSCJ.Text = " ";
			cbGenderBSCJ.Text = " ";
			txtAddressBSCJ.Text = " ";
			txtEaddressBSCJ.Text = " ";

		}

		private void listViewBSCJ_MouseClick(object sender, MouseEventArgs e)
		{

			if (role != "Admin")
			{
				return;
			}
			if (listViewBSCJ.SelectedItems.Count > 0)
			{
				txtIdBSCJ.Text = listViewBSCJ.SelectedItems[0].SubItems[0].Text;
				txtFnameBSCJ.Text = listViewBSCJ.SelectedItems[0].SubItems[1].Text;
				txtMnameBSCJ.Text = listViewBSCJ.SelectedItems[0].SubItems[2].Text;
				txtLnameBSCJ.Text = listViewBSCJ.SelectedItems[0].SubItems[3].Text;
				txtAgeBSCJ.Text = listViewBSCJ.SelectedItems[0].SubItems[4].Text;
				cbGenderBSCJ.Text = listViewBSCJ.SelectedItems[0].SubItems[5].Text;
				txtAddressBSCJ.Text = listViewBSCJ.SelectedItems[0].SubItems[6].Text;
				txtEaddressBSCJ.Text = listViewBSCJ.SelectedItems[0].SubItems[7].Text;
				dateTimePickerBSCJ.Text = listViewBSCJ.SelectedItems[0].SubItems[8].Text;

				btnNewBSCJ.Enabled = false;
				btnAddBSCJ.Enabled = false;
				txtIdBSCJ.Enabled = true;
				txtFnameBSCJ.Enabled = true;
				txtMnameBSCJ.Enabled = true;
				txtLnameBSCJ.Enabled = true;
				txtAgeBSCJ.Enabled = true;
				cbGenderBSCJ.Enabled = true;
				txtAddressBSCJ.Enabled = true;
				txtEaddressBSCJ.Enabled = true;
				dateTimePickerBSCJ.Enabled = true;
				btnUpdateBSCJ.Enabled = true;
				btnDeleteBSCJ.Enabled = true;


			}
		}

		private void btnUpdateBSCJ_MouseClick(object sender, MouseEventArgs e)
		{
			listViewBSCJ.SelectedItems[0].SubItems[0].Text = txtIdBSCJ.Text;
			listViewBSCJ.SelectedItems[0].SubItems[1].Text = txtFnameBSCJ.Text;
			listViewBSCJ.SelectedItems[0].SubItems[2].Text = txtMnameBSCJ.Text;
			listViewBSCJ.SelectedItems[0].SubItems[3].Text = txtLnameBSCJ.Text;
			listViewBSCJ.SelectedItems[0].SubItems[4].Text = txtAgeBSCJ.Text;
			listViewBSCJ.SelectedItems[0].SubItems[5].Text = cbGenderBSCJ.Text;
			listViewBSCJ.SelectedItems[0].SubItems[6].Text = txtAddressBSCJ.Text;
			listViewBSCJ.SelectedItems[0].SubItems[7].Text = txtEaddressBSCJ.Text;
			listViewBSCJ.SelectedItems[0].SubItems[8].Text = dateTimePickerBSCJ.Text;

			btnNewBSCJ.Enabled = true;
			btnAddBSCJ.Enabled = false;
			txtIdBSCJ.Enabled = false;
			txtFnameBSCJ.Enabled = false;
			txtMnameBSCJ.Enabled = false;
			txtLnameBSCJ.Enabled = false;
			txtAgeBSCJ.Enabled = false;
			cbGenderBSCJ.Enabled = false;
			txtAddressBSCJ.Enabled = false;
			txtEaddressBSCJ.Enabled = false;
			dateTimePickerBSCJ.Enabled = false;
			btnUpdateBSCJ.Enabled = false;
			btnDeleteBSCJ.Enabled = false;


			txtIdBSCJ.Text = " ";
			txtFnameBSCJ.Text = " ";
			txtMnameBSCJ.Text = " ";
			txtLnameBSCJ.Text = " ";
			txtAgeBSCJ.Text = " ";
			cbGenderBSCJ.Text = " ";
			txtAddressBSCJ.Text = " ";
			txtEaddressBSCJ.Text = " ";

		}

		private void btnDeleteBSCJ_MouseClick(object sender, MouseEventArgs e)
		{
			if (listViewBSCJ.SelectedItems.Count > 0)
			{
				int index = listViewBSCJ.SelectedItems[0].Index;

				StudentDataStore.bscjstudents.RemoveAt(index);
				listViewBSCJ.Items.RemoveAt(index);

				btnNewBSCJ.Enabled = true;
				btnAddBSCJ.Enabled = false;
				txtIdBSCJ.Enabled = false;
				txtFnameBSCJ.Enabled = false;
				txtMnameBSCJ.Enabled = false;
				txtLnameBSCJ.Enabled = false;
				txtAgeBSCJ.Enabled = false;
				cbGenderBSCJ.Enabled = false;
				txtAddressBSCJ.Enabled = false;
				txtEaddressBSCJ.Enabled = false;
				dateTimePickerBSCJ.Enabled = false;
				btnUpdateBSCJ.Enabled = false;
				btnDeleteBSCJ.Enabled = false;


				txtIdBSCJ.Text = " ";
				txtFnameBSCJ.Text = " ";
				txtMnameBSCJ.Text = " ";
				txtLnameBSCJ.Text = " ";
				txtAgeBSCJ.Text = " ";
				cbGenderBSCJ.Text = " ";
				txtAddressBSCJ.Text = " ";
				txtEaddressBSCJ.Text = " ";


			}
		}

		private void btnNewBSHM_MouseClick(object sender, MouseEventArgs e)
		{
			btnNewBSHM.Enabled = false;
			btnAddBSHM.Enabled = true;
			txtIdBSHM.Enabled = true;
			txtFnameBSHM.Enabled = true;
			txtMnameBSHM.Enabled = true;
			txtLnameBSHM.Enabled = true;
			txtAgeBSHM.Enabled = true;
			cbGenderBSHM.Enabled = true;
			txtAddressBSHM.Enabled = true;
			txtEaddressBSHM.Enabled = true;
			dateTimePickerBSHM.Enabled = true;



		}

		private void btnAddBSHM_MouseClick(object sender, MouseEventArgs e)
		{

			ListViewItem BSHM = new ListViewItem(txtIdBSHM.Text);
			BSHM.SubItems.Add(txtFnameBSHM.Text);
			BSHM.SubItems.Add(txtMnameBSHM.Text);
			BSHM.SubItems.Add(txtLnameBSHM.Text);
			BSHM.SubItems.Add(txtAgeBSHM.Text);
			BSHM.SubItems.Add(cbGenderBSHM.Text);
			BSHM.SubItems.Add(txtAddressBSHM.Text);
			BSHM.SubItems.Add(txtEaddressBSHM.Text);
			BSHM.SubItems.Add(dateTimePickerBSHM.Text);

			listViewBSHM.Items.Add(BSHM);
			StudentDataStore.bshmstudents.Add(new Class1
			{
				ID = txtIdBSHM.Text,
				Firstname = txtFnameBSHM.Text,
				Middlename = txtMnameBSHM.Text,
				Lastname = txtLnameBSHM.Text,
				Age = txtAgeBSHM.Text,
				Gender = cbGenderBSHM.Text,
				Address = txtAddressBSHM.Text,
				EmailAddress = txtEaddressBSHM.Text,
				DateofBirth = dateTimePickerBSHM.Text
			});
			btnNewBSHM.Enabled = true;
			btnAddBSHM.Enabled = false;
			txtIdBSHM.Enabled = false;
			txtFnameBSHM.Enabled = false;
			txtMnameBSHM.Enabled = false;
			txtLnameBSHM.Enabled = false;
			txtAgeBSHM.Enabled = false;
			cbGenderBSHM.Enabled = false;
			txtAddressBSHM.Enabled = false;
			txtEaddressBSHM.Enabled = false;
			dateTimePickerBSHM.Enabled = false;

			txtIdBSHM.Text = " ";
			txtFnameBSHM.Text = " ";
			txtMnameBSHM.Text = " ";
			txtLnameBSHM.Text = " ";
			txtAgeBSHM.Text = " ";
			cbGenderBSHM.Text = " ";
			txtAddressBSHM.Text = " ";
			txtEaddressBSHM.Text = " ";



		}

		private void listViewBSHM_MouseClick(object sender, MouseEventArgs e)
		{

			if (role != "Admin")
			{
				return;
			}
			if (listViewBSHM.SelectedItems.Count > 0)
			{
				txtIdBSHM.Text = listViewBSHM.SelectedItems[0].SubItems[0].Text;
				txtFnameBSHM.Text = listViewBSHM.SelectedItems[0].SubItems[1].Text;
				txtMnameBSHM.Text = listViewBSHM.SelectedItems[0].SubItems[2].Text;
				txtLnameBSHM.Text = listViewBSHM.SelectedItems[0].SubItems[3].Text;
				txtAgeBSHM.Text = listViewBSHM.SelectedItems[0].SubItems[4].Text;
				cbGenderBSHM.Text = listViewBSHM.SelectedItems[0].SubItems[5].Text;
				txtAddressBSHM.Text = listViewBSHM.SelectedItems[0].SubItems[6].Text;
				txtEaddressBSHM.Text = listViewBSHM.SelectedItems[0].SubItems[7].Text;
				dateTimePickerBSHM.Text = listViewBSHM.SelectedItems[0].SubItems[8].Text;

				btnNewBSHM.Enabled = false;
				btnAddBSHM.Enabled = false;
				txtIdBSHM.Enabled = true;
				txtFnameBSHM.Enabled = true;
				txtMnameBSHM.Enabled = true;
				txtLnameBSHM.Enabled = true;
				txtAgeBSHM.Enabled = true;
				cbGenderBSHM.Enabled = true;
				txtAddressBSHM.Enabled = true;
				txtEaddressBSHM.Enabled = true;
				dateTimePickerBSHM.Enabled = true;
				btnUpdateBSHM.Enabled = true;
				btnDeleteBSHM.Enabled = true;
			}
		}

		private void btnUpdateBSHM_MouseClick(object sender, MouseEventArgs e)
		{

			listViewBSHM.SelectedItems[0].SubItems[0].Text = txtIdBSHM.Text;
			listViewBSHM.SelectedItems[0].SubItems[1].Text = txtFnameBSHM.Text;
			listViewBSHM.SelectedItems[0].SubItems[2].Text = txtMnameBSHM.Text;
			listViewBSHM.SelectedItems[0].SubItems[3].Text = txtLnameBSHM.Text;
			listViewBSHM.SelectedItems[0].SubItems[4].Text = txtAgeBSHM.Text;
			listViewBSHM.SelectedItems[0].SubItems[5].Text = cbGenderBSHM.Text;
			listViewBSHM.SelectedItems[0].SubItems[6].Text = txtAddressBSHM.Text;
			listViewBSHM.SelectedItems[0].SubItems[7].Text = txtEaddressBSHM.Text;
			listViewBSHM.SelectedItems[0].SubItems[8].Text = dateTimePickerBSHM.Text;

			btnNewBSHM.Enabled = true;
			btnAddBSHM.Enabled = false;
			txtIdBSHM.Enabled = false;
			txtFnameBSHM.Enabled = false;
			txtMnameBSHM.Enabled = false;
			txtLnameBSHM.Enabled = false;
			txtAgeBSHM.Enabled = false;
			cbGenderBSHM.Enabled = false;
			txtAddressBSHM.Enabled = false;
			txtEaddressBSHM.Enabled = false;
			dateTimePickerBSHM.Enabled = false;
			btnUpdateBSHM.Enabled = false;
			btnDeleteBSHM.Enabled = false;

			txtIdBSHM.Text = " ";
			txtFnameBSHM.Text = " ";
			txtMnameBSHM.Text = " ";
			txtLnameBSHM.Text = " ";
			txtAgeBSHM.Text = " ";
			cbGenderBSHM.Text = " ";
			txtAddressBSHM.Text = " ";
			txtEaddressBSHM.Text = " ";

		}

		private void btnDeleteBSHM_MouseClick(object sender, MouseEventArgs e)
		{
			if (listViewBSHM.SelectedItems.Count > 0)
			{
				int index = listViewBSHM.SelectedItems[0].Index;

				StudentDataStore.bshmstudents.RemoveAt(index);
				listViewBSHM.Items.RemoveAt(index);

				btnNewBSHM.Enabled = true;
				btnAddBSHM.Enabled = false;
				txtIdBSHM.Enabled = false;
				txtFnameBSHM.Enabled = false;
				txtMnameBSHM.Enabled = false;
				txtLnameBSHM.Enabled = false;
				txtAgeBSHM.Enabled = false;
				cbGenderBSHM.Enabled = false;
				txtAddressBSHM.Enabled = false;
				txtEaddressBSHM.Enabled = false;
				dateTimePickerBSHM.Enabled = false;
				btnUpdateBSHM.Enabled = false;
				btnDeleteBSHM.Enabled = false;

				txtIdBSHM.Text = " ";
				txtFnameBSHM.Text = " ";
				txtMnameBSHM.Text = " ";
				txtLnameBSHM.Text = " ";
				txtAgeBSHM.Text = " ";
				cbGenderBSHM.Text = " ";
				txtAddressBSHM.Text = " ";
				txtEaddressBSHM.Text = " ";
			}
		}

		private void BSEDPANEL_Paint(object sender, PaintEventArgs e)
		{

		}

		private void btnNewBSED_MouseClick(object sender, MouseEventArgs e)
		{
			btnNewBSED.Enabled = false;
			btnAddBSED.Enabled = true;
			txtIdBSED.Enabled = true;
			txtFnameBSED.Enabled = true;
			txtMnameBSED.Enabled = true;
			txtLnameBSED.Enabled = true;
			txtAgeBSED.Enabled = true;
			cbGenderBSED.Enabled = true;
			txtAddressBSED.Enabled = true;
			txtEaddressBSED.Enabled = true;
			dateTimePickerBSED.Enabled = true;

		}

		private void btnAddBSED_MouseClick(object sender, MouseEventArgs e)
		{
			ListViewItem BSED = new ListViewItem(txtIdBSED.Text);
			BSED.SubItems.Add(txtFnameBSED.Text);
			BSED.SubItems.Add(txtMnameBSED.Text);
			BSED.SubItems.Add(txtLnameBSED.Text);
			BSED.SubItems.Add(txtAgeBSED.Text);
			BSED.SubItems.Add(cbGenderBSED.Text);
			BSED.SubItems.Add(txtAddressBSED.Text);
			BSED.SubItems.Add(txtEaddressBSED.Text);
			BSED.SubItems.Add(dateTimePickerBSED.Text);

			listViewBSED.Items.Add(BSED);
			StudentDataStore.bsedstudents.Add(new Class1
			{
				ID = txtIdBSED.Text,
				Firstname = txtFnameBSED.Text,
				Middlename = txtMnameBSED.Text,
				Lastname = txtLnameBSED.Text,
				Age = txtAgeBSED.Text,
				Gender = cbGenderBSED.Text,
				Address = txtAddressBSED.Text,
				EmailAddress = txtEaddressBSED.Text,
				DateofBirth = dateTimePickerBSED.Text
			});
			btnNewBSED.Enabled = true;
			btnAddBSED.Enabled = false;
			txtIdBSED.Enabled = false;
			txtFnameBSED.Enabled = false;
			txtMnameBSED.Enabled = false;
			txtLnameBSED.Enabled = false;
			txtAgeBSED.Enabled = false;
			cbGenderBSED.Enabled = false;
			txtAddressBSED.Enabled = false;
			txtEaddressBSED.Enabled = false;
			dateTimePickerBSED.Enabled = false;

			txtIdBSED.Text = " ";
			txtFnameBSED.Text = " ";
			txtMnameBSED.Text = " ";
			txtLnameBSED.Text = " ";
			txtAgeBSED.Text = " ";
			cbGenderBSED.Text = " ";
			txtAddressBSED.Text = " ";
			txtEaddressBSED.Text = " ";



		}

		private void listViewBSED_MouseClick(object sender, MouseEventArgs e)
		{

			if (role != "Admin")
			{
				return;
			}
			if (listViewBSED.SelectedItems.Count > 0)
			{
				txtIdBSED.Text = listViewBSED.SelectedItems[0].SubItems[0].Text;
				txtFnameBSED.Text = listViewBSED.SelectedItems[0].SubItems[1].Text;
				txtMnameBSED.Text = listViewBSED.SelectedItems[0].SubItems[2].Text;
				txtLnameBSED.Text = listViewBSED.SelectedItems[0].SubItems[3].Text;
				txtAgeBSED.Text = listViewBSED.SelectedItems[0].SubItems[4].Text;
				cbGenderBSED.Text = listViewBSED.SelectedItems[0].SubItems[5].Text;
				txtAddressBSED.Text = listViewBSED.SelectedItems[0].SubItems[6].Text;
				txtEaddressBSED.Text = listViewBSED.SelectedItems[0].SubItems[7].Text;
				dateTimePickerBSED.Text = listViewBSED.SelectedItems[0].SubItems[8].Text;

				btnNewBSED.Enabled = false;
				btnAddBSED.Enabled = false;
				txtIdBSED.Enabled = true;
				txtFnameBSED.Enabled = true;
				txtMnameBSED.Enabled = true;
				txtLnameBSED.Enabled = true;
				txtAgeBSED.Enabled = true;
				cbGenderBSED.Enabled = true;
				txtAddressBSED.Enabled = true;
				txtEaddressBSED.Enabled = true;
				dateTimePickerBSED.Enabled = true;
				btnUpdateBSED.Enabled = true;
				btnDeleteBSED.Enabled = true;


			}
		}

		private void btnUpdateBSED_MouseClick(object sender, MouseEventArgs e)
		{

			listViewBSED.SelectedItems[0].SubItems[0].Text = txtIdBSED.Text;
			listViewBSED.SelectedItems[0].SubItems[1].Text = txtFnameBSED.Text;
			listViewBSED.SelectedItems[0].SubItems[2].Text = txtMnameBSED.Text;
			listViewBSED.SelectedItems[0].SubItems[3].Text = txtLnameBSED.Text;
			listViewBSED.SelectedItems[0].SubItems[4].Text = txtAgeBSED.Text;
			listViewBSED.SelectedItems[0].SubItems[5].Text = cbGenderBSED.Text;
			listViewBSED.SelectedItems[0].SubItems[6].Text = txtAddressBSED.Text;
			listViewBSED.SelectedItems[0].SubItems[7].Text = txtEaddressBSED.Text;
			listViewBSED.SelectedItems[0].SubItems[8].Text = dateTimePickerBSED.Text;

			btnNewBSED.Enabled = true;
			btnAddBSED.Enabled = false;
			txtIdBSED.Enabled = false;
			txtFnameBSED.Enabled = false;
			txtMnameBSED.Enabled = false;
			txtLnameBSED.Enabled = false;
			txtAgeBSED.Enabled = false;
			cbGenderBSED.Enabled = false;
			txtAddressBSED.Enabled = false;
			txtEaddressBSED.Enabled = false;
			dateTimePickerBSED.Enabled = false;
			btnUpdateBSED.Enabled = false;
			btnDeleteBSED.Enabled = false;

			txtIdBSED.Text = " ";
			txtFnameBSED.Text = " ";
			txtMnameBSED.Text = " ";
			txtLnameBSED.Text = " ";
			txtAgeBSED.Text = " ";
			cbGenderBSED.Text = " ";
			txtAddressBSED.Text = " ";
			txtEaddressBSED.Text = " ";
		}

		private void btnDeleteBSED_MouseClick(object sender, MouseEventArgs e)
		{
			if (listViewBSED.SelectedItems.Count > 0)
			{
				int index = listViewBSED.SelectedItems[0].Index;

				StudentDataStore.bsedstudents.RemoveAt(index);
				listViewBSED.Items.RemoveAt(index);

				btnNewBSED.Enabled = true;
				btnAddBSED.Enabled = false;
				txtIdBSED.Enabled = false;
				txtFnameBSED.Enabled = false;
				txtMnameBSED.Enabled = false;
				txtLnameBSED.Enabled = false;
				txtAgeBSED.Enabled = false;
				cbGenderBSED.Enabled = false;
				txtAddressBSED.Enabled = false;
				txtEaddressBSED.Enabled = false;
				dateTimePickerBSED.Enabled = false;
				btnUpdateBSED.Enabled = false;
				btnDeleteBSED.Enabled = false;

				txtIdBSED.Text = " ";
				txtFnameBSED.Text = " ";
				txtMnameBSED.Text = " ";
				txtLnameBSED.Text = " ";
				txtAgeBSED.Text = " ";
				cbGenderBSED.Text = " ";
				txtAddressBSED.Text = " ";
				txtEaddressBSED.Text = " ";
			}
		}

		private void textBox3_TextChanged(object sender, EventArgs e)
		{

		}

		private void textBox7_TextChanged(object sender, EventArgs e)
		{

		}

		private void btnNewSHS_MouseClick(object sender, MouseEventArgs e)
		{
			btnNewSHS.Enabled = false;
			btnAddSHS.Enabled = true;
			txtIdSHS.Enabled = true;
			txtFnameSHS.Enabled = true;
			txtMnameSHS.Enabled = true;
			txtLnameSHS.Enabled = true;
			txtAgeSHS.Enabled = true;
			cbGenderSHS.Enabled = true;
			txtAddressSHS.Enabled = true;
			txtEaddressSHS.Enabled = true;
			dateTimePickerSHS.Enabled = true;

		}

		private void btnAddSHS_MouseClick(object sender, MouseEventArgs e)
		{
			ListViewItem SHS = new ListViewItem(txtIdSHS.Text);
			SHS.SubItems.Add(txtFnameSHS.Text);
			SHS.SubItems.Add(txtMnameSHS.Text);
			SHS.SubItems.Add(txtLnameSHS.Text);
			SHS.SubItems.Add(txtAgeSHS.Text);
			SHS.SubItems.Add(cbGenderSHS.Text);
			SHS.SubItems.Add(txtAddressSHS.Text);
			SHS.SubItems.Add(txtEaddressSHS.Text);
			SHS.SubItems.Add(dateTimePickerSHS.Text);

			listViewSHS.Items.Add(SHS);
			StudentDataStore.shsstudents.Add(new Class1
			{
				ID = txtIdSHS.Text,
				Firstname = txtFnameSHS.Text,
				Middlename = txtMnameSHS.Text,
				Lastname = txtLnameSHS.Text,
				Age = txtAgeSHS.Text,
				Gender = cbGenderSHS.Text,
				Address = txtAddressSHS.Text,
				EmailAddress = txtEaddressSHS.Text,
				DateofBirth = dateTimePickerSHS.Text
			});
			btnNewSHS.Enabled = true;
			btnAddSHS.Enabled = false;
			txtIdSHS.Enabled = false;
			txtFnameSHS.Enabled = false;
			txtMnameSHS.Enabled = false;
			txtLnameSHS.Enabled = false;
			txtAgeSHS.Enabled = false;
			cbGenderSHS.Enabled = false;
			txtAddressSHS.Enabled = false;
			txtEaddressSHS.Enabled = false;
			dateTimePickerSHS.Enabled = false;

			txtIdSHS.Text = " ";
			txtFnameSHS.Text = " ";
			txtMnameSHS.Text = " ";
			txtLnameSHS.Text = " ";
			txtAgeSHS.Text = " ";
			cbGenderSHS.Text = " ";
			txtAddressSHS.Text = " ";
			txtEaddressSHS.Text = " ";






		}

		private void listViewSHS_MouseClick(object sender, MouseEventArgs e)
		{

			if (role != "Admin")
			{
				return;
			}
			if (listViewSHS.SelectedItems.Count > 0)
			{
				txtIdSHS.Text = listViewSHS.SelectedItems[0].SubItems[0].Text;
				txtFnameSHS.Text = listViewSHS.SelectedItems[0].SubItems[1].Text;
				txtMnameSHS.Text = listViewSHS.SelectedItems[0].SubItems[2].Text;
				txtLnameSHS.Text = listViewSHS.SelectedItems[0].SubItems[3].Text;
				txtAgeSHS.Text = listViewSHS.SelectedItems[0].SubItems[4].Text;
				cbGenderSHS.Text = listViewSHS.SelectedItems[0].SubItems[5].Text;
				txtAddressSHS.Text = listViewSHS.SelectedItems[0].SubItems[6].Text;
				txtEaddressSHS.Text = listViewSHS.SelectedItems[0].SubItems[7].Text;
				dateTimePickerSHS.Text = listViewSHS.SelectedItems[0].SubItems[8].Text;

				btnNewSHS.Enabled = false;
				btnAddSHS.Enabled = false;
				txtIdSHS.Enabled = true;
				txtFnameSHS.Enabled = true;
				txtMnameSHS.Enabled = true;
				txtLnameSHS.Enabled = true;
				txtAgeSHS.Enabled = true;
				cbGenderSHS.Enabled = true;
				txtAddressSHS.Enabled = true;
				txtEaddressSHS.Enabled = true;
				dateTimePickerSHS.Enabled = true;
				btnUpdateSHS.Enabled = true;
				btnDeleteSHS.Enabled = true;


			}



		}

		private void btnUpdateSHS_MouseClick(object sender, MouseEventArgs e)
		{
			listViewSHS.SelectedItems[0].SubItems[0].Text = txtIdSHS.Text;
			listViewSHS.SelectedItems[0].SubItems[1].Text = txtFnameSHS.Text;
			listViewSHS.SelectedItems[0].SubItems[2].Text = txtMnameSHS.Text;
			listViewSHS.SelectedItems[0].SubItems[3].Text = txtLnameSHS.Text;
			listViewSHS.SelectedItems[0].SubItems[4].Text = txtAgeSHS.Text;
			listViewSHS.SelectedItems[0].SubItems[5].Text = cbGenderSHS.Text;
			listViewSHS.SelectedItems[0].SubItems[6].Text = txtAddressSHS.Text;
			listViewSHS.SelectedItems[0].SubItems[7].Text = txtEaddressSHS.Text;
			listViewSHS.SelectedItems[0].SubItems[8].Text = dateTimePickerSHS.Text;


			btnNewSHS.Enabled = true;
			btnAddSHS.Enabled = false;
			txtIdSHS.Enabled = false;
			txtFnameSHS.Enabled = false;
			txtMnameSHS.Enabled = false;
			txtLnameSHS.Enabled = false;
			txtAgeSHS.Enabled = false;
			cbGenderSHS.Enabled = false;
			txtAddressSHS.Enabled = false;
			txtEaddressSHS.Enabled = false;
			dateTimePickerSHS.Enabled = false;
			btnUpdateSHS.Enabled = false;
			btnDeleteSHS.Enabled = false;

			txtIdSHS.Text = " ";
			txtFnameSHS.Text = " ";
			txtMnameSHS.Text = " ";
			txtLnameSHS.Text = " ";
			txtAgeSHS.Text = " ";
			cbGenderSHS.Text = " ";
			txtAddressSHS.Text = " ";
			txtEaddressSHS.Text = " ";

		}

		private void button4_MouseClick(object sender, MouseEventArgs e)
		{

			if (listViewSHS.SelectedItems.Count > 0)
			{
				int index = listViewSHS.SelectedItems[0].Index;

				StudentDataStore.shsstudents.RemoveAt(index);
				listViewSHS.Items.RemoveAt(index);

				btnNewSHS.Enabled = true;
				btnAddSHS.Enabled = false;
				txtIdSHS.Enabled = false;
				txtFnameSHS.Enabled = false;
				txtMnameSHS.Enabled = false;
				txtLnameSHS.Enabled = false;
				txtAgeSHS.Enabled = false;
				cbGenderSHS.Enabled = false;
				txtAddressSHS.Enabled = false;
				txtEaddressSHS.Enabled = false;
				dateTimePickerSHS.Enabled = false;
				btnUpdateSHS.Enabled = false;
				btnDeleteSHS.Enabled = false;

				txtIdSHS.Text = " ";
				txtFnameSHS.Text = " ";
				txtMnameSHS.Text = " ";
				txtLnameSHS.Text = " ";
				txtAgeSHS.Text = " ";
				cbGenderSHS.Text = " ";
				txtAddressSHS.Text = " ";
				txtEaddressSHS.Text = " ";
			}
		}

		private void btnCourses_MouseClick(object sender, MouseEventArgs e)
		{
			panel1.Visible = true;
			btnEDIT.Visible = true;
			panel5.Visible = false;
			btnCourses.Enabled = false;
			btnSCHEDULE.Enabled = true;


			PANELSDBSIT.Visible = false;
			PANELSDBSN.Visible = false;


		}

		private void SHSbtn_Click(object sender, EventArgs e)
		{

		}

		private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
		{
			panel4.Visible = true;
		}

		private void btnSCHEDULE_MouseClick(object sender, MouseEventArgs e)
		{
			BSITPANEL.Visible = false;
			BSBAPANEL.Visible = false;
			BSNPANEL.Visible = false;
			BSCEPANEL.Visible = false;
			PANELBSEE.Visible = false;
			BSCJPANEL.Visible = false;
			BSHMPANEL.Visible = false;
			BSEDPANEL.Visible = false;
			SHSPANEL.Visible = false;
			panel1.Visible = false;

			panel5.Visible = true;
			btnCourses.Enabled = true;
			btnSCHEDULE.Enabled = false;

		}

		private void btnSDBSIT_MouseClick(object sender, MouseEventArgs e)
		{
			btnSDBSIT.Enabled = false;
			btnSDBSBA.Enabled = true;
			btnSDBSN.Enabled = true;
			btnSDBSCE.Enabled = true;
			btnSDBSEE.Enabled = true;
			btnSDBSCJ.Enabled = true;
			btnSDBSHM.Enabled = true;
			btnSDBSED.Enabled = true;
			btnSDSHS.Enabled = true;



			PANELSDBSIT.Visible = true;
			PANELSDBSN.Visible = false;
		}

		private void btnSDBSBA_MouseClick(object sender, MouseEventArgs e)
		{
			btnSDBSIT.Enabled = true;
			btnSDBSBA.Enabled = false;
			btnSDBSN.Enabled = true;
			btnSDBSCE.Enabled = true;
			btnSDBSEE.Enabled = true;
			btnSDBSCJ.Enabled = true;
			btnSDBSHM.Enabled = true;
			btnSDBSED.Enabled = true;
			btnSDSHS.Enabled = true;

			PANELSDBSIT.Visible = false;
			PANELSDBSN.Visible = false;
		}

		private void btnSDBSN_MouseClick(object sender, MouseEventArgs e)
		{
			btnSDBSIT.Enabled = true;
			btnSDBSBA.Enabled = true;
			btnSDBSN.Enabled = false;
			btnSDBSCE.Enabled = true;
			btnSDBSEE.Enabled = true;
			btnSDBSCJ.Enabled = true;
			btnSDBSHM.Enabled = true;
			btnSDBSED.Enabled = true;
			btnSDSHS.Enabled = true;

			PANELSDBSIT.Visible = false;

			PANELSDBSN.Visible = true;
		}

		private void btnSDBSCE_MouseClick(object sender, MouseEventArgs e)
		{
			btnSDBSIT.Enabled = true;
			btnSDBSBA.Enabled = true;
			btnSDBSN.Enabled = true;
			btnSDBSCE.Enabled = false;
			btnSDBSEE.Enabled = true;
			btnSDBSCJ.Enabled = true;
			btnSDBSHM.Enabled = true;
			btnSDBSED.Enabled = true;
			btnSDSHS.Enabled = true;


			PANELSDBSIT.Visible = false;
			PANELSDBSN.Visible = false;
		}

		private void btnSDBSEE_MouseClick(object sender, MouseEventArgs e)
		{
			btnSDBSIT.Enabled = true;
			btnSDBSBA.Enabled = true;
			btnSDBSN.Enabled = true;
			btnSDBSCE.Enabled = true;
			btnSDBSEE.Enabled = false;
			btnSDBSCJ.Enabled = true;
			btnSDBSHM.Enabled = true;
			btnSDBSED.Enabled = true;
			btnSDSHS.Enabled = true;

			PANELSDBSIT.Visible = false;
			PANELSDBSN.Visible = false;
		}

		private void btnSDBSCJ_MouseClick(object sender, MouseEventArgs e)
		{
			btnSDBSIT.Enabled = true;
			btnSDBSBA.Enabled = true;
			btnSDBSN.Enabled = true;
			btnSDBSCE.Enabled = true;
			btnSDBSEE.Enabled = true;
			btnSDBSCJ.Enabled = false;
			btnSDBSHM.Enabled = true;
			btnSDBSED.Enabled = true;
			btnSDSHS.Enabled = true;

			PANELSDBSIT.Visible = false;
			PANELSDBSN.Visible = false;
		}

		private void button6_MouseClick(object sender, MouseEventArgs e)
		{
			btnSDBSIT.Enabled = true;
			btnSDBSBA.Enabled = true;
			btnSDBSN.Enabled = true;
			btnSDBSCE.Enabled = true;
			btnSDBSEE.Enabled = true;
			btnSDBSCJ.Enabled = true;
			btnSDBSHM.Enabled = false;
			btnSDBSED.Enabled = true;
			btnSDSHS.Enabled = true;

			PANELSDBSIT.Visible = false;
			PANELSDBSN.Visible = false;
		}

		private void btnSDBSED_MouseClick(object sender, MouseEventArgs e)
		{
			btnSDBSIT.Enabled = true;
			btnSDBSBA.Enabled = true;
			btnSDBSN.Enabled = true;
			btnSDBSCE.Enabled = true;
			btnSDBSEE.Enabled = true;
			btnSDBSCJ.Enabled = true;
			btnSDBSHM.Enabled = true;
			btnSDBSED.Enabled = false;
			btnSDSHS.Enabled = true;

			PANELSDBSIT.Visible = false;
			PANELSDBSN.Visible = false;
		}

		private void btnSDSHS_MouseClick(object sender, MouseEventArgs e)
		{
			btnSDBSIT.Enabled = true;
			btnSDBSBA.Enabled = true;
			btnSDBSN.Enabled = true;
			btnSDBSCE.Enabled = true;
			btnSDBSEE.Enabled = true;
			btnSDBSCJ.Enabled = true;
			btnSDBSHM.Enabled = true;
			btnSDBSED.Enabled = true;
			btnSDSHS.Enabled = false;

			PANELSDBSIT.Visible = false;
			PANELSDBSN.Visible = false;
		}

		private void btnERC_MouseClick(object sender, MouseEventArgs e)
		{
			Form3 form = new Form3(role);
			form.Show();
			this.Hide();
		}
	}
}
